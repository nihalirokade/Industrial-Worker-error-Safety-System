# Industrial Worker Safety and Error Prediction System

[![Python](https://img.shields.io/badge/Language-Python-3776AB?style=flat&logo=python&logoColor=white)](https://www.python.org/)
[![HTML](https://img.shields.io/badge/Language-HTML-E34F26?style=flat&logo=html5&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/HTML)
[![JavaScript](https://img.shields.io/badge/Language-JavaScript-F7DF1E?style=flat&logo=javascript&logoColor=black)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)

> An intelligent web platform for industrial operator readiness, fatigue detection, and Lead II ECG biosignal error prediction before operating heavy machinery.

---

## 🌐 Live Web Portal
Open the platform directly in your browser:
- **Web Application**: [Launch Web System](http://localhost:5173) *(Local Server)*
- **Offline All-in-One Edition**: Open [`local_app.html`](local_app.html) directly in any web browser (no setup required).

---

## 👥 Project Team

- **Nihali Rokade**
- **Bhavika Pawar**
- **Tejaswi Salian**

**Guided by:**  
Prof. Poonam Vengurlekare, B.Tech (AI),  
**Usha Mittal Institute of Technology (UMIT), SNDT Women's University, Mumbai.**

---

## ⚡ Key System Features

- **4-Stage Behavioral Readiness**: Evaluates Concentration (Go/No-Go), Reaction Speed (≤800ms per-click target), Error Detection ("Spot the Change"), and Memory Recall.
- **Lead II ECG Telemetry**: R-peak extraction using Pan-Tompkins algorithm, HRV vagal metrics (RMSSD, SDNN), and High/Low Cardiac Strain classification.
- **Operator Dashboard & History**: Real-time readiness clearance and chronological audit logs.

---

## 🚀 Quickstart Guide

- **All-in-One Compilation**: Open **[`local_app.html`](local_app.html)** in any browser, or visit **[http://localhost:5173](http://localhost:5173)** to run the complete interactive platform.

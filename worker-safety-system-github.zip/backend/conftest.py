import os
import sys

# Ensure the backend directory is in sys.path regardless of how pytest is invoked
backend_dir = os.path.dirname(os.path.abspath(__file__))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

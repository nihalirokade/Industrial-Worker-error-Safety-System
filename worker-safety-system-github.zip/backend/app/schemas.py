from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field

class Token(BaseModel):
    access_token: str
    token_type: str
    role: str
    username: str
    worker_id: int
    anonymized_id: str

class TokenData(BaseModel):
    username: Optional[str] = None
    role: Optional[str] = None
    worker_id: Optional[int] = None

class LoginRequest(BaseModel):
    username: str
    password: str

class WorkerBase(BaseModel):
    anonymized_id: str
    name: str
    department: str
    role: str

class WorkerCreate(WorkerBase):
    username: str
    password: str

class WorkerOut(WorkerBase):
    id: int
    username: str
    created_at: datetime

    class Config:
        from_attributes = True

class BehavioralSessionCreate(BaseModel):
    worker_id: int
    session_type: str = "daily_screening"
    
    # Go/No-Go metrics
    concentration_score: float = Field(..., ge=0, le=100)
    accuracy: float = Field(..., ge=0, le=100)
    total_trials: int = Field(..., ge=1)
    commission_errors: int = 0
    omission_errors: int = 0
    
    # Reaction-time metrics
    rt_median_ms: float = Field(..., ge=0)
    rt_sd_ms: float = Field(..., ge=0)
    rt_variability_cv: float = 0.0
    anticipatory_clicks: int = 0
    lapse_count: int = 0

    # Error Detection Test metrics
    error_detection_score: Optional[float] = 0.0
    error_detection_accuracy: Optional[float] = 0.0
    error_detection_correct: Optional[int] = 0
    error_detection_incorrect: Optional[int] = 0
    error_detection_avg_response_time: Optional[float] = 0.0

    # Memory Test metrics
    memory_score: Optional[float] = 0.0
    memory_correct: Optional[int] = 0
    memory_incorrect: Optional[int] = 0
    memory_avg_response_time: Optional[float] = 0.0
    memory_max_sequence_length: Optional[int] = 0
    
    # Raw trial stream
    raw_trial_data: Optional[Dict[str, Any]] = None

class RiskResultOut(BaseModel):
    id: int
    session_id: Optional[int] = None
    worker_id: int
    concentration_zscore: float
    reaction_zscore: float
    physiological_risk: Optional[float] = None
    is_baseline_established: bool
    final_risk_score: float
    classification: str
    confidence_score: float
    flagged_reasons: List[str]
    weights_used: Dict[str, float]
    status_action: str
    created_at: datetime

    class Config:
        from_attributes = True

class SessionOut(BaseModel):
    id: int
    worker_id: int
    session_type: str
    concentration_score: float
    accuracy: float
    total_trials: int
    commission_errors: int
    omission_errors: int
    rt_median_ms: float
    rt_sd_ms: float
    rt_variability_cv: float
    anticipatory_clicks: int
    lapse_count: int
    reaction_score: float

    # Error Detection metrics
    error_detection_score: Optional[float] = 0.0
    error_detection_accuracy: Optional[float] = 0.0
    error_detection_correct: Optional[int] = 0
    error_detection_incorrect: Optional[int] = 0
    error_detection_avg_response_time: Optional[float] = 0.0

    # Memory Test metrics
    memory_score: Optional[float] = 0.0
    memory_correct: Optional[int] = 0
    memory_incorrect: Optional[int] = 0
    memory_avg_response_time: Optional[float] = 0.0
    memory_max_sequence_length: Optional[int] = 0

    created_at: datetime
    risk_result: Optional[RiskResultOut] = None

    class Config:
        from_attributes = True

class BaselineOut(BaseModel):
    id: int
    worker_id: int
    session_count: int
    is_established: bool
    concentration_mean: float
    concentration_sd: float
    rt_median_mean: float
    rt_median_sd: float
    rt_sd_mean: float
    rt_sd_sd: float
    decay_factor: float
    last_calculated_at: datetime

    class Config:
        from_attributes = True

class EEGECGUploadOut(BaseModel):
    id: int
    worker_id: int
    session_id: Optional[int] = None
    filename: str
    file_type: str
    classification: Optional[str] = "normal"
    summary_note: Optional[str] = ""
    eeg_features: Dict[str, Any]
    ecg_features: Dict[str, Any]
    physiological_risk_score: float
    created_at: datetime

    class Config:
        from_attributes = True

class ActionUpdateRequest(BaseModel):
    action: str # cleared, rest_advised, reassigned, retest_requested

class DashboardWorkerCard(BaseModel):
    worker_id: int
    anonymized_id: str
    name: str
    department: str
    last_session_time: Optional[datetime] = None
    is_tested_today: bool
    baseline_established: bool
    session_count: int
    current_classification: str
    final_risk_score: float
    concentration_score: Optional[float] = None
    rt_median_ms: Optional[float] = None
    concentration_zscore: Optional[float] = None
    reaction_zscore: Optional[float] = None
    physiological_risk: Optional[float] = None
    flagged_reasons: List[str]
    status_action: str

class DashboardSummary(BaseModel):
    total_workers: int
    tested_today: int
    safe_count: int
    elevated_count: int
    high_risk_count: int
    workers: List[DashboardWorkerCard]

class WorkerDrilldown(BaseModel):
    worker: WorkerOut
    baseline: Optional[BaselineOut] = None
    recent_sessions: List[SessionOut]
    recent_risk_results: List[RiskResultOut]
    recent_uploads: List[EEGECGUploadOut]

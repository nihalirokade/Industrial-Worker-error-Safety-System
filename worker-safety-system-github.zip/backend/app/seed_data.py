import os
import json
from datetime import datetime, timedelta
import numpy as np
from .database import engine, SessionLocal, Base
from .models import Worker, Session as DbSession, Baseline, RiskResult, EEGECGUpload
from .auth import get_password_hash
from .baseline_engine import recompute_worker_baseline
from .risk_classifier import fuse_multimodal_risk, compute_physiological_risk
from .signal_processing import generate_synthetic_signal, extract_eeg_features, extract_ecg_features

def seed_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    try:
        # Check if already seeded
        if db.query(Worker).count() > 0:
            print("Database already populated. Skipping seed.")
            return

        print("Seeding initial industrial safety workforce and demo sessions...")

        # 1. Create Supervisor
        supervisor = Worker(
            anonymized_id="SUP-0001",
            username="supervisor",
            name="Operations Supervisor (Plant Unit 4)",
            department="Shift Command",
            role="supervisor",
            hashed_password=get_password_hash("admin123"),
            created_at=datetime.utcnow() - timedelta(days=60)
        )
        db.add(supervisor)

        # 2. Worker definitions
        worker_specs = [
            ("worker1", "WRK-8104", "Operator Alex (Control Room)", "Control Room", 14, "safe"),
            ("worker2", "WRK-4299", "Operator Brian (Turbine Deck)", "Turbine Deck", 12, "high_risk"),
            ("worker3", "WRK-9150", "Operator Chloe (Avionics Bay)", "Aviation Maintenance", 4, "cold_start"),
            ("worker4", "WRK-3021", "Operator David (Robotics Cell)", "Robotic Assembly", 10, "elevated_physio"),
            ("worker5", "WRK-5572", "Operator Elena (Core Monitoring)", "Nuclear Safety Ops", 15, "safe"),
            ("worker6", "WRK-1194", "Operator Frank (Assembly Line)", "Assembly Line", 8, "pending"),
        ]

        now = datetime.utcnow()

        for username, anon_id, name, dept, hist_days, today_type in worker_specs:
            worker = Worker(
                anonymized_id=anon_id,
                username=username,
                name=name,
                department=dept,
                role="worker",
                hashed_password=get_password_hash("worker123"),
                created_at=now - timedelta(days=hist_days + 5)
            )
            db.add(worker)
            db.commit()
            db.refresh(worker)

            # Generate historical sessions
            base_conc = 85.0 if today_type != "high_risk" else 83.0
            base_rt = 245.0 if today_type != "high_risk" else 260.0

            for d in range(hist_days, 0, -1):
                session_time = now - timedelta(days=d, hours=np.random.randint(1, 4))
                # Natural daily variance
                conc = float(np.clip(np.random.normal(base_conc, 4.0), 65.0, 98.0))
                rt = float(np.clip(np.random.normal(base_rt, 18.0), 190.0, 320.0))
                rtsd = float(np.clip(np.random.normal(42.0, 8.0), 20.0, 75.0))
                comm_errs = int(np.random.choice([0, 0, 1, 1, 2]))

                sess = DbSession(
                    worker_id=worker.id,
                    session_type="daily_screening",
                    concentration_score=round(conc, 1),
                    accuracy=round(92.0 + np.random.uniform(-4, 6), 1),
                    total_trials=30,
                    commission_errors=comm_errs,
                    omission_errors=0,
                    rt_median_ms=round(rt, 1),
                    rt_sd_ms=round(rtsd, 1),
                    rt_variability_cv=round(rtsd / rt, 3),
                    anticipatory_clicks=0,
                    lapse_count=0,
                    reaction_score=round(max(0, min(100, 100 - (rt - 180)/2.5)), 1),
                    raw_trial_data="{}",
                    created_at=session_time
                )
                db.add(sess)
                db.commit()
                db.refresh(sess)

                # Historical risk results
                risk = RiskResult(
                    session_id=sess.id,
                    worker_id=worker.id,
                    concentration_zscore=round((conc - base_conc)/5.0, 2),
                    reaction_zscore=round((rt - base_rt)/20.0, 2),
                    physiological_risk=None,
                    is_baseline_established=(d < hist_days - 6),
                    final_risk_score=round(np.clip(25.0 + np.random.uniform(-10, 15), 10.0, 42.0), 1),
                    classification="Safe Operation",
                    confidence_score=85.0,
                    flagged_reasons="[]",
                    weights_used=json.dumps({"concentration": 0.55, "reaction": 0.45}),
                    status_action="cleared",
                    created_at=session_time
                )
                db.add(risk)
                db.commit()

            # Compute established baseline up to today
            baseline = recompute_worker_baseline(db, worker.id)

            # Generate TODAY's session if not pending
            if today_type != "pending":
                today_time = now - timedelta(minutes=np.random.randint(20, 180))
                
                if today_type == "safe":
                    conc = round(float(np.random.normal(baseline.concentration_mean + 2, 2.0)), 1)
                    rt = round(float(np.random.normal(baseline.rt_median_mean - 10, 10.0)), 1)
                    rtsd = round(float(np.random.normal(38.0, 5.0)), 1)
                    comm = 0
                    lapses = 0
                elif today_type == "high_risk":
                    # Severe reaction slowing & concentration collapse
                    conc = 58.5 # Severe drop
                    rt = 378.0  # +2.6 SD slower!
                    rtsd = 94.0 # Erratic RT
                    comm = 5    # Impulse inhibition collapse
                    lapses = 3
                elif today_type == "cold_start":
                    # Building baseline
                    conc = 81.0
                    rt = 268.0
                    rtsd = 44.0
                    comm = 1
                    lapses = 0
                elif today_type == "elevated_physio":
                    # Moderate behavioral, but with physiological fatigue
                    conc = 78.0
                    rt = 275.0
                    rtsd = 50.0
                    comm = 2
                    lapses = 0

                today_sess = DbSession(
                    worker_id=worker.id,
                    session_type="daily_screening",
                    concentration_score=conc,
                    accuracy=82.0 if today_type == "high_risk" else 96.0,
                    total_trials=30,
                    commission_errors=comm,
                    omission_errors=2 if today_type == "high_risk" else 0,
                    rt_median_ms=rt,
                    rt_sd_ms=rtsd,
                    rt_variability_cv=round(rtsd / rt, 3),
                    anticipatory_clicks=1 if today_type == "high_risk" else 0,
                    lapse_count=lapses,
                    reaction_score=round(max(0, min(100, 100 - (rt - 180)/2.5)), 1),
                    raw_trial_data="{}",
                    created_at=today_time
                )
                db.add(today_sess)
                db.commit()
                db.refresh(today_sess)

                # Evaluate z-scores against baseline
                c_sd = max(baseline.concentration_sd, 3.0)
                rt_sd = max(baseline.rt_median_sd, 15.0)
                z_conc = round((conc - baseline.concentration_mean) / c_sd, 2)
                z_rt = round((rt - baseline.rt_median_mean) / rt_sd, 2)

                flags = []
                if z_rt >= 2.0:
                    flags.append(f"Severe motor/cognitive deceleration: RT {rt:.0f}ms (+{z_rt} SD above personal baseline)")
                elif z_rt >= 1.5:
                    flags.append(f"Noticeable reaction delay: RT {rt:.0f}ms (+{z_rt} SD above personal baseline)")
                
                if z_conc <= -2.0:
                    flags.append(f"Severe sustained-attention lapse: Score {conc:.1f} ({z_conc} SD drop below personal baseline)")
                elif z_conc <= -1.5:
                    flags.append(f"Concentration impairment: Score {conc:.1f} ({z_conc} SD drop below personal baseline)")

                if comm >= 4:
                    flags.append(f"High commission error count ({comm} false alarms on No-Go trials, indicating impulse inhibition failure)")

                physio_risk = None
                if today_type == "elevated_physio":
                    # Attach synthetic fatigued EEG upload
                    eeg_sig, fs = generate_synthetic_signal("eeg", "fatigued")
                    eeg_feats = extract_eeg_features(eeg_sig, fs)
                    physio_risk, bio_flags = compute_physiological_risk(eeg_feats, None)
                    flags.extend(bio_flags)

                    upload = EEGECGUpload(
                        session_id=today_sess.id,
                        worker_id=worker.id,
                        filename="eeg_shift_start_fatigue.csv",
                        file_type="eeg",
                        eeg_features=json.dumps(eeg_feats),
                        ecg_features="{}",
                        physiological_risk_score=physio_risk,
                        created_at=today_time
                    )
                    db.add(upload)
                    db.commit()

                fusion = fuse_multimodal_risk(
                    concentration_zscore=z_conc,
                    reaction_zscore=z_rt,
                    physiological_risk=physio_risk,
                    base_flagged_reasons=flags,
                    is_baseline_established=baseline.is_established
                )

                today_risk = RiskResult(
                    session_id=today_sess.id,
                    worker_id=worker.id,
                    concentration_zscore=z_conc,
                    reaction_zscore=z_rt,
                    physiological_risk=physio_risk,
                    is_baseline_established=baseline.is_established,
                    final_risk_score=fusion["final_risk_score"],
                    classification=fusion["classification"],
                    confidence_score=fusion["confidence_score"],
                    flagged_reasons=json.dumps(fusion["flagged_reasons"]),
                    weights_used=json.dumps(fusion["weights_used"]),
                    status_action="pending",
                    created_at=today_time
                )
                db.add(today_risk)
                db.commit()

                # Refresh baseline
                recompute_worker_baseline(db, worker.id)

        # 3. Create Sample Data Files for Download & Physical Testing
        sample_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "sample_data")
        os.makedirs(sample_dir, exist_ok=True)

        samples = [
            ("eeg_rested_worker.csv", "eeg", "rested", 256.0),
            ("eeg_fatigued_worker.csv", "eeg", "fatigued", 256.0),
            ("ecg_normal_worker.csv", "ecg", "rested", 250.0),
            ("ecg_stressed_worker.csv", "ecg", "high_stress", 250.0),
        ]

        for fname, stype, cond, fs in samples:
            sig, _ = generate_synthetic_signal(stype, cond, duration_sec=20)
            col_name = "eeg_voltage_uv" if stype == "eeg" else "ecg_lead_mv"
            csv_lines = [f"time_s,{col_name}"]
            for idx, val in enumerate(sig):
                csv_lines.append(f"{idx/fs:.4f},{val:.4f}")
            
            fpath = os.path.join(sample_dir, fname)
            with open(fpath, "w") as f:
                f.write("\n".join(csv_lines))

        print("Database seeded successfully with realistic workforce histories and sample data files.")

    except Exception as e:
        print(f"Error seeding database: {e}")
        db.rollback()
        raise e
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import engine, Base
from .seed_data import seed_database
from .routers import auth_router, worker_router, session_router, signal_router, supervisor_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize DB tables and auto-seed if needed
    Base.metadata.create_all(bind=engine)
    seed_database()
    yield

app = FastAPI(
    title="Industrial Worker Safety and Error Prediction System API",
    description="Cognitive screening (Go/No-Go & Reaction Time), adaptive personal baseline engine, EEG/ECG signal processing, and multi-modal risk prediction.",
    version="1.0.0",
    lifespan=lifespan
)

# Enable CORS for local Vite development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register route modules
app.include_router(auth_router.router)
app.include_router(worker_router.router)
app.include_router(session_router.router)
app.include_router(signal_router.router)
app.include_router(supervisor_router.router)

@app.get("/")
def root():
    return {
        "system": "Industrial Worker Safety & Error Prediction System",
        "status": "online",
        "docs_url": "/docs",
        "version": "1.0.0"
    }

@app.get("/health")
def health():
    return {"status": "healthy"}

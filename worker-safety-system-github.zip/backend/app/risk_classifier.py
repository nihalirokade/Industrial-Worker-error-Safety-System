from typing import Dict, Any, List, Optional, Tuple
import numpy as np
from sklearn.ensemble import RandomForestClassifier

def compute_physiological_risk(eeg_features: Optional[Dict[str, Any]] = None, ecg_features: Optional[Dict[str, Any]] = None) -> Tuple[float, List[str]]:
    """
    Computes a physiological risk score (0 - 100) from extracted EEG and ECG metrics.
    Higher score indicates higher error risk due to fatigue, drowsiness, or autonomic stress.
    """
    risk_points = 0.0
    total_weights = 0.0
    explanations = []

    if eeg_features:
        # 1. Fatigue index (theta + alpha) / beta. Normal is ~ 1.0 - 2.0. Fatigued > 3.0
        fatigue_idx = eeg_features.get("fatigue_index", 1.5)
        if fatigue_idx >= 3.0:
            risk_points += 85.0 * 0.35
            explanations.append(f"High EEG Fatigue Index ({fatigue_idx:.2f}): elevated theta/alpha relative to beta indicates drowsiness")
        elif fatigue_idx >= 2.0:
            risk_points += 55.0 * 0.35
        else:
            risk_points += 20.0 * 0.35
        total_weights += 0.35

        # 2. Theta/Beta Ratio (TBR). Normal < 2.5, impaired attention > 3.5
        tbr = eeg_features.get("theta_beta_ratio", 1.8)
        if tbr >= 3.5:
            risk_points += 80.0 * 0.25
            explanations.append(f"Elevated Theta/Beta Ratio ({tbr:.2f}): indicates reduced cortical activation and executive attention")
        elif tbr >= 2.5:
            risk_points += 50.0 * 0.25
        else:
            risk_points += 20.0 * 0.25
        total_weights += 0.25

    if ecg_features:
        # 3. RMSSD (ms): Parasympathetic tone. High stress or severe fatigue blunts RMSSD (<20ms)
        rmssd = ecg_features.get("rmssd_ms", 35.0)
        if rmssd < 18.0:
            risk_points += 85.0 * 0.20
            explanations.append(f"Severely suppressed RMSSD ({rmssd:.1f}ms): indicates high autonomic sympathetic strain/stress")
        elif rmssd < 28.0:
            risk_points += 50.0 * 0.20
        else:
            risk_points += 15.0 * 0.20
        total_weights += 0.20

        # 4. LF/HF ratio: Sympathovagal balance. Normal 1.0 - 2.5. Acute stress > 3.5
        lf_hf = ecg_features.get("lf_hf_ratio", 1.5)
        if lf_hf >= 3.5:
            risk_points += 80.0 * 0.20
            explanations.append(f"Elevated LF/HF ratio ({lf_hf:.2f}): sympathetic overdrive indicative of acute workload overload")
        elif lf_hf >= 2.5:
            risk_points += 55.0 * 0.20
        else:
            risk_points += 20.0 * 0.20
        total_weights += 0.20

    if total_weights == 0.0:
        return 0.0, []

    final_bio_score = round(risk_points / total_weights, 1)
    return final_bio_score, explanations

def fuse_multimodal_risk(
    concentration_zscore: float,
    reaction_zscore: float,
    physiological_risk: Optional[float] = None,
    base_flagged_reasons: Optional[List[str]] = None,
    is_baseline_established: bool = False
) -> Dict[str, Any]:
    """
    Fuses behavioral deviation z-scores and physiological risk into a unified
    Safe / Elevated / High-Risk classification using dynamic normalized weighting.
    """
    flags = list(base_flagged_reasons or [])
    
    # Map z-scores to 0-100 risk components:
    # Concentration: Negative z = impairment -> higher risk
    # z = -2.0 -> 100, z = 0 -> 50, z = +2.0 -> 0
    risk_conc = np.clip(50.0 - (25.0 * concentration_zscore), 0.0, 100.0)

    # Reaction Time: Positive z = slower -> higher risk
    # z = +2.0 -> 100, z = 0 -> 50, z = -2.0 -> 0
    risk_rt = np.clip(50.0 + (25.0 * reaction_zscore), 0.0, 100.0)

    # Default ideal base weights
    weights = {
        "concentration": 0.55,
        "reaction": 0.45,
    }

    modalities_used = {
        "concentration": float(risk_conc),
        "reaction": float(risk_rt),
    }

    if physiological_risk is not None:
        weights = {
            "physiological": 0.40,
            "concentration": 0.35,
            "reaction": 0.25,
        }
        modalities_used["physiological"] = float(physiological_risk)

    # Normalize weights across available modalities
    w_sum = sum(weights.values())
    norm_weights = {k: round(v / w_sum, 3) for k, v in weights.items()}

    final_risk = sum(norm_weights[k] * modalities_used[k] for k in norm_weights)
    final_risk = round(float(np.clip(final_risk, 0.0, 100.0)), 1)

    # Classification Thresholds
    if final_risk >= 68.0 or len(flags) >= 2 or (physiological_risk is not None and physiological_risk >= 80.0):
        classification = "High Error Risk"
    elif final_risk >= 42.0 or len(flags) == 1 or (physiological_risk is not None and physiological_risk >= 60.0):
        classification = "Elevated Monitoring"
    else:
        classification = "Safe Operation"

    # Confidence score: higher if established baseline and physiological data available
    confidence = 80.0
    if is_baseline_established:
        confidence += 10.0
    if physiological_risk is not None:
        confidence += 10.0
    confidence = min(98.0, confidence)

    return {
        "final_risk_score": final_risk,
        "classification": classification,
        "confidence_score": confidence,
        "weights_used": norm_weights,
        "risk_components": {
            "concentration_risk": round(float(risk_conc), 1),
            "reaction_risk": round(float(risk_rt), 1),
            "physiological_risk": round(float(physiological_risk), 1) if physiological_risk is not None else None
        },
        "flagged_reasons": flags,
    }

class MLRiskClassifier:
    """
    Random Forest classifier trained on cognitive and physiological feature distributions
    to provide an ML-backed risk probability for project viva and comparative verification.
    """
    def __init__(self):
        self.clf = RandomForestClassifier(n_estimators=50, random_state=42)
        self._fit_synthetic_model()

    def _fit_synthetic_model(self):
        # Features: [conc_z, rt_z, fatigue_index, rmssd, lf_hf]
        # Target: 0 (Safe), 1 (Elevated), 2 (High Risk)
        X = []
        y = []
        np.random.seed(42)
        
        # 300 Safe samples
        for _ in range(300):
            conc_z = np.random.normal(0.2, 0.6)
            rt_z = np.random.normal(-0.2, 0.6)
            fatigue = np.random.normal(1.2, 0.3)
            rmssd = np.random.normal(45.0, 8.0)
            lf_hf = np.random.normal(1.2, 0.3)
            X.append([conc_z, rt_z, fatigue, rmssd, lf_hf])
            y.append(0)

        # 200 Elevated samples
        for _ in range(200):
            conc_z = np.random.normal(-1.1, 0.5)
            rt_z = np.random.normal(1.2, 0.5)
            fatigue = np.random.normal(2.2, 0.4)
            rmssd = np.random.normal(27.0, 5.0)
            lf_hf = np.random.normal(2.4, 0.5)
            X.append([conc_z, rt_z, fatigue, rmssd, lf_hf])
            y.append(1)

        # 200 High Risk samples
        for _ in range(200):
            conc_z = np.random.normal(-2.3, 0.6)
            rt_z = np.random.normal(2.4, 0.6)
            fatigue = np.random.normal(3.8, 0.8)
            rmssd = np.random.normal(14.0, 4.0)
            lf_hf = np.random.normal(4.2, 0.8)
            X.append([conc_z, rt_z, fatigue, rmssd, lf_hf])
            y.append(2)

        self.clf.fit(np.array(X), np.array(y))

    def predict_risk_proba(self, conc_z: float, rt_z: float, fatigue_idx: float = 1.5, rmssd: float = 35.0, lf_hf: float = 1.5) -> Dict[str, float]:
        X_test = np.array([[conc_z, rt_z, fatigue_idx, rmssd, lf_hf]])
        probs = self.clf.predict_proba(X_test)[0]
        return {
            "p_safe": round(float(probs[0]), 3),
            "p_elevated": round(float(probs[1]), 3),
            "p_high_risk": round(float(probs[2]), 3),
        }

ml_classifier_instance = MLRiskClassifier()

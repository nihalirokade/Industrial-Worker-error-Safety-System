from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from .database import Base

class Worker(Base):
    __tablename__ = "workers"

    id = Column(Integer, primary_key=True, index=True)
    anonymized_id = Column(String(32), unique=True, index=True, nullable=False)
    username = Column(String(64), unique=True, index=True, nullable=False)
    name = Column(String(100), nullable=False)
    department = Column(String(100), default="Control Room")
    role = Column(String(20), default="worker") # worker, supervisor, admin
    hashed_password = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    sessions = relationship("Session", back_populates="worker", cascade="all, delete-orphan")
    baseline = relationship("Baseline", back_populates="worker", uselist=False, cascade="all, delete-orphan")
    uploads = relationship("EEGECGUpload", back_populates="worker", cascade="all, delete-orphan")
    risk_results = relationship("RiskResult", back_populates="worker", cascade="all, delete-orphan")

class Session(Base):
    __tablename__ = "sessions"

    id = Column(Integer, primary_key=True, index=True)
    worker_id = Column(Integer, ForeignKey("workers.id"), nullable=False)
    session_type = Column(String(50), default="daily_screening")
    
    # Concentration metrics (Go/No-Go)
    concentration_score = Column(Float, default=0.0)
    accuracy = Column(Float, default=0.0)
    total_trials = Column(Integer, default=0)
    commission_errors = Column(Integer, default=0) # Responded on No-Go
    omission_errors = Column(Integer, default=0)   # Missed Go
    
    # Reaction-time metrics
    rt_median_ms = Column(Float, default=0.0)
    rt_sd_ms = Column(Float, default=0.0)
    rt_variability_cv = Column(Float, default=0.0)
    anticipatory_clicks = Column(Integer, default=0) # <100ms
    lapse_count = Column(Integer, default=0)         # >1000ms
    reaction_score = Column(Float, default=0.0)

    # Error Detection Test metrics ("Spot the Change")
    error_detection_score = Column(Float, default=0.0)
    error_detection_accuracy = Column(Float, default=0.0)
    error_detection_correct = Column(Integer, default=0)
    error_detection_incorrect = Column(Integer, default=0)
    error_detection_avg_response_time = Column(Float, default=0.0)

    # Memory Test metrics ("Number Recall")
    memory_score = Column(Float, default=0.0)
    memory_correct = Column(Integer, default=0)
    memory_incorrect = Column(Integer, default=0)
    memory_avg_response_time = Column(Float, default=0.0)
    memory_max_sequence_length = Column(Integer, default=0)
    
    # Raw trial logs
    raw_trial_data = Column(Text, default="{}") # JSON string
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    worker = relationship("Worker", back_populates="sessions")
    risk_result = relationship("RiskResult", back_populates="session", uselist=False, cascade="all, delete-orphan")
    upload = relationship("EEGECGUpload", back_populates="session", uselist=False)

class Baseline(Base):
    __tablename__ = "baselines"

    id = Column(Integer, primary_key=True, index=True)
    worker_id = Column(Integer, ForeignKey("workers.id"), unique=True, nullable=False)
    session_count = Column(Integer, default=0)
    is_established = Column(Boolean, default=False)
    
    concentration_mean = Column(Float, default=82.0)
    concentration_sd = Column(Float, default=10.0)
    
    rt_median_mean = Column(Float, default=265.0)
    rt_median_sd = Column(Float, default=45.0)
    
    rt_sd_mean = Column(Float, default=48.0)
    rt_sd_sd = Column(Float, default=18.0)
    
    decay_factor = Column(Float, default=0.90)
    last_calculated_at = Column(DateTime, default=datetime.utcnow)

    worker = relationship("Worker", back_populates="baseline")

class EEGECGUpload(Base):
    __tablename__ = "eeg_ecg_uploads"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=True)
    worker_id = Column(Integer, ForeignKey("workers.id"), nullable=False)
    filename = Column(String(255), nullable=False)
    file_type = Column(String(50), default="ecg") # eeg, ecg, combined, pdf
    classification = Column(String(50), default="normal") # normal, tensed
    summary_note = Column(Text, default="")
    
    eeg_features = Column(Text, default="{}") # JSON: delta, theta, alpha, beta, gamma, theta_beta_ratio
    ecg_features = Column(Text, default="{}") # JSON: mean_hr, rmssd, sdnn, lf, hf, lf_hf_ratio
    physiological_risk_score = Column(Float, default=0.0) # 0 - 100
    created_at = Column(DateTime, default=datetime.utcnow)

    worker = relationship("Worker", back_populates="uploads")
    session = relationship("Session", back_populates="upload")

class RiskResult(Base):
    __tablename__ = "risk_results"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=True)
    worker_id = Column(Integer, ForeignKey("workers.id"), nullable=False)
    
    concentration_zscore = Column(Float, default=0.0)
    reaction_zscore = Column(Float, default=0.0)
    physiological_risk = Column(Float, nullable=True) # Null if no upload
    is_baseline_established = Column(Boolean, default=False)
    
    final_risk_score = Column(Float, default=0.0) # 0 - 100
    classification = Column(String(50), default="Safe Operation") # Safe Operation, Elevated Monitoring, High Error Risk
    confidence_score = Column(Float, default=85.0) # 0 - 100
    flagged_reasons = Column(Text, default="[]") # JSON list of string explanations
    weights_used = Column(Text, default="{}")     # JSON dict of weights
    status_action = Column(String(50), default="pending") # pending, cleared, rest_advised, reassigned
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    worker = relationship("Worker", back_populates="risk_results")
    session = relationship("Session", back_populates="risk_result")

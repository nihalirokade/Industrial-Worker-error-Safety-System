from datetime import datetime
from typing import List, Dict, Any, Tuple
import numpy as np
from sqlalchemy.orm import Session
from .models import Worker, Session as DbSession, Baseline

MIN_SESSIONS_FOR_BASELINE = 7

# Reference values derived from empirical normative cognitive-motor literature
POPULATION_NORMS = {
    "concentration_mean": 82.0,
    "concentration_sd": 10.0,
    "rt_median_mean": 265.0,
    "rt_median_sd": 45.0,
    "rt_sd_mean": 48.0,
    "rt_sd_sd": 18.0,
}

# Clamps on standard deviations to prevent infinite z-scores if worker is robotic
MIN_SD_FLOORS = {
    "concentration": 3.0,
    "rt_median": 15.0,
    "rt_sd": 6.0,
}

def compute_robust_stats(values: List[float], min_sd: float) -> Tuple[float, float]:
    """
    Computes location (median) and scale (Normalized Median Absolute Deviation - NMAD)
    which is robust against historical one-off outlier sessions.
    """
    arr = np.array(values, dtype=float)
    if len(arr) == 0:
        return 0.0, min_sd
    med = float(np.median(arr))
    mad = float(np.median(np.abs(arr - med)))
    # 1.4826 makes MAD an unbiased estimator for normal distribution standard deviation
    nmad = 1.4826 * mad
    sd = max(float(nmad), float(np.std(arr, ddof=1)) if len(arr) > 1 else min_sd, min_sd)
    return med, sd

def recompute_worker_baseline(db: Session, worker_id: int) -> Baseline:
    """
    Recomputes personal baseline for a worker based on all historical sessions.
    Implements cold-start cutoff (>= 7 sessions) and recency-weighted statistics.
    """
    sessions = (
        db.query(DbSession)
        .filter(DbSession.worker_id == worker_id)
        .order_by(DbSession.created_at.asc())
        .all()
    )

    baseline = db.query(Baseline).filter(Baseline.worker_id == worker_id).first()
    if not baseline:
        baseline = Baseline(worker_id=worker_id)
        db.add(baseline)

    session_count = len(sessions)
    baseline.session_count = session_count

    if session_count < MIN_SESSIONS_FOR_BASELINE:
        # Cold start: Use population norms
        baseline.is_established = False
        baseline.concentration_mean = POPULATION_NORMS["concentration_mean"]
        baseline.concentration_sd = POPULATION_NORMS["concentration_sd"]
        baseline.rt_median_mean = POPULATION_NORMS["rt_median_mean"]
        baseline.rt_median_sd = POPULATION_NORMS["rt_median_sd"]
        baseline.rt_sd_mean = POPULATION_NORMS["rt_sd_mean"]
        baseline.rt_sd_sd = POPULATION_NORMS["rt_sd_sd"]
    else:
        # Established baseline: Compute personal distributions with recency weighting
        baseline.is_established = True
        
        # Consider the most recent 30 sessions for active rolling window
        recent_sessions = sessions[-30:]
        
        # Recency weighting: weights decay by 0.95 per step into the past
        n = len(recent_sessions)
        weights = np.array([0.95 ** (n - 1 - i) for i in range(n)])
        weights /= weights.sum()

        conc_vals = [s.concentration_score for s in recent_sessions]
        rt_med_vals = [s.rt_median_ms for s in recent_sessions]
        rt_sd_vals = [s.rt_sd_ms for s in recent_sessions]

        # Weighted mean and weighted standard deviation
        conc_mean = float(np.average(conc_vals, weights=weights))
        conc_var = float(np.average((np.array(conc_vals) - conc_mean) ** 2, weights=weights))
        baseline.concentration_mean = round(conc_mean, 2)
        baseline.concentration_sd = round(max(np.sqrt(conc_var), MIN_SD_FLOORS["concentration"]), 2)

        rt_mean = float(np.average(rt_med_vals, weights=weights))
        rt_var = float(np.average((np.array(rt_med_vals) - rt_mean) ** 2, weights=weights))
        baseline.rt_median_mean = round(rt_mean, 2)
        baseline.rt_median_sd = round(max(np.sqrt(rt_var), MIN_SD_FLOORS["rt_median"]), 2)

        rtsd_mean = float(np.average(rt_sd_vals, weights=weights))
        rtsd_var = float(np.average((np.array(rt_sd_vals) - rtsd_mean) ** 2, weights=weights))
        baseline.rt_sd_mean = round(rtsd_mean, 2)
        baseline.rt_sd_sd = round(max(np.sqrt(rtsd_var), MIN_SD_FLOORS["rt_sd"]), 2)

    baseline.last_calculated_at = datetime.utcnow()
    db.commit()
    db.refresh(baseline)
    return baseline

def score_session_against_baseline(
    db: Session,
    worker_id: int,
    concentration_score: float,
    rt_median_ms: float,
    rt_sd_ms: float,
    commission_errors: int = 0,
    anticipatory_clicks: int = 0,
    lapse_count: int = 0
) -> Dict[str, Any]:
    """
    Evaluates current behavioral scores against personal baseline or population norms.
    Calculates z-scores and produces explainable flags.
    """
    baseline = db.query(Baseline).filter(Baseline.worker_id == worker_id).first()
    if not baseline:
        baseline = recompute_worker_baseline(db, worker_id)

    is_established = baseline.is_established
    c_mean = baseline.concentration_mean
    c_sd = max(baseline.concentration_sd, MIN_SD_FLOORS["concentration"])

    rt_mean = baseline.rt_median_mean
    rt_sd = max(baseline.rt_median_sd, MIN_SD_FLOORS["rt_median"])

    rtsd_mean = baseline.rt_sd_mean
    rtsd_sd = max(baseline.rt_sd_sd, MIN_SD_FLOORS["rt_sd"])

    # z-scores:
    # For concentration: higher is better, so positive = above normal, negative = impairment
    z_conc = (concentration_score - c_mean) / c_sd
    
    # For reaction time: lower (faster) is better, so positive = slowing (impairment), negative = faster
    z_rt = (rt_median_ms - rt_mean) / rt_sd

    # For reaction time variability: higher = less stable/more lapses
    z_rtsd = (rt_sd_ms - rtsd_mean) / rtsd_sd

    flagged_reasons = []
    norm_context = "personal baseline" if is_established else "population reference norm (baseline still building)"

    # Check for meaningful negative deviations (|z| >= 1.5 - 2.0 SD)
    if z_rt >= 2.0:
        flagged_reasons.append(
            f"Severe motor/cognitive deceleration: RT is {rt_median_ms:.0f}ms (+{z_rt:.2f} SD slower than {norm_context})"
        )
    elif z_rt >= 1.5:
        flagged_reasons.append(
            f"Noticeable reaction delay: RT is {rt_median_ms:.0f}ms (+{z_rt:.2f} SD slower than {norm_context})"
        )

    if z_conc <= -2.0:
        flagged_reasons.append(
            f"Severe sustained-attention lapse: Score {concentration_score:.1f} ({z_conc:.2f} SD drop below {norm_context})"
        )
    elif z_conc <= -1.5:
        flagged_reasons.append(
            f"Concentration impairment: Score {concentration_score:.1f} ({z_conc:.2f} SD drop below {norm_context})"
        )

    if z_rtsd >= 2.0:
        flagged_reasons.append(
            f"Extreme response variability / micro-lapses (+{z_rtsd:.2f} SD deviation in RT consistency)"
        )

    if commission_errors >= 4:
        flagged_reasons.append(
            f"High commission error count ({commission_errors} false clicks on No-Go trials, indicating impaired impulse inhibition)"
        )

    if lapse_count >= 2:
        flagged_reasons.append(
            f"{lapse_count} major attentional lapses detected (>1000ms response latency)"
        )

    if anticipatory_clicks >= 3:
        flagged_reasons.append(
            f"{anticipatory_clicks} anticipatory responses (<100ms false start clicks)"
        )

    return {
        "is_baseline_established": is_established,
        "session_count": baseline.session_count,
        "concentration_zscore": round(float(z_conc), 2),
        "reaction_zscore": round(float(z_rt), 2),
        "reaction_sd_zscore": round(float(z_rtsd), 2),
        "flagged_reasons": flagged_reasons,
        "baseline_snapshot": {
            "concentration_mean": c_mean,
            "concentration_sd": c_sd,
            "rt_median_mean": rt_mean,
            "rt_median_sd": rt_sd,
        }
    }

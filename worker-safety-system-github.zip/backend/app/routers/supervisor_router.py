import json
from datetime import datetime, date
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Worker, Session as DbSession, Baseline, RiskResult, EEGECGUpload
from ..schemas import ActionUpdateRequest, DashboardSummary, DashboardWorkerCard, WorkerDrilldown
from ..auth import require_supervisor, get_current_user
from ..baseline_engine import recompute_worker_baseline

router = APIRouter(prefix="/supervisor", tags=["supervisor"])

@router.get("/dashboard")
def get_supervisor_dashboard(db: Session = Depends(get_db), current_user: Worker = Depends(require_supervisor)):
    workers = db.query(Worker).filter(Worker.role == "worker").all()
    
    total_workers = len(workers)
    tested_today = 0
    safe_count = 0
    elevated_count = 0
    high_risk_count = 0
    worker_cards = []

    today = date.today()

    for w in workers:
        # Get latest session
        latest_session = (
            db.query(DbSession)
            .filter(DbSession.worker_id == w.id)
            .order_by(DbSession.created_at.desc())
            .first()
        )

        baseline = db.query(Baseline).filter(Baseline.worker_id == w.id).first()
        if not baseline:
            baseline = recompute_worker_baseline(db, w.id)

        latest_risk = None
        if latest_session:
            latest_risk = db.query(RiskResult).filter(RiskResult.session_id == latest_session.id).first()

        is_today = False
        if latest_session and latest_session.created_at.date() == today:
            is_today = True
            tested_today += 1

        classification = latest_risk.classification if latest_risk else "Pending Test"
        final_risk = latest_risk.final_risk_score if latest_risk else 0.0

        if is_today:
            if classification == "Safe Operation":
                safe_count += 1
            elif classification == "Elevated Monitoring":
                elevated_count += 1
            elif classification == "High Error Risk":
                high_risk_count += 1

        flags = []
        if latest_risk and latest_risk.flagged_reasons:
            try:
                flags = json.loads(latest_risk.flagged_reasons)
            except Exception:
                flags = []

        card = {
            "worker_id": w.id,
            "anonymized_id": w.anonymized_id,
            "name": w.name,
            "department": w.department,
            "last_session_time": latest_session.created_at.isoformat() if latest_session else None,
            "is_tested_today": is_today,
            "baseline_established": baseline.is_established if baseline else False,
            "session_count": baseline.session_count if baseline else 0,
            "current_classification": classification,
            "final_risk_score": final_risk,
            "concentration_score": latest_session.concentration_score if latest_session else None,
            "rt_median_ms": latest_session.rt_median_ms if latest_session else None,
            "concentration_zscore": latest_risk.concentration_zscore if latest_risk else None,
            "reaction_zscore": latest_risk.reaction_zscore if latest_risk else None,
            "physiological_risk": latest_risk.physiological_risk if latest_risk else None,
            "flagged_reasons": flags,
            "status_action": latest_risk.status_action if latest_risk else "none"
        }
        worker_cards.append(card)

    # Sort high risk and elevated first
    sort_priority = {"High Error Risk": 0, "Elevated Monitoring": 1, "Safe Operation": 2, "Pending Test": 3}
    worker_cards.sort(key=lambda x: (sort_priority.get(x["current_classification"], 4), -x["final_risk_score"]))

    return {
        "total_workers": total_workers,
        "tested_today": tested_today,
        "safe_count": safe_count,
        "elevated_count": elevated_count,
        "high_risk_count": high_risk_count,
        "workers": worker_cards
    }

@router.get("/workers/{worker_id}/drilldown")
def get_worker_drilldown(worker_id: int, db: Session = Depends(get_db), current_user: Worker = Depends(require_supervisor)):
    worker = db.query(Worker).filter(Worker.id == worker_id).first()
    if not worker:
        raise HTTPException(status_code=404, detail="Worker not found")

    baseline = db.query(Baseline).filter(Baseline.worker_id == worker_id).first()
    if not baseline:
        baseline = recompute_worker_baseline(db, worker_id)

    sessions = (
        db.query(DbSession)
        .filter(DbSession.worker_id == worker_id)
        .order_by(DbSession.created_at.desc())
        .limit(20)
        .all()
    )

    history = []
    for s in reversed(sessions):
        risk = db.query(RiskResult).filter(RiskResult.session_id == s.id).first()
        history.append({
            "session_id": s.id,
            "date": s.created_at.strftime("%b %d"),
            "timestamp": s.created_at.isoformat(),
            "concentration_score": s.concentration_score,
            "reaction_score": s.reaction_score,
            "rt_median_ms": s.rt_median_ms,
            "rt_sd_ms": s.rt_sd_ms,
            "final_risk_score": risk.final_risk_score if risk else 0.0,
            "classification": risk.classification if risk else "Safe Operation",
            "concentration_zscore": risk.concentration_zscore if risk else 0.0,
            "reaction_zscore": risk.reaction_zscore if risk else 0.0,
            "physiological_risk": risk.physiological_risk if risk else None,
            "flags": json.loads(risk.flagged_reasons) if risk and risk.flagged_reasons else [],
            "action": risk.status_action if risk else "none"
        })

    uploads = (
        db.query(EEGECGUpload)
        .filter(EEGECGUpload.worker_id == worker_id)
        .order_by(EEGECGUpload.created_at.desc())
        .limit(5)
        .all()
    )
    
    upload_summaries = []
    for u in uploads:
        upload_summaries.append({
            "id": u.id,
            "filename": u.filename,
            "file_type": u.file_type,
            "physiological_risk_score": u.physiological_risk_score,
            "eeg_features": json.loads(u.eeg_features) if u.eeg_features else {},
            "ecg_features": json.loads(u.ecg_features) if u.ecg_features else {},
            "created_at": u.created_at.isoformat()
        })

    return {
        "worker": {
            "id": worker.id,
            "anonymized_id": worker.anonymized_id,
            "name": worker.name,
            "department": worker.department,
            "role": worker.role,
        },
        "baseline": {
            "is_established": baseline.is_established,
            "session_count": baseline.session_count,
            "concentration_mean": baseline.concentration_mean,
            "concentration_sd": baseline.concentration_sd,
            "rt_median_mean": baseline.rt_median_mean,
            "rt_median_sd": baseline.rt_median_sd,
            "rt_sd_mean": baseline.rt_sd_mean,
            "rt_sd_sd": baseline.rt_sd_sd,
            "last_calculated_at": baseline.last_calculated_at.isoformat(),
        },
        "history": history,
        "uploads": upload_summaries
    }

@router.post("/action/{worker_id}")
def update_supervisor_action(
    worker_id: int,
    payload: ActionUpdateRequest,
    db: Session = Depends(get_db),
    current_user: Worker = Depends(require_supervisor)
):
    latest_risk = (
        db.query(RiskResult)
        .filter(RiskResult.worker_id == worker_id)
        .order_by(RiskResult.created_at.desc())
        .first()
    )
    if not latest_risk:
        raise HTTPException(status_code=404, detail="No risk assessment found for worker")

    latest_risk.status_action = payload.action
    db.commit()
    return {"message": f"Status updated to {payload.action}", "action": payload.action}

import json
from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session
import numpy as np
from ..database import get_db
from ..models import Worker, Session as DbSession, EEGECGUpload, RiskResult
from ..auth import get_current_user
from ..signal_processing import (
    parse_signal_file,
    extract_eeg_features,
    extract_ecg_features,
    generate_synthetic_signal
)
from ..risk_classifier import compute_physiological_risk, fuse_multimodal_risk

router = APIRouter(prefix="/signals", tags=["signals"])

@router.post("/upload")
async def upload_signal_file(
    worker_id: int = Form(...),
    session_id: Optional[int] = Form(None),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: Worker = Depends(get_current_user)
):
    content = await file.read()
    filename = file.filename or "signal.csv"
    
    try:
        signal_data, detected_type = parse_signal_file(content, filename)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to parse signal file: {str(e)}")

    eeg_features = None
    ecg_features = None

    if detected_type == "eeg":
        eeg_features = extract_eeg_features(signal_data)
    else:
        ecg_features = extract_ecg_features(signal_data)

    physio_risk, bio_flags = compute_physiological_risk(eeg_features, ecg_features)
    classification = "tensed" if physio_risk >= 50.0 else "normal"
    
    if ecg_features:
        hr = ecg_features.get("mean_heart_rate_bpm", 72.0)
        rmssd = ecg_features.get("rmssd_ms", 42.0)
        c_desc = "Acute sympathetic strain (Tensed)" if classification == "tensed" else "Healthy Sinus Rhythm (Normal)"
        summary_note = f"Lead II recording · Mean HR: {hr:.0f} BPM, RMSSD: {rmssd:.1f} ms · {c_desc}"
    else:
        summary_note = f"Biosignal recording ({detected_type.upper()}) · Risk index: {physio_risk:.1f}/100"

    # Store upload record
    upload_rec = EEGECGUpload(
        worker_id=worker_id,
        session_id=session_id,
        filename=filename,
        file_type=detected_type,
        classification=classification,
        summary_note=summary_note,
        eeg_features=json.dumps(eeg_features or {}),
        ecg_features=json.dumps(ecg_features or {}),
        physiological_risk_score=physio_risk,
        created_at=datetime.utcnow()
    )
    db.add(upload_rec)
    db.commit()
    db.refresh(upload_rec)

    # If linked to an existing session, re-fuse with physiological risk
    updated_risk_result = None
    if session_id:
        risk_res = db.query(RiskResult).filter(RiskResult.session_id == session_id).first()
        if risk_res:
            existing_flags = json.loads(risk_res.flagged_reasons) if risk_res.flagged_reasons else []
            combined_flags = existing_flags + bio_flags

            fusion = fuse_multimodal_risk(
                concentration_zscore=risk_res.concentration_zscore,
                reaction_zscore=risk_res.reaction_zscore,
                physiological_risk=physio_risk,
                base_flagged_reasons=combined_flags,
                is_baseline_established=risk_res.is_baseline_established
            )
            
            risk_res.physiological_risk = physio_risk
            risk_res.final_risk_score = fusion["final_risk_score"]
            risk_res.classification = fusion["classification"]
            risk_res.confidence_score = fusion["confidence_score"]
            risk_res.flagged_reasons = json.dumps(fusion["flagged_reasons"])
            risk_res.weights_used = json.dumps(fusion["weights_used"])
            db.commit()
            db.refresh(risk_res)
            updated_risk_result = fusion

    return {
        "upload_id": upload_rec.id,
        "filename": filename,
        "detected_type": detected_type,
        "classification": classification,
        "summary_note": summary_note,
        "eeg_features": eeg_features,
        "ecg_features": ecg_features,
        "physiological_risk_score": physio_risk,
        "bio_flags": bio_flags,
        "fused_update": updated_risk_result
    }

@router.get("/history/{worker_id}")
def get_worker_ecg_history(
    worker_id: int,
    db: Session = Depends(get_db),
    current_user: Worker = Depends(get_current_user)
):
    uploads = (
        db.query(EEGECGUpload)
        .filter(EEGECGUpload.worker_id == worker_id)
        .order_by(EEGECGUpload.created_at.desc())
        .all()
    )
    return [
        {
            "id": u.id,
            "filename": u.filename,
            "file_type": u.file_type,
            "classification": u.classification or ("tensed" if u.physiological_risk_score >= 50 else "normal"),
            "summary_note": u.summary_note or "",
            "physiological_risk_score": u.physiological_risk_score,
            "ecg_features": json.loads(u.ecg_features) if u.ecg_features else {},
            "eeg_features": json.loads(u.eeg_features) if u.eeg_features else {},
            "created_at": u.created_at.isoformat(),
        }
        for u in uploads
    ]

@router.post("/demo-load")
def demo_load_signal(
    worker_id: int,
    signal_type: str = "eeg",      # eeg or ecg
    condition: str = "fatigued",   # rested, fatigued, high_stress
    session_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: Worker = Depends(get_current_user)
):
    """Instant simulation of physiological signals for demo / viva walkthrough."""
    signal_arr, fs = generate_synthetic_signal(signal_type, condition)
    
    if signal_type == "eeg":
        eeg_feats = extract_eeg_features(signal_arr, sampling_rate=fs)
        ecg_feats = None
    else:
        eeg_feats = None
        ecg_feats = extract_ecg_features(signal_arr, sampling_rate=fs)

    physio_risk, bio_flags = compute_physiological_risk(eeg_feats, ecg_feats)

    filename = f"simulated_{signal_type}_{condition}.csv"
    upload_rec = EEGECGUpload(
        worker_id=worker_id,
        session_id=session_id,
        filename=filename,
        file_type=signal_type,
        eeg_features=json.dumps(eeg_feats or {}),
        ecg_features=json.dumps(ecg_feats or {}),
        physiological_risk_score=physio_risk,
        created_at=datetime.utcnow()
    )
    db.add(upload_rec)
    db.commit()
    db.refresh(upload_rec)

    # Re-fuse if session provided or find today's latest session
    target_session = None
    if session_id:
        target_session = db.query(DbSession).filter(DbSession.id == session_id).first()
    else:
        target_session = (
            db.query(DbSession)
            .filter(DbSession.worker_id == worker_id)
            .order_by(DbSession.created_at.desc())
            .first()
        )

    fused_info = None
    if target_session:
        risk_res = db.query(RiskResult).filter(RiskResult.session_id == target_session.id).first()
        if risk_res:
            existing_flags = json.loads(risk_res.flagged_reasons) if risk_res.flagged_reasons else []
            combined_flags = list(set(existing_flags + bio_flags))

            fusion = fuse_multimodal_risk(
                concentration_zscore=risk_res.concentration_zscore,
                reaction_zscore=risk_res.reaction_zscore,
                physiological_risk=physio_risk,
                base_flagged_reasons=combined_flags,
                is_baseline_established=risk_res.is_baseline_established
            )
            risk_res.physiological_risk = physio_risk
            risk_res.final_risk_score = fusion["final_risk_score"]
            risk_res.classification = fusion["classification"]
            risk_res.confidence_score = fusion["confidence_score"]
            risk_res.flagged_reasons = json.dumps(fusion["flagged_reasons"])
            risk_res.weights_used = json.dumps(fusion["weights_used"])
            db.commit()
            fused_info = fusion

    return {
        "upload_id": upload_rec.id,
        "filename": filename,
        "signal_type": signal_type,
        "condition": condition,
        "eeg_features": eeg_feats,
        "ecg_features": ecg_feats,
        "physiological_risk_score": physio_risk,
        "bio_flags": bio_flags,
        "fused_update": fused_info,
    }

@router.get("/download-sample/{sample_name}")
def download_sample(sample_name: str):
    """Returns downloadable CSV string for manual upload testing."""
    if "eeg" in sample_name.lower():
        cond = "fatigued" if "fatigue" in sample_name.lower() else "rested"
        sig, _ = generate_synthetic_signal("eeg", cond)
        csv_text = "time_s,eeg_voltage_uv\n" + "\n".join(f"{i/256.0:.4f},{v:.4f}" for i, v in enumerate(sig))
    else:
        cond = "high_stress" if "stress" in sample_name.lower() else "rested"
        sig, _ = generate_synthetic_signal("ecg", cond)
        csv_text = "time_s,ecg_lead_mv\n" + "\n".join(f"{i/250.0:.4f},{v:.4f}" for i, v in enumerate(sig))

    return PlainTextResponse(content=csv_text, media_type="text/csv", headers={"Content-Disposition": f"attachment; filename={sample_name}.csv"})

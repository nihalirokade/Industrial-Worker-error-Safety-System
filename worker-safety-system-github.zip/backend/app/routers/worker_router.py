from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Worker, Session as DbSession, Baseline, RiskResult
from ..schemas import WorkerOut, BaselineOut, SessionOut, RiskResultOut
from ..auth import get_current_user, require_supervisor
from ..baseline_engine import recompute_worker_baseline

router = APIRouter(prefix="/workers", tags=["workers"])

@router.get("/", response_model=List[WorkerOut])
def list_workers(db: Session = Depends(get_db), current_user: Worker = Depends(require_supervisor)):
    return db.query(Worker).filter(Worker.role == "worker").all()

@router.get("/{worker_id}", response_model=WorkerOut)
def get_worker(worker_id: int, db: Session = Depends(get_db), current_user: Worker = Depends(get_current_user)):
    if current_user.role == "worker" and current_user.id != worker_id:
        raise HTTPException(status_code=403, detail="Not authorized to access other worker profile")
    worker = db.query(Worker).filter(Worker.id == worker_id).first()
    if not worker:
        raise HTTPException(status_code=404, detail="Worker not found")
    return worker

@router.get("/{worker_id}/baseline", response_model=BaselineOut)
def get_worker_baseline(worker_id: int, db: Session = Depends(get_db), current_user: Worker = Depends(get_current_user)):
    baseline = db.query(Baseline).filter(Baseline.worker_id == worker_id).first()
    if not baseline:
        baseline = recompute_worker_baseline(db, worker_id)
    return baseline

@router.get("/{worker_id}/history")
def get_worker_history(worker_id: int, limit: int = 15, db: Session = Depends(get_db), current_user: Worker = Depends(get_current_user)):
    sessions = (
        db.query(DbSession)
        .filter(DbSession.worker_id == worker_id)
        .order_by(DbSession.created_at.desc())
        .limit(limit)
        .all()
    )
    
    results = []
    for s in reversed(sessions):
        risk = db.query(RiskResult).filter(RiskResult.session_id == s.id).first()
        results.append({
            "session_id": s.id,
            "created_at": s.created_at.isoformat(),
            "concentration_score": s.concentration_score,
            "accuracy": s.accuracy,
            "commission_errors": s.commission_errors,
            "rt_median_ms": s.rt_median_ms,
            "rt_sd_ms": s.rt_sd_ms,
            "reaction_score": s.reaction_score,
            "final_risk_score": risk.final_risk_score if risk else 0.0,
            "classification": risk.classification if risk else "Safe Operation",
            "concentration_zscore": risk.concentration_zscore if risk else 0.0,
            "reaction_zscore": risk.reaction_zscore if risk else 0.0,
            "physiological_risk": risk.physiological_risk if risk else None,
        })
    return results

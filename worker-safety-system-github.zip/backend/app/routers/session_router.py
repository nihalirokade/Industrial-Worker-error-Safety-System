import json
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Worker, Session as DbSession, RiskResult, Baseline
from ..schemas import BehavioralSessionCreate, SessionOut, RiskResultOut
from ..auth import get_current_user
from ..baseline_engine import score_session_against_baseline, recompute_worker_baseline
from ..risk_classifier import fuse_multimodal_risk

router = APIRouter(prefix="/sessions", tags=["sessions"])

def compute_reaction_score(rt_median_ms: float) -> float:
    # 800ms threshold rule: <= 800ms is PASS, > 800ms is FAIL
    if rt_median_ms <= 200.0:
        return 100.0
    elif rt_median_ms <= 800.0:
        # Scale smoothly between 70.0 and 100.0 for passing latency
        score = 100.0 - ((rt_median_ms - 200.0) / 600.0) * 30.0
        return round(float(max(70.0, min(100.0, score))), 1)
    else:
        # Above 800ms is FAIL: drops from 49 down to 0
        score = 49.0 - ((rt_median_ms - 800.0) / 400.0) * 49.0
        return round(float(max(0.0, score)), 1)

@router.post("/behavioral")
def create_behavioral_session(
    payload: BehavioralSessionCreate,
    db: Session = Depends(get_db),
    current_user: Worker = Depends(get_current_user)
):
    # Verify authorization
    if current_user.role == "worker" and current_user.id != payload.worker_id:
        raise HTTPException(status_code=403, detail="Worker cannot submit data for another operator")

    worker = db.query(Worker).filter(Worker.id == payload.worker_id).first()
    if not worker:
        raise HTTPException(status_code=404, detail="Worker not found")

    reaction_score = compute_reaction_score(payload.rt_median_ms)

    # 1. Evaluate against current baseline
    baseline_eval = score_session_against_baseline(
        db=db,
        worker_id=payload.worker_id,
        concentration_score=payload.concentration_score,
        rt_median_ms=payload.rt_median_ms,
        rt_sd_ms=payload.rt_sd_ms,
        commission_errors=payload.commission_errors,
        anticipatory_clicks=payload.anticipatory_clicks,
        lapse_count=payload.lapse_count
    )

    # 2. Multi-modal score fusion
    fusion_result = fuse_multimodal_risk(
        concentration_zscore=baseline_eval["concentration_zscore"],
        reaction_zscore=baseline_eval["reaction_zscore"],
        physiological_risk=None, # Pure behavioral session
        base_flagged_reasons=baseline_eval["flagged_reasons"],
        is_baseline_established=baseline_eval["is_baseline_established"]
    )

    # 3. Save Session
    db_session = DbSession(
        worker_id=payload.worker_id,
        session_type=payload.session_type,
        concentration_score=payload.concentration_score,
        accuracy=payload.accuracy,
        total_trials=payload.total_trials,
        commission_errors=payload.commission_errors,
        omission_errors=payload.omission_errors,
        rt_median_ms=payload.rt_median_ms,
        rt_sd_ms=payload.rt_sd_ms,
        rt_variability_cv=payload.rt_variability_cv,
        anticipatory_clicks=payload.anticipatory_clicks,
        lapse_count=payload.lapse_count,
        reaction_score=reaction_score,
        error_detection_score=payload.error_detection_score or 0.0,
        error_detection_accuracy=payload.error_detection_accuracy or 0.0,
        error_detection_correct=payload.error_detection_correct or 0,
        error_detection_incorrect=payload.error_detection_incorrect or 0,
        error_detection_avg_response_time=payload.error_detection_avg_response_time or 0.0,
        memory_score=payload.memory_score or 0.0,
        memory_correct=payload.memory_correct or 0,
        memory_incorrect=payload.memory_incorrect or 0,
        memory_avg_response_time=payload.memory_avg_response_time or 0.0,
        memory_max_sequence_length=payload.memory_max_sequence_length or 0,
        raw_trial_data=json.dumps(payload.raw_trial_data or {}),
        created_at=datetime.utcnow()
    )
    db.add(db_session)
    db.commit()
    db.refresh(db_session)

    # 4. Save RiskResult
    risk_result = RiskResult(
        session_id=db_session.id,
        worker_id=payload.worker_id,
        concentration_zscore=baseline_eval["concentration_zscore"],
        reaction_zscore=baseline_eval["reaction_zscore"],
        physiological_risk=None,
        is_baseline_established=baseline_eval["is_baseline_established"],
        final_risk_score=fusion_result["final_risk_score"],
        classification=fusion_result["classification"],
        confidence_score=fusion_result["confidence_score"],
        flagged_reasons=json.dumps(fusion_result["flagged_reasons"]),
        weights_used=json.dumps(fusion_result["weights_used"]),
        status_action="pending",
        created_at=datetime.utcnow()
    )
    db.add(risk_result)
    db.commit()
    db.refresh(risk_result)

    # 5. Update worker baseline with new session included
    updated_baseline = recompute_worker_baseline(db, payload.worker_id)

    return {
        "session_id": db_session.id,
        "worker_id": payload.worker_id,
        "anonymized_id": worker.anonymized_id,
        "concentration_score": db_session.concentration_score,
        "reaction_score": db_session.reaction_score,
        "rt_median_ms": db_session.rt_median_ms,
        "rt_sd_ms": db_session.rt_sd_ms,
        "is_baseline_established": baseline_eval["is_baseline_established"],
        "sessions_recorded": updated_baseline.session_count,
        "concentration_zscore": baseline_eval["concentration_zscore"],
        "reaction_zscore": baseline_eval["reaction_zscore"],
        "final_risk_score": fusion_result["final_risk_score"],
        "classification": fusion_result["classification"],
        "confidence_score": fusion_result["confidence_score"],
        "flagged_reasons": fusion_result["flagged_reasons"],
        "weights_used": fusion_result["weights_used"],
        "risk_components": fusion_result["risk_components"],
        "baseline_snapshot": baseline_eval["baseline_snapshot"],
    }

@router.get("/latest/{worker_id}")
def get_latest_session(worker_id: int, db: Session = Depends(get_db), current_user: Worker = Depends(get_current_user)):
    session = (
        db.query(DbSession)
        .filter(DbSession.worker_id == worker_id)
        .order_by(DbSession.created_at.desc())
        .first()
    )
    if not session:
        return None
    risk = db.query(RiskResult).filter(RiskResult.session_id == session.id).first()
    return {
        "session_id": session.id,
        "created_at": session.created_at.isoformat(),
        "concentration_score": session.concentration_score,
        "reaction_score": session.reaction_score,
        "rt_median_ms": session.rt_median_ms,
        "final_risk_score": risk.final_risk_score if risk else 0.0,
        "classification": risk.classification if risk else "Safe Operation",
        "flagged_reasons": json.loads(risk.flagged_reasons) if risk and risk.flagged_reasons else [],
    }

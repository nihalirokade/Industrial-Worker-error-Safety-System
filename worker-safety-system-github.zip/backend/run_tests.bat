@echo off
cd /d "%~dp0"
echo Running Industrial Safety System Tests...
.venv\Scripts\pytest.exe -v
pause

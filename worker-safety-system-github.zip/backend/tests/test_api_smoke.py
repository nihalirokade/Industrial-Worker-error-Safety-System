import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.database import Base, engine
from app.seed_data import seed_database

@pytest.fixture(scope="module")
def client():
    # Ensure database is seeded
    Base.metadata.create_all(bind=engine)
    seed_database()
    with TestClient(app) as c:
        yield c

def test_health_and_root(client):
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json()["status"] == "healthy"

def test_login_supervisor_and_dashboard(client):
    login_res = client.post("/auth/login", json={"username": "supervisor", "password": "admin123"})
    assert login_res.status_code == 200
    token = login_res.json()["access_token"]
    assert token is not None

    headers = {"Authorization": f"Bearer {token}"}
    dash_res = client.get("/supervisor/dashboard", headers=headers)
    assert dash_res.status_code == 200
    dash_data = dash_res.json()
    assert dash_data["total_workers"] >= 5
    assert "workers" in dash_data
    assert len(dash_data["workers"]) >= 5

def test_submit_behavioral_session_and_fusion(client):
    # Login as worker1
    login_res = client.post("/auth/login", json={"username": "worker1", "password": "worker123"})
    assert login_res.status_code == 200
    token = login_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    payload = {
        "worker_id": 2, # worker1 is id 2 (id 1 is supervisor)
        "session_type": "daily_screening",
        "concentration_score": 86.5,
        "accuracy": 94.0,
        "total_trials": 30,
        "commission_errors": 1,
        "omission_errors": 0,
        "rt_median_ms": 238.0,
        "rt_sd_ms": 36.0,
        "rt_variability_cv": 0.15,
        "anticipatory_clicks": 0,
        "lapse_count": 0,
        "raw_trial_data": {"test": "smoke"}
    }

    res = client.post("/sessions/behavioral", json=payload, headers=headers)
    assert res.status_code == 200
    data = res.json()
    assert "final_risk_score" in data
    assert "classification" in data
    assert "concentration_zscore" in data
    assert "reaction_zscore" in data
    assert "is_baseline_established" in data

def test_simulate_signal_and_fusion(client):
    login_res = client.post("/auth/login", json={"username": "worker1", "password": "worker123"})
    token = login_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # Demo load fatigued EEG
    res = client.post("/signals/demo-load?worker_id=2&signal_type=eeg&condition=fatigued", headers=headers)
    assert res.status_code == 200
    data = res.json()
    assert "eeg_features" in data
    assert data["physiological_risk_score"] > 0
    assert "fatigue_index" in data["eeg_features"]

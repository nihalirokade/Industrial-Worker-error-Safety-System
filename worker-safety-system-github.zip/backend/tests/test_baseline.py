import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.database import Base
from app.models import Worker, Session as DbSession, Baseline
from app.baseline_engine import (
    recompute_worker_baseline,
    score_session_against_baseline,
    POPULATION_NORMS,
    MIN_SESSIONS_FOR_BASELINE
)

@pytest.fixture
def db_session():
    test_engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=test_engine)
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=test_engine)
    session = TestingSessionLocal()
    
    # Create test worker
    worker = Worker(
        anonymized_id="WRK-TEST",
        username="testworker",
        name="Test Worker",
        department="Test Dept",
        role="worker",
        hashed_password="fakehash"
    )
    session.add(worker)
    session.commit()
    session.refresh(worker)

    yield session
    session.close()

def test_cold_start_under_seven_sessions(db_session):
    worker = db_session.query(Worker).first()
    
    # Add 4 sessions (< 7 threshold)
    for _ in range(4):
        s = DbSession(
            worker_id=worker.id,
            concentration_score=85.0,
            rt_median_ms=250.0,
            rt_sd_ms=40.0
        )
        db_session.add(s)
    db_session.commit()

    baseline = recompute_worker_baseline(db_session, worker.id)
    assert baseline.session_count == 4
    assert baseline.is_established is False
    assert baseline.concentration_mean == POPULATION_NORMS["concentration_mean"]
    assert baseline.rt_median_mean == POPULATION_NORMS["rt_median_mean"]

def test_established_baseline_calculation(db_session):
    worker = db_session.query(Worker).first()
    
    # Add 8 sessions (>= 7 threshold) with tight personal performance around RT=220ms, Conc=90
    for _ in range(8):
        s = DbSession(
            worker_id=worker.id,
            concentration_score=90.0,
            rt_median_ms=220.0,
            rt_sd_ms=35.0
        )
        db_session.add(s)
    db_session.commit()

    baseline = recompute_worker_baseline(db_session, worker.id)
    assert baseline.session_count == 8
    assert baseline.is_established is True
    assert baseline.rt_median_mean == pytest.approx(220.0, abs=2.0)
    assert baseline.concentration_mean == pytest.approx(90.0, abs=2.0)

def test_zscore_and_deviation_flagging(db_session):
    worker = db_session.query(Worker).first()
    
    # Seed 10 sessions with mean RT 220ms and SD 15ms
    for _ in range(10):
        s = DbSession(
            worker_id=worker.id,
            concentration_score=90.0,
            rt_median_ms=220.0,
            rt_sd_ms=30.0
        )
        db_session.add(s)
    db_session.commit()

    # Worker has a bad day: RT slows to 300ms (+5.3 SD!) and concentration drops to 65
    res = score_session_against_baseline(
        db=db_session,
        worker_id=worker.id,
        concentration_score=65.0,
        rt_median_ms=300.0,
        rt_sd_ms=80.0,
        commission_errors=5
    )

    assert res["is_baseline_established"] is True
    assert res["reaction_zscore"] > 2.0
    assert res["concentration_zscore"] < -2.0
    assert len(res["flagged_reasons"]) >= 2

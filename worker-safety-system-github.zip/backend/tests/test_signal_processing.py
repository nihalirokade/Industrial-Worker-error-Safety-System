import pytest
import numpy as np
from app.signal_processing import (
    extract_eeg_features,
    extract_ecg_features,
    generate_synthetic_signal,
    parse_signal_file
)

def test_eeg_feature_extraction():
    # Test rested vs fatigued signals
    rested_sig, fs = generate_synthetic_signal("eeg", "rested", duration_sec=10)
    feats_rested = extract_eeg_features(rested_sig, sampling_rate=fs)

    fatigued_sig, fs = generate_synthetic_signal("eeg", "fatigued", duration_sec=10)
    feats_fatigued = extract_eeg_features(fatigued_sig, sampling_rate=fs)

    assert "band_powers" in feats_rested
    assert "fatigue_index" in feats_rested
    assert "theta_beta_ratio" in feats_rested
    
    # Fatigued signal should have significantly higher fatigue index than rested
    assert feats_fatigued["fatigue_index"] > feats_rested["fatigue_index"]

def test_ecg_feature_extraction():
    # Test normal vs high stress ECG
    rested_sig, fs = generate_synthetic_signal("ecg", "rested", duration_sec=15)
    feats_rested = extract_ecg_features(rested_sig, sampling_rate=fs)

    stressed_sig, fs = generate_synthetic_signal("ecg", "high_stress", duration_sec=15)
    feats_stressed = extract_ecg_features(stressed_sig, sampling_rate=fs)

    assert "mean_heart_rate_bpm" in feats_rested
    assert "rmssd_ms" in feats_rested
    assert "sdnn_ms" in feats_rested

    # Stressed condition has elevated HR and reduced RMSSD (parasympathetic suppression)
    assert feats_stressed["mean_heart_rate_bpm"] > feats_rested["mean_heart_rate_bpm"]
    assert feats_stressed["rmssd_ms"] < feats_rested["rmssd_ms"]

def test_signal_file_parser():
    csv_bytes = b"time_s,eeg_voltage_uv\n0.0,0.12\n0.01,-0.34\n0.02,0.56\n"
    arr, detected_type = parse_signal_file(csv_bytes, "eeg_sample.csv")
    assert detected_type == "eeg"
    assert len(arr) == 3

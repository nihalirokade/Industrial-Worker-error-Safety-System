import pytest
from app.risk_classifier import (
    fuse_multimodal_risk,
    compute_physiological_risk,
    ml_classifier_instance
)

def test_behavioral_only_fusion():
    # Safe session: z_conc = +0.5 (above avg), z_rt = -0.4 (faster than avg)
    res = fuse_multimodal_risk(
        concentration_zscore=0.5,
        reaction_zscore=-0.4,
        physiological_risk=None,
        base_flagged_reasons=[]
    )
    assert res["classification"] == "Safe Operation"
    assert res["final_risk_score"] < 45.0
    assert "concentration" in res["weights_used"]
    assert "reaction" in res["weights_used"]
    assert "physiological" not in res["weights_used"]

def test_high_risk_fusion_with_physiological_upload():
    # Impaired session with severe deceleration and high fatigue
    res = fuse_multimodal_risk(
        concentration_zscore=-2.2,
        reaction_zscore=2.5,
        physiological_risk=85.0,
        base_flagged_reasons=["Severe RT deceleration", "High EEG Fatigue Index"],
        is_baseline_established=True
    )
    assert res["classification"] == "High Error Risk"
    assert res["final_risk_score"] >= 70.0
    assert res["confidence_score"] >= 95.0
    assert "physiological" in res["weights_used"]

def test_ml_classifier_predictions():
    # Test ML Random Forest prediction probability
    pred = ml_classifier_instance.predict_risk_proba(
        conc_z=-2.5,
        rt_z=2.5,
        fatigue_idx=4.0,
        rmssd=12.0,
        lf_hf=4.5
    )
    assert "p_high_risk" in pred
    assert pred["p_high_risk"] > pred["p_safe"]

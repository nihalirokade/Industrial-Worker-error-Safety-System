import React, { useState } from 'react';
import { Shield, Lock, User, ArrowRight, Activity, AlertOctagon, CheckCircle } from 'lucide-react';
import { apiClient } from '../api/client';

export const Login = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('supervisor');
  const [password, setPassword] = useState('admin123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e) => {
    if (e) e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const data = await apiClient.login(username, password);
      onLoginSuccess(data);
    } catch (err) {
      setError(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const quickLogin = async (u, p) => {
    setUsername(u);
    setPassword(p);
    setLoading(true);
    setError('');
    try {
      const data = await apiClient.login(u, p);
      onLoginSuccess(data);
    } catch (err) {
      setError(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl mx-auto flex items-center justify-center bg-[#0E1520] text-white shadow-xl">
            <Shield className="w-8 h-8 text-[#D9077E]" />
          </div>
          <h1 className="text-3xl font-black font-headline text-[#0E1520] tracking-tight">
            AEGIS<span className="text-[#D9077E]">-SAFE</span>
          </h1>
          <p className="text-xs text-[#1E444B] font-mono uppercase tracking-wider font-bold">
            Industrial Cognitive Surveillance & Error Prediction
          </p>
        </div>

        {/* Login Form Box */}
        <div className="border-2 border-[#CCEBF0] border-t-4 border-t-[#D9077E] p-6 rounded-3xl bg-white shadow-lg space-y-4">
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-xs font-mono font-bold uppercase tracking-wider text-slate-700 block mb-1">
                Operator ID / Username
              </label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full border border-[#CCEBF0] rounded-xl pl-9 pr-3 py-2.5 text-xs font-mono text-[#0E1520] bg-[#EBF8FA]/40 focus:outline-none focus:border-[#D9077E] focus:ring-1 focus:ring-[#D9077E]"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-mono font-bold uppercase tracking-wider text-slate-700 block mb-1">
                Shift Passcode
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full border border-[#CCEBF0] rounded-xl pl-9 pr-3 py-2.5 text-xs font-mono text-[#0E1520] bg-[#EBF8FA]/40 focus:outline-none focus:border-[#D9077E] focus:ring-1 focus:ring-[#D9077E]"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="text-xs border border-[#F7BFE0] bg-[#FDE8F3] text-[#D9077E] p-2.5 rounded-xl font-mono font-bold">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 font-headline font-black text-xs uppercase tracking-wider rounded-xl flex items-center justify-center gap-2 transition transform active:scale-95 cursor-pointer bg-[#D9077E] hover:bg-[#b8066a] text-white shadow-lg shadow-[#D9077E]/30"
            >
              {loading ? 'Authenticating...' : 'Sign In to Operations Console'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Quick 1-Click Demo Persona Access */}
          <div className="pt-4 border-t border-[#CCEBF0] space-y-2">
            <span className="text-[10px] font-mono font-black uppercase tracking-widest text-[#1E444B] block text-center">
              1-Click Demo Persona Access (Viva Evaluation)
            </span>

            <div className="grid grid-cols-1 gap-2 text-xs">
              <button
                onClick={() => quickLogin('supervisor', 'admin123')}
                className="p-3 rounded-2xl border border-[#CCEBF0] bg-[#D5F5F8]/40 text-left flex items-center justify-between hover:bg-[#D5F5F8] transition cursor-pointer"
              >
                <div>
                  <strong className="block font-headline font-bold text-[#0E1520]">Supervisor Operations Console</strong>
                  <span className="text-[10px] text-slate-500 font-mono">Live plant roster, triage, managerial action panel</span>
                </div>
                <Shield className="w-4 h-4 text-[#D9077E]" />
              </button>

              <button
                onClick={() => quickLogin('worker1', 'worker123')}
                className="p-3 rounded-2xl border border-[#CCEBF0] bg-white text-left flex items-center justify-between hover:bg-[#D5F5F8]/40 transition cursor-pointer"
              >
                <div>
                  <strong className="block font-headline font-bold text-[#0E1520]">Operator Alex (Control Room)</strong>
                  <span className="text-[10px] text-slate-500 font-mono">Established baseline (14 shifts) • Safe Operation</span>
                </div>
                <CheckCircle className="w-4 h-4 text-[#1E444B]" />
              </button>

              <button
                onClick={() => quickLogin('worker2', 'worker123')}
                className="p-3 rounded-2xl border border-[#F7BFE0] bg-[#FDE8F3]/60 text-left flex items-center justify-between hover:bg-[#FDE8F3] transition cursor-pointer"
              >
                <div>
                  <strong className="block font-headline font-bold text-[#0E1520]">Operator Brian (Turbine Deck)</strong>
                  <span className="text-[10px] text-slate-500 font-mono">High Error Risk Anomaly (+2.6 SD slower RT, 5 commission errors)</span>
                </div>
                <AlertOctagon className="w-4 h-4 text-[#D9077E]" />
              </button>

              <button
                onClick={() => quickLogin('worker3', 'worker123')}
                className="p-3 rounded-2xl border border-[#CCEBF0] bg-white text-left flex items-center justify-between hover:bg-[#D5F5F8]/40 transition cursor-pointer"
              >
                <div>
                  <strong className="block font-headline font-bold text-[#0E1520]">Operator Chloe (Avionics Bay)</strong>
                  <span className="text-[10px] text-slate-500 font-mono">Cold-Start Mode (4/7 shifts, population norm fallback)</span>
                </div>
                <Activity className="w-4 h-4 text-[#940D7E]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

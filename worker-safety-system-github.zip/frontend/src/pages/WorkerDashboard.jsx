import React from 'react';
import { 
  ShieldCheck, Heart, Zap, Target, Eye, Hash, ArrowRight, 
  CheckCircle, AlertTriangle, TrendingUp, Calendar, User, Clock, 
  Activity, Award, Sparkles, FileText, ChevronRight
} from 'lucide-react';
import { StatusBadge } from '../components/StatusBadge';

export const WorkerDashboard = ({ user, setView }) => {
  return (
    <div className="space-y-8 font-['Inter'] text-[#111111] animate-fadeIn">
      {/* Editorial Header */}
      <div className="border-b border-[#EAE3D5] pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2 font-['JetBrains_Mono'] text-xs font-bold text-[#821E14] uppercase tracking-wider">
            <span className="w-2 h-2 rounded-full bg-[#821E14]"></span>
            <span>• Operator Command & Shift Clearance Dashboard</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-['Manrope'] font-black text-[#111111] uppercase tracking-tight">
            Main <span className="text-[#821E14]">Dashboard</span>
          </h1>
          <p className="text-xs md:text-sm text-[#666055] mt-1 font-['Inter']">
            Current operational status, readiness metrics, and shift directives for <strong>Operator Alex Turner (WRK-8104)</strong>.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setView('get-started')}
            className="px-3.5 py-1.5 rounded-xl border border-[#EAE3D5] bg-white text-xs font-['JetBrains_Mono'] font-bold text-[#666055] hover:text-[#111111] transition cursor-pointer flex items-center gap-1.5"
          >
            <span>←</span> Introduction / SOP
          </button>
          <span className="px-3.5 py-1.5 rounded-full text-xs font-['JetBrains_Mono'] font-bold bg-[#821E14] text-white">
            Shift A · Active
          </span>
        </div>
      </div>

      {/* OPERATOR PROFILE & LIVE STATUS BANNER */}
      <div className="p-6 md:p-8 rounded-3xl bg-white border-2 border-[#821E14] shadow-md space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[#EAE3D5] pb-5">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl bg-[#5A150D] text-white flex items-center justify-center font-['Manrope'] font-black text-xl shadow-md flex-shrink-0">
              AT
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-['Manrope'] font-black text-2xl text-[#111111]">Operator Alex Turner</span>
                <span className="font-['JetBrains_Mono'] text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#FAF8F5] border border-[#EAE3D5] text-[#821E14]">
                  {user?.anonymized_id || 'WRK-8104'}
                </span>
              </div>
              <p className="text-xs text-[#666055] font-['JetBrains_Mono'] mt-0.5">
                Press & Stamping Division · Shift A (07:00 – 15:30) · Station 04-B
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-4 py-2 rounded-full text-xs font-['JetBrains_Mono'] font-black uppercase tracking-wider bg-[#D5F5F8] text-[#136752] border border-[#CCEBF0] flex items-center gap-1.5 shadow-sm">
              <span className="w-2 h-2 rounded-full bg-[#136752] animate-pulse"></span>
              STATUS: CLEARED FOR SHIFT (94/100)
            </span>
          </div>
        </div>

        {/* 4 Massive Live Operational Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
            <span className="text-[10px] font-['JetBrains_Mono'] uppercase text-[#888173] font-bold block">
              Today's Composite Readiness
            </span>
            <span className="text-3xl md:text-4xl font-['Manrope'] font-black text-[#821E14] block mt-1">
              94 <span className="text-xs font-normal text-[#888173]">/ 100</span>
            </span>
            <span className="text-[10px] font-['JetBrains_Mono'] text-[#136752] font-semibold block mt-0.5">
              ● Optimal Operating Zone
            </span>
          </div>

          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
            <span className="text-[10px] font-['JetBrains_Mono'] uppercase text-[#888173] font-bold block">
              Autonomic Cardiac Strain
            </span>
            <span className="text-3xl md:text-4xl font-['Manrope'] font-black text-[#136752] block mt-1">
              LOW
            </span>
            <span className="text-[10px] font-['JetBrains_Mono'] text-[#888173] block mt-0.5">
              Resting HR 68 BPM · RMSSD 46.2 ms
            </span>
          </div>

          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
            <span className="text-[10px] font-['JetBrains_Mono'] uppercase text-[#888173] font-bold block">
              Reaction Latency (≤800ms)
            </span>
            <span className="text-3xl md:text-4xl font-['Manrope'] font-black text-[#111111] block mt-1">
              215 <span className="text-xs font-normal text-[#888173]">ms</span>
            </span>
            <span className="text-[10px] font-['JetBrains_Mono'] text-[#136752] font-bold block mt-0.5">
              ✓ PASSED (Fast Psychomotor Speed)
            </span>
          </div>

          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
            <span className="text-[10px] font-['JetBrains_Mono'] uppercase text-[#888173] font-bold block">
              Weekly Shift Compliance
            </span>
            <span className="text-3xl md:text-4xl font-['Manrope'] font-black text-[#111111] block mt-1">
              5 / 5
            </span>
            <span className="text-[10px] font-['JetBrains_Mono'] text-[#136752] font-semibold block mt-0.5">
              100% On-Time Protocol (Sep 8–12)
            </span>
          </div>
        </div>

        {/* Operator Action Launchers */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <button
            onClick={() => setView('test')}
            className="p-4 rounded-2xl bg-[#821E14] text-white hover:bg-[#681810] shadow-md transition cursor-pointer flex items-center justify-between group text-left"
          >
            <div>
              <span className="text-[10px] font-['JetBrains_Mono'] uppercase font-bold text-[#FAF8F5]/80 block">
                Pre-Shift Assessment
              </span>
              <strong className="font-['Manrope'] font-black text-sm block mt-0.5">
                Run 2-Min Readiness Check
              </strong>
            </div>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition" />
          </button>

          <button
            onClick={() => setView('ecg')}
            className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5] text-[#111111] hover:border-[#821E14] shadow-sm transition cursor-pointer flex items-center justify-between group text-left"
          >
            <div>
              <span className="text-[10px] font-['JetBrains_Mono'] uppercase font-bold text-[#888173] block">
                Lead II Biosignal
              </span>
              <strong className="font-['Manrope'] font-black text-sm block mt-0.5">
                Ingest ECG Telemetry
              </strong>
            </div>
            <ArrowRight className="w-4 h-4 text-[#821E14] group-hover:translate-x-1 transition" />
          </button>

          <button
            onClick={() => setView('history')}
            className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5] text-[#111111] hover:border-[#821E14] shadow-sm transition cursor-pointer flex items-center justify-between group text-left"
          >
            <div>
              <span className="text-[10px] font-['JetBrains_Mono'] uppercase font-bold text-[#888173] block">
                Separated Shift Logs
              </span>
              <strong className="font-['Manrope'] font-black text-sm block mt-0.5">
                Inspect Separated History
              </strong>
            </div>
            <ArrowRight className="w-4 h-4 text-[#821E14] group-hover:translate-x-1 transition" />
          </button>
        </div>
      </div>

      {/* 3. SUPERVISOR NOTICE & SHIFT AUDIT TRAIL */}
      <div className="p-6 md:p-8 rounded-3xl bg-[#FAF8F5] border-2 border-[#EAE3D5] space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-[#821E14]" />
            <span className="font-['JetBrains_Mono'] text-xs uppercase tracking-wider text-[#821E14] font-bold">
              • Shift Command Operational Note
            </span>
          </div>
          <span className="text-xs font-['JetBrains_Mono'] text-[#666055]">
            Medical Review: Dr. Sarah Vance, MD
          </span>
        </div>

        <blockquote className="font-['Manrope'] font-medium text-sm md:text-base text-[#111111] leading-relaxed italic border-l-4 border-[#821E14] pl-4">
          "Alex Turner (WRK-8104) has maintained optimal readiness parameters following Thursday's mid-week fatigue event. Both psychomotor reaction latencies (215ms) and vagal tone reserve (RMSSD 46.2ms) are within top-tier safety tolerances. Alex is authorized for unsupervised heavy hydraulic stamping operations."
        </blockquote>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-[#EAE3D5] text-xs font-['JetBrains_Mono'] text-[#666055]">
          <span>Station: 04-B (Automated Press Line)</span>
          <span>Shift Command ID: ISO-26262-PLANT-4-SEC-9</span>
        </div>
      </div>
    </div>
  );
};

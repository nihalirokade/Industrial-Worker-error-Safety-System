import React, { useState, useEffect } from 'react';
import { Users, ShieldCheck, AlertTriangle, AlertOctagon, Clock, Activity, ArrowUpRight, Search, CheckCircle } from 'lucide-react';
import { apiClient } from '../api/client';
import { StatusBadge } from '../components/StatusBadge';

export const SupervisorDashboard = ({ onSelectWorker }) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [actionSuccess, setActionSuccess] = useState('');

  const loadDashboard = async () => {
    setLoading(true);
    try {
      const res = await apiClient.getSupervisorDashboard();
      setData(res);
    } catch (err) {
      console.error("Dashboard error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboard();
    const interval = setInterval(loadDashboard, 15000);
    return () => clearInterval(interval);
  }, []);

  const handleActionChange = async (workerId, action) => {
    try {
      await apiClient.updateSupervisorAction(workerId, action);
      setActionSuccess(`Updated action for worker to "${action}"`);
      setTimeout(() => setActionSuccess(''), 3000);
      loadDashboard();
    } catch (err) {
      console.error("Action update failed:", err);
    }
  };

  const filteredWorkers = (data?.workers || []).filter(w => {
    if (filter === 'high_risk' && w.current_classification !== 'High Error Risk') return false;
    if (filter === 'elevated' && w.current_classification !== 'Elevated Monitoring') return false;
    if (filter === 'safe' && w.current_classification !== 'Safe Operation') return false;
    if (filter === 'pending' && w.is_tested_today) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        w.anonymized_id.toLowerCase().includes(q) ||
        w.name.toLowerCase().includes(q) ||
        w.department.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6 font-['Inter']">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-['Manrope'] font-black text-[#0E1520] flex items-center gap-2">
            <Users className="w-6 h-6 text-[#D9077E]" />
            Supervisor Shift Operations Command
          </h1>
          <p className="text-xs font-['JetBrains_Mono'] text-[#1E444B] mt-1">
            Real-time cognitive surveillance, adaptive baseline drift, and error triage · ASIL-D ISO-26262
          </p>
        </div>

        {actionSuccess && (
          <div
            style={{
              backgroundColor: '#D5F5F8',
              borderColor: '#CCEBF0',
              color: '#1E444B',
            }}
            className="text-xs font-['JetBrains_Mono'] font-bold px-3 py-1.5 rounded-xl border flex items-center gap-1.5 animate-in fade-in"
          >
            <CheckCircle className="w-3.5 h-3.5 text-[#1E444B]" />
            {actionSuccess}
          </div>
        )}
      </div>

      {/* KPI Stats Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {/* Total Operators */}
        <div
          style={{
            backgroundColor: '#FFFFFF',
            borderColor: '#CCEBF0',
            boxShadow: '0 4px 15px rgba(14, 21, 32, 0.04)',
          }}
          className="p-4 rounded-2xl border-2"
        >
          <span className="text-[10px] font-['JetBrains_Mono'] font-bold uppercase tracking-wider text-[#1E444B] block">Total Operators</span>
          <span className="text-2xl font-['JetBrains_Mono'] font-black text-[#0E1520]">{data?.total_workers || 0}</span>
          <span className="text-[10px] text-slate-400 block mt-1">Plant workforce</span>
        </div>

        {/* Screened Today */}
        <div
          style={{
            backgroundColor: '#FFFFFF',
            borderColor: '#CCEBF0',
            boxShadow: '0 4px 15px rgba(14, 21, 32, 0.04)',
          }}
          className="p-4 rounded-2xl border-2"
        >
          <span className="text-[10px] font-['JetBrains_Mono'] font-bold uppercase tracking-wider block text-[#1E444B]">Screened Today</span>
          <span className="text-2xl font-['JetBrains_Mono'] font-black text-[#1E444B]">
            {data?.tested_today || 0} <span className="text-xs text-slate-400 font-normal">/ {data?.total_workers || 0}</span>
          </span>
          <span className="text-[10px] text-slate-400 block mt-1">Pre-shift clearance</span>
        </div>

        {/* Safe Operation */}
        <div
          style={{
            backgroundColor: '#D5F5F8',
            borderColor: '#CCEBF0',
            boxShadow: '0 4px 15px rgba(30, 68, 75, 0.06)',
          }}
          className="p-4 rounded-2xl border-2"
        >
          <span className="text-[10px] font-['JetBrains_Mono'] font-bold uppercase tracking-wider block text-[#1E444B]">Safe Operation</span>
          <span className="text-2xl font-['JetBrains_Mono'] font-black text-[#1E444B]">{data?.safe_count || 0}</span>
          <span className="text-[10px] text-[#1E444B] block mt-1">Normal baseline</span>
        </div>

        {/* Elevated Monitoring */}
        <div
          style={{
            backgroundColor: '#FDE8F3',
            borderColor: '#F7BFE0',
            boxShadow: '0 4px 15px rgba(148, 13, 126, 0.08)',
          }}
          className="p-4 rounded-2xl border-2"
        >
          <span className="text-[10px] font-['JetBrains_Mono'] font-bold uppercase tracking-wider block text-[#940D7E]">Elevated Monitoring</span>
          <span className="text-2xl font-['JetBrains_Mono'] font-black text-[#940D7E]">{data?.elevated_count || 0}</span>
          <span className="text-[10px] text-[#940D7E] block mt-1">Mild deviation observed</span>
        </div>

        {/* High Error Risk */}
        <div
          style={{
            backgroundColor: '#FDE8F3',
            borderColor: '#D9077E',
            boxShadow: '0 4px 15px rgba(217, 7, 126, 0.15)',
          }}
          className="p-4 rounded-2xl border-2"
        >
          <span className="text-[10px] font-['JetBrains_Mono'] font-bold uppercase tracking-wider block text-[#D9077E]">High Error Risk</span>
          <span className="text-2xl font-['JetBrains_Mono'] font-black text-[#D9077E]">{data?.high_risk_count || 0}</span>
          <span className="text-[10px] block mt-1 font-bold text-[#D9077E]">Immediate triage</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div
        style={{
          backgroundColor: '#FFFFFF',
          borderColor: '#CCEBF0',
          boxShadow: '0 4px 15px rgba(14, 21, 32, 0.04)',
        }}
        className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-2xl border-2"
      >
        <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto">
          {[
            { key: 'all', label: 'All Operators' },
            { key: 'high_risk', label: 'High Risk Alerts' },
            { key: 'elevated', label: 'Elevated Monitoring' },
            { key: 'safe', label: 'Safe Operation' },
            { key: 'pending', label: 'Pending Screening' },
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key)}
              style={{
                backgroundColor: filter === tab.key ? '#0E1520' : 'transparent',
                color: filter === tab.key ? '#D5F5F8' : '#1E444B',
              }}
              className="px-3.5 py-1.5 rounded-xl text-xs font-['JetBrains_Mono'] font-bold whitespace-nowrap transition cursor-pointer"
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#1E444B]" />
          <input
            type="text"
            placeholder="Search by ID, name, dept..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              backgroundColor: '#EBF8FA',
              borderColor: '#CCEBF0',
            }}
            className="w-full border rounded-xl pl-8 pr-3 py-1.5 text-xs text-[#0E1520] placeholder-[#1E444B]/60 focus:outline-none focus:border-[#D9077E] font-['JetBrains_Mono']"
          />
        </div>
      </div>

      {/* Live Workforce Roster Grid */}
      <div className="space-y-3">
        {filteredWorkers.map(w => {
          const isHighRisk = w.current_classification === 'High Error Risk';
          const isElevated = w.current_classification === 'Elevated Monitoring';

          return (
            <div
              key={w.worker_id}
              style={{
                backgroundColor: isHighRisk ? '#FFF8FB' : '#FFFFFF',
                borderColor: isHighRisk ? '#D9077E' : isElevated ? '#F7BFE0' : '#CCEBF0',
                borderLeft: isHighRisk ? '5px solid #D9077E' : '5px solid #CCEBF0',
                boxShadow: isHighRisk ? '0 8px 25px rgba(217, 7, 126, 0.12)' : '0 2px 10px rgba(14,21,32,0.03)',
              }}
              className="p-5 rounded-3xl border-2 transition-all duration-150"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                {/* Left: Worker Identity */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      style={{
                        backgroundColor: '#D5F5F8',
                        color: '#0E1520',
                        borderColor: '#CCEBF0',
                      }}
                      className="font-['JetBrains_Mono'] text-xs px-2.5 py-0.5 rounded-full font-bold border"
                    >
                      {w.anonymized_id}
                    </span>
                    <span className="text-xs text-[#1E444B] font-medium font-['JetBrains_Mono']">
                      {w.department}
                    </span>
                    {w.baseline_established ? (
                      <span
                        style={{
                          backgroundColor: '#D5F5F8',
                          color: '#1E444B',
                          borderColor: '#CCEBF0',
                        }}
                        className="text-[10px] font-['JetBrains_Mono'] font-bold border px-2 py-0.5 rounded-full"
                      >
                        Established Baseline ({w.session_count} shifts)
                      </span>
                    ) : (
                      <span
                        style={{
                          backgroundColor: '#FDE8F3',
                          color: '#940D7E',
                          borderColor: '#F7BFE0',
                        }}
                        className="text-[10px] font-['JetBrains_Mono'] font-bold border px-2 py-0.5 rounded-full"
                      >
                        Baseline Building ({w.session_count}/7 shifts)
                      </span>
                    )}
                  </div>
                  <h3 className="text-base font-['Manrope'] font-black text-[#0E1520]">{w.name}</h3>
                </div>

                {/* Middle: Shift Metrics & Z-Scores */}
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 text-xs">
                  <div
                    style={{
                      backgroundColor: '#EBF8FA',
                      borderColor: '#CCEBF0',
                    }}
                    className="p-2.5 rounded-xl border text-center"
                  >
                    <span className="text-[10px] text-[#1E444B] uppercase block font-['JetBrains_Mono'] font-bold">Reaction Time</span>
                    <span className="font-['JetBrains_Mono'] font-bold text-[#0E1520]">
                      {w.rt_median_ms ? `${w.rt_median_ms}ms` : '—'}
                    </span>
                    {w.reaction_zscore !== null && (
                      <span
                        style={{ color: w.reaction_zscore > 1.5 ? '#D9077E' : '#1E444B' }}
                        className="text-[10px] font-['JetBrains_Mono'] block font-bold"
                      >
                        {w.reaction_zscore > 0 ? `+${w.reaction_zscore}` : w.reaction_zscore} SD
                      </span>
                    )}
                  </div>

                  <div
                    style={{
                      backgroundColor: '#EBF8FA',
                      borderColor: '#CCEBF0',
                    }}
                    className="p-2.5 rounded-xl border text-center"
                  >
                    <span className="text-[10px] text-[#1E444B] uppercase block font-['JetBrains_Mono'] font-bold">Concentration</span>
                    <span className="font-['JetBrains_Mono'] font-bold text-[#0E1520]">
                      {w.concentration_score !== null ? `${w.concentration_score}` : '—'}
                    </span>
                    {w.concentration_zscore !== null && (
                      <span
                        style={{ color: w.concentration_zscore < -1.5 ? '#D9077E' : '#1E444B' }}
                        className="text-[10px] font-['JetBrains_Mono'] block font-bold"
                      >
                        {w.concentration_zscore > 0 ? `+${w.concentration_zscore}` : w.concentration_zscore} SD
                      </span>
                    )}
                  </div>

                  <div
                    style={{
                      backgroundColor: '#EBF8FA',
                      borderColor: '#CCEBF0',
                    }}
                    className="p-2.5 rounded-xl border text-center"
                  >
                    <span className="text-[10px] text-[#1E444B] uppercase block font-['JetBrains_Mono'] font-bold">Physiological</span>
                    <span className="font-['JetBrains_Mono'] font-bold text-[#1E444B]">
                      {w.physiological_risk !== null ? `${w.physiological_risk}` : 'None'}
                    </span>
                    <span className="text-[10px] text-slate-400 block font-['JetBrains_Mono']">EEG / ECG</span>
                  </div>

                  <div
                    style={{
                      backgroundColor: '#EBF8FA',
                      borderColor: '#CCEBF0',
                    }}
                    className="p-2.5 rounded-xl border text-center"
                  >
                    <span className="text-[10px] text-[#1E444B] uppercase block font-['JetBrains_Mono'] font-bold">Risk Score</span>
                    <span
                      style={{
                        color: w.final_risk_score >= 68 ? '#D9077E' :
                               w.final_risk_score >= 42 ? '#940D7E' :
                               '#1E444B',
                      }}
                      className="font-['JetBrains_Mono'] font-black text-sm"
                    >
                      {w.final_risk_score}
                    </span>
                    <span className="text-[10px] text-slate-400 block font-['JetBrains_Mono']">/ 100</span>
                  </div>
                </div>

                {/* Right: Risk Badge & Managerial Actions */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                  <StatusBadge status={w.current_classification} size="md" />

                  <select
                    value={w.status_action || 'none'}
                    onChange={(e) => handleActionChange(w.worker_id, e.target.value)}
                    style={{
                      backgroundColor: '#FFFFFF',
                      borderColor: '#CCEBF0',
                    }}
                    className="text-[#0E1520] text-xs rounded-xl px-2.5 py-1.5 border focus:outline-none focus:border-[#D9077E] font-['JetBrains_Mono'] font-medium"
                  >
                    <option value="none">Action: None</option>
                    <option value="cleared">Action: Cleared for Shift</option>
                    <option value="rest_advised">Action: Advise 15m Rest</option>
                    <option value="reassigned">Action: Reassign Low Risk</option>
                    <option value="retest_requested">Action: Request Re-test</option>
                  </select>

                  <button
                    onClick={() => onSelectWorker(w.worker_id)}
                    style={{
                      backgroundColor: '#D5F5F8',
                      borderColor: '#CCEBF0',
                      color: '#0E1520',
                    }}
                    className="px-3.5 py-1.5 border rounded-xl text-xs font-['JetBrains_Mono'] font-bold flex items-center gap-1 hover:bg-[#D9077E] hover:text-white transition cursor-pointer"
                  >
                    Diagnostics
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {w.flagged_reasons && w.flagged_reasons.length > 0 && (
                <div className="mt-3 pt-3 border-t border-[#CCEBF0]/50 flex items-start gap-2 text-xs">
                  <AlertOctagon className="w-4 h-4 shrink-0 mt-0.5 text-[#D9077E]" />
                  <div className="flex-1 text-[#D9077E] font-['JetBrains_Mono']">
                    <span className="font-extrabold uppercase text-[10px] tracking-wider mr-2">
                      Surfaced Anomaly Flags:
                    </span>
                    {w.flagged_reasons.join(" • ")}
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {filteredWorkers.length === 0 && (
          <div
            style={{
              backgroundColor: '#FFFFFF',
              borderColor: '#CCEBF0',
            }}
            className="text-center py-12 rounded-3xl border-2"
          >
            <p className="text-sm font-['JetBrains_Mono'] text-[#1E444B]">No operators matching the selected filter.</p>
          </div>
        )}
      </div>
    </div>
  );
};

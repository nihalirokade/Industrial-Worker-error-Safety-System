import React, { useState } from 'react';
import { Upload, FileSpreadsheet, Activity, Sparkles, AlertOctagon, Download } from 'lucide-react';
import { apiClient } from '../api/client';
import { StatusBadge } from '../components/StatusBadge';

export const SignalUpload = ({ user, latestSession, onSignalProcessed }) => {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setError('');
    }
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) {
      setError('Please select a file');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('worker_id', user.worker_id);
      if (latestSession?.session_id) {
        formData.append('session_id', latestSession.session_id);
      }

      const data = await apiClient.uploadSignal(formData);
      setResult(data);
      if (onSignalProcessed) onSignalProcessed(data);
    } catch (err) {
      setError(err.message || 'Failed to process signal');
    } finally {
      setLoading(false);
    }
  };

  const handleSimulate = async (signalType, condition) => {
    setLoading(true);
    setError('');
    try {
      const data = await apiClient.demoLoadSignal(
        user.worker_id,
        signalType,
        condition,
        latestSession?.session_id || null
      );
      setResult(data);
      if (onSignalProcessed) onSignalProcessed(data);
    } catch (err) {
      setError(err.message || 'Simulation failed');
    } finally {
      setLoading(false);
    }
  };

  const downloadSampleFile = (name) => {
    window.open(`/api/signals/download-sample/${name}`, '_blank');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 font-['Inter']">
      <div>
        <h1 className="text-2xl font-['Manrope'] font-black text-[#0E1520] flex items-center gap-2">
          <FileSpreadsheet className="w-6 h-6 text-[#D9077E]" />
          Physiological Signal Processing & Multi-Modal Fusion
        </h1>
        <p className="text-xs font-['JetBrains_Mono'] text-[#1E444B] mt-1 font-medium">
          Upload pre-recorded EEG or ECG signals to extract spectral band-power, heart rate variability, and compute multi-modal error risk.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border-2 border-[#CCEBF0] rounded-3xl p-5 shadow-sm space-y-4 relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1 bg-[#D9077E]" />
            <h2 className="font-['Manrope'] font-bold text-[#0E1520] text-sm flex items-center gap-2">
              <Upload className="w-4 h-4 text-[#D9077E]" />
              Upload Signal Dataset (.csv, .npy)
            </h2>

            <form onSubmit={handleUpload} className="space-y-4">
              <div className="bg-[#EBF8FA] border-2 border-dashed border-[#CCEBF0] hover:border-[#D9077E] rounded-2xl p-6 text-center cursor-pointer transition">
                <input
                  type="file"
                  id="signal-file"
                  accept=".csv,.txt,.npy"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <label htmlFor="signal-file" className="cursor-pointer block">
                  <Activity className="w-8 h-8 mx-auto mb-2 text-[#1E444B]" />
                  <span className="text-xs font-['Manrope'] font-bold text-[#0E1520] block">
                    {file ? file.name : "Click to select EEG/ECG file"}
                  </span>
                  <span className="text-[10px] font-['JetBrains_Mono'] text-[#1E444B] mt-1 block">
                    CSV with time/voltage or single-channel numpy array
                  </span>
                </label>
              </div>

              {error && (
                <div className="bg-[#FDE8F3] border border-[#D9077E] text-[#D9077E] text-xs p-2.5 rounded-xl font-['JetBrains_Mono'] font-bold">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={!file || loading}
                className={`w-full py-3 text-xs font-['Manrope'] font-black rounded-xl transition flex items-center justify-center gap-2 cursor-pointer ${
                  !file || loading
                    ? 'bg-slate-100 border border-slate-200 text-slate-400 cursor-not-allowed'
                    : 'bg-[#D9077E] hover:bg-[#b00566] text-white shadow-md shadow-[#D9077E]/25'
                }`}
              >
                {loading ? 'Processing Spectral Features...' : 'Analyze Uploaded Signal'}
              </button>
            </form>

            <div className="pt-3 border-t border-[#CCEBF0]/60">
              <span className="text-[11px] font-['JetBrains_Mono'] font-bold uppercase tracking-wider text-[#1E444B] block mb-2">
                Download Benchmark Test Files:
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs font-['JetBrains_Mono']">
                <button
                  onClick={() => downloadSampleFile('eeg_fatigued_worker')}
                  className="p-2.5 rounded-xl border border-[#D9077E] bg-[#FDE8F3] text-[#D9077E] hover:bg-[#fbd3ea] transition flex items-center justify-between font-bold cursor-pointer"
                >
                  <span>Fatigued EEG</span>
                  <Download className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => downloadSampleFile('eeg_rested_worker')}
                  className="p-2.5 rounded-xl border border-[#CCEBF0] bg-[#D5F5F8] text-[#1E444B] hover:bg-[#bcebf1] transition flex items-center justify-between font-bold cursor-pointer"
                >
                  <span>Rested EEG</span>
                  <Download className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => downloadSampleFile('ecg_stressed_worker')}
                  className="p-2.5 rounded-xl border border-[#F7BFE0] bg-[#FDE8F3] text-[#940D7E] hover:bg-[#fbd3ea] transition flex items-center justify-between font-bold cursor-pointer"
                >
                  <span>Stressed ECG</span>
                  <Download className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => downloadSampleFile('ecg_normal_worker')}
                  className="p-2.5 rounded-xl border border-[#CCEBF0] bg-[#D5F5F8] text-[#1E444B] hover:bg-[#bcebf1] transition flex items-center justify-between font-bold cursor-pointer"
                >
                  <span>Normal ECG</span>
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white border-2 border-[#CCEBF0] rounded-3xl p-5 shadow-sm space-y-3 relative overflow-hidden">
            <div className="flex items-center gap-2 text-xs font-['JetBrains_Mono'] font-black uppercase tracking-wider text-[#D9077E]">
              <Sparkles className="w-4 h-4 text-[#D9077E]" />
              1-Click Instant Signal Simulation (Viva Demo)
            </div>
            <p className="text-xs text-[#1E444B] font-medium font-['Inter']">
              Instantly feeds synthesized EEG or ECG waveforms through Welch PSD and R-peak pipelines:
            </p>

            <div className="grid grid-cols-2 gap-2 text-xs font-['JetBrains_Mono']">
              <button
                onClick={() => handleSimulate('eeg', 'fatigued')}
                disabled={loading}
                className="p-3 rounded-2xl border border-[#D9077E] bg-[#FDE8F3] text-[#D9077E] font-bold text-left transition hover:bg-[#fbd3ea] cursor-pointer"
              >
                Simulate Fatigued EEG
                <span className="block text-[10px] text-[#940D7E] font-normal mt-0.5">Theta/Beta &gt; 3.0, drowsy</span>
              </button>

              <button
                onClick={() => handleSimulate('eeg', 'rested')}
                disabled={loading}
                className="p-3 rounded-2xl border border-[#CCEBF0] bg-[#D5F5F8] text-[#1E444B] font-bold text-left transition hover:bg-[#bcebf1] cursor-pointer"
              >
                Simulate Rested EEG
                <span className="block text-[10px] text-[#1E444B] font-normal mt-0.5">Dominant 10Hz Alpha</span>
              </button>

              <button
                onClick={() => handleSimulate('ecg', 'high_stress')}
                disabled={loading}
                className="p-3 rounded-2xl border border-[#F7BFE0] bg-[#FDE8F3] text-[#940D7E] font-bold text-left transition hover:bg-[#fbd3ea] cursor-pointer"
              >
                Simulate Stressed ECG
                <span className="block text-[10px] text-[#940D7E] font-normal mt-0.5">Tachycardia, RMSSD 14ms</span>
              </button>

              <button
                onClick={() => handleSimulate('ecg', 'rested')}
                disabled={loading}
                className="p-3 rounded-2xl border border-[#CCEBF0] bg-[#D5F5F8] text-[#1E444B] font-bold text-left transition hover:bg-[#bcebf1] cursor-pointer"
              >
                Simulate Healthy ECG
                <span className="block text-[10px] text-[#1E444B] font-normal mt-0.5">Normal 70bpm, RMSSD 42ms</span>
              </button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-7">
          {result ? (
            <div className="bg-white border-2 border-[#CCEBF0] rounded-3xl p-6 shadow-sm space-y-6 relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#D9077E]" />
              <div className="flex items-center justify-between border-b border-[#CCEBF0]/60 pb-4">
                <div>
                  <span className="text-xs text-[#1E444B] uppercase font-['JetBrains_Mono'] font-bold tracking-wider">Processed Signal Analysis</span>
                  <h3 className="text-lg font-['Manrope'] font-black text-[#0E1520] capitalize">{result.filename || result.detected_type}</h3>
                </div>
                <div className="text-right">
                  <span className="text-xs text-[#1E444B] block font-semibold font-['JetBrains_Mono']">Physiological Risk</span>
                  <span
                    style={{
                      color: result.physiological_risk_score >= 70 ? '#D9077E' :
                             result.physiological_risk_score >= 45 ? '#940D7E' :
                             '#1E444B',
                    }}
                    className="text-3xl font-black font-['JetBrains_Mono']"
                  >
                    {result.physiological_risk_score} <span className="text-xs text-slate-400 font-normal">/ 100</span>
                  </span>
                </div>
              </div>

              {result.bio_flags && result.bio_flags.length > 0 && (
                <div className="bg-[#FDE8F3] border border-[#D9077E] text-[#D9077E] p-4 rounded-2xl text-xs space-y-1.5 font-['JetBrains_Mono']">
                  <div className="font-extrabold uppercase tracking-wider flex items-center gap-1.5 text-[#D9077E]">
                    <AlertOctagon className="w-4 h-4" />
                    Detected Physiological Indicators:
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-[#940D7E] font-medium font-['Inter']">
                    {result.bio_flags.map((bf, i) => (
                      <li key={i}>{bf}</li>
                    ))}
                  </ul>
                </div>
              )}

              {result.eeg_features && (
                <div className="space-y-3">
                  <h4 className="text-xs font-['Manrope'] font-black uppercase tracking-wider text-[#0E1520]">
                    EEG Spectral Power Bands (Welch PSD)
                  </h4>
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                    {Object.entries(result.eeg_features.relative_powers || {}).map(([band, val]) => (
                      <div
                        key={band}
                        className="bg-[#EBF8FA] border border-[#CCEBF0] p-2.5 rounded-xl text-center"
                      >
                        <span className="text-[10px] text-[#1E444B] uppercase block font-['JetBrains_Mono'] font-bold">{band.replace('rel_', '')}</span>
                        <span className="text-sm font-black font-['JetBrains_Mono'] text-[#D9077E]">{(val * 100).toFixed(1)}%</span>
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-3 gap-3 pt-2 font-['JetBrains_Mono']">
                    <div className="bg-[#EBF8FA] border border-[#CCEBF0] p-3.5 rounded-2xl">
                      <span className="text-[10px] text-[#1E444B] uppercase block font-bold">Theta / Beta Ratio</span>
                      <span
                        style={{
                          color: result.eeg_features.theta_beta_ratio >= 3.0 ? '#D9077E' : '#1E444B',
                        }}
                        className="text-xl font-black block mt-1"
                      >
                        {result.eeg_features.theta_beta_ratio}
                      </span>
                      <span className="text-[10px] text-[#1E444B] block mt-0.5">Normal: &lt;2.5</span>
                    </div>

                    <div className="bg-[#EBF8FA] border border-[#CCEBF0] p-3.5 rounded-2xl">
                      <span className="text-[10px] text-[#1E444B] uppercase block font-bold">Fatigue Index (θ+α)/β</span>
                      <span
                        style={{
                          color: result.eeg_features.fatigue_index >= 2.5 ? '#D9077E' : '#1E444B',
                        }}
                        className="text-xl font-black block mt-1"
                      >
                        {result.eeg_features.fatigue_index}
                      </span>
                      <span className="text-[10px] text-[#1E444B] block mt-0.5">Drowsy: &gt;2.5</span>
                    </div>

                    <div className="bg-[#EBF8FA] border border-[#CCEBF0] p-3.5 rounded-2xl">
                      <span className="text-[10px] text-[#1E444B] uppercase block font-bold">Engagement Index</span>
                      <span className="text-xl font-black text-[#D9077E] block mt-1">
                        {result.eeg_features.engagement_index}
                      </span>
                      <span className="text-[10px] text-[#1E444B] block mt-0.5">Cortical arousal</span>
                    </div>
                  </div>
                </div>
              )}

              {result.ecg_features && (
                <div className="space-y-3 font-['JetBrains_Mono']">
                  <h4 className="text-xs font-['Manrope'] font-black uppercase tracking-wider text-[#0E1520]">
                    Heart Rate Variability & Autonomic Metrics
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="bg-[#EBF8FA] border border-[#CCEBF0] p-3.5 rounded-2xl">
                      <span className="text-[10px] text-[#1E444B] uppercase block font-bold">Mean Heart Rate</span>
                      <span className="text-xl font-black text-[#0E1520] block mt-1">
                        {result.ecg_features.mean_heart_rate_bpm} <span className="text-xs text-slate-500 font-normal">bpm</span>
                      </span>
                    </div>

                    <div className="bg-[#EBF8FA] border border-[#CCEBF0] p-3.5 rounded-2xl">
                      <span className="text-[10px] text-[#1E444B] uppercase block font-bold">RMSSD (Vagal Tone)</span>
                      <span
                        style={{
                          color: result.ecg_features.rmssd_ms < 20 ? '#D9077E' : '#1E444B',
                        }}
                        className="text-xl font-black block mt-1"
                      >
                        {result.ecg_features.rmssd_ms} <span className="text-xs text-slate-500 font-normal">ms</span>
                      </span>
                    </div>

                    <div className="bg-[#EBF8FA] border border-[#CCEBF0] p-3.5 rounded-2xl">
                      <span className="text-[10px] text-[#1E444B] uppercase block font-bold">SDNN (Total HRV)</span>
                      <span className="text-xl font-black text-[#0E1520] block mt-1">
                        {result.ecg_features.sdnn_ms} <span className="text-xs text-slate-500 font-normal">ms</span>
                      </span>
                    </div>

                    <div className="bg-[#EBF8FA] border border-[#CCEBF0] p-3.5 rounded-2xl">
                      <span className="text-[10px] text-[#1E444B] uppercase block font-bold">LF / HF Ratio</span>
                      <span
                        style={{
                          color: result.ecg_features.lf_hf_ratio > 3.0 ? '#D9077E' : '#1E444B',
                        }}
                        className="text-xl font-black block mt-1"
                      >
                        {result.ecg_features.lf_hf_ratio}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {result.fused_update && (
                <div className="bg-[#D5F5F8] border border-[#CCEBF0] p-4 rounded-2xl space-y-3 pt-4 font-['JetBrains_Mono']">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase tracking-wider text-[#0E1520]">
                      Tri-Modal Dynamic Fusion Updated
                    </span>
                    <StatusBadge status={result.fused_update.classification} />
                  </div>
                  <div className="flex items-center justify-between text-xs text-[#0E1520]">
                    <span>New Composite Risk Score: <strong className="font-bold">{result.fused_update.final_risk_score} / 100</strong></span>
                    <span>Confidence: <strong className="font-bold">{result.fused_update.confidence_score}%</strong></span>
                  </div>
                  <div className="text-[11px] text-[#1E444B]">
                    Renormalized Weights: Conc ({result.fused_update.weights_used?.concentration || 0.35}), RT ({result.fused_update.weights_used?.reaction || 0.25}), Bio ({result.fused_update.weights_used?.physiological || 0.40})
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="h-full min-h-[380px] flex flex-col items-center justify-center p-8 border-2 border-dashed border-[#CCEBF0] bg-white rounded-3xl text-center shadow-sm">
              <Activity className="w-12 h-12 mb-3 text-[#1E444B]" />
              <h3 className="text-base font-['Manrope'] font-bold text-[#0E1520]">No Signal Analyzed Yet</h3>
              <p className="text-xs font-['Inter'] text-[#1E444B] max-w-sm mt-1">
                Upload a CSV/NPY recording from the left panel or click any instant simulation button to extract neuro-cardiac biomarkers.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

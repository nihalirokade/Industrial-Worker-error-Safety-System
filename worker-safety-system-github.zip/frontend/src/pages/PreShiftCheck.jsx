import React, { useState, useEffect, useRef } from 'react';
import { 
  CheckCircle, AlertTriangle, RotateCcw, Clock, Target, 
  Zap, Eye, Hash, ArrowRight, ShieldCheck, AlertOctagon, Sparkles 
} from 'lucide-react';
import { apiClient } from '../api/client';
import { StatusBadge } from '../components/StatusBadge';

// Gauge parameters pool for Error Detection ("Spot the Change")
const GAUGE_POOL = [
  { key: 'Temperature', unit: '°C', baseMin: 55, baseMax: 85, delta: 14 },
  { key: 'Pressure', unit: 'bar', baseMin: 4.0, baseMax: 8.5, delta: 2.8 },
  { key: 'RPM Speed', unit: 'RPM', baseMin: 1100, baseMax: 1850, delta: 350 },
  { key: 'Vibration', unit: 'mm/s', baseMin: 1.2, baseMax: 3.4, delta: 1.6 },
];

export const PreShiftCheck = ({ user, onSessionSaved }) => {
  // Steps: 
  // 'intro' -> 'part1_gng' -> 'trans_to_rt' -> 'part2_rt' -> 
  // 'trans_to_ed' -> 'part3_ed' -> 'trans_to_mem' -> 'part4_mem' -> 'results'
  const [step, setStep] = useState('intro');

  // ==========================================
  // Test 1: Concentration (Go / No-Go)
  // ==========================================
  const [gngTrialIdx, setGngTrialIdx] = useState(0);
  const [gngStimulus, setGngStimulus] = useState(null); // 'GO' | 'NOGO'
  const [gngFeedback, setGngFeedback] = useState(null);
  const gngTrialsRef = useRef([]);
  const gngStartTimeRef = useRef(0);
  const gngRespondedRef = useRef(false);
  const gngTimerRef = useRef(null);
  const gngLogsRef = useRef([]);

  // ==========================================
  // Test 2: Reaction Time (Simple RT, 10 trials)
  // Target: Tap within 800ms. <= 800ms per click = PASS, > 800ms = FAIL. Average computed across trials.
  // ==========================================
  const [rtTrialIdx, setRtTrialIdx] = useState(0);
  const [rtPhase, setRtPhase] = useState('waiting'); // 'waiting', 'triggered', 'too_soon', 'responded'
  const [currentRtMs, setCurrentRtMs] = useState(null);
  const [currentRtPass, setCurrentRtPass] = useState(null); // true if <= 800ms, false if > 800ms
  const rtStartTimeRef = useRef(0);
  const rtTimerRef = useRef(null);
  const rtTimeoutRef = useRef(null);
  const rtLogsRef = useRef([]);

  // ==========================================
  // Test 3: Error Detection ("Spot the Change", 8 rounds)
  // ==========================================
  const [edRound, setEdRound] = useState(1);
  const [edPhase, setEdPhase] = useState('observe'); // 'observe' | 'hidden' | 'inspect' | 'answered'
  const [edInitialGauges, setEdInitialGauges] = useState([]);
  const [edChangedGauges, setEdChangedGauges] = useState([]);
  const [edTargetChangedKey, setEdTargetChangedKey] = useState('');
  const [edSelectedAnswer, setEdSelectedAnswer] = useState(null);
  const [edFeedback, setEdFeedback] = useState(null);
  const edStartTimeRef = useRef(0);
  const edLogsRef = useRef([]);

  // ==========================================
  // Test 4: Memory Test ("Number Recall", 6 rounds)
  // ==========================================
  const [memRound, setMemRound] = useState(1);
  const [memPhase, setMemPhase] = useState('display'); // 'display' | 'recall' | 'feedback'
  const [memSequence, setMemSequence] = useState([]);
  const [memInput, setMemInput] = useState('');
  const [memFeedback, setMemFeedback] = useState(null);
  const memStartTimeRef = useRef(0);
  const memLogsRef = useRef([]);

  // ==========================================
  // Final Combined Results
  // ==========================================
  const [resultsData, setResultsData] = useState(null);
  const [recentAverage, setRecentAverage] = useState(null);

  // Fetch recent baseline average for worker
  useEffect(() => {
    const fetchRecentAvg = async () => {
      try {
        const history = await apiClient.getWorkerHistory(user?.worker_id || 2);
        if (history && history.length > 0) {
          const sum = history.slice(0, 5).reduce((acc, s) => {
            const sc = s.risk_result ? (100 - s.risk_result.final_risk_score) : (s.concentration_score || 80);
            return acc + sc;
          }, 0);
          setRecentAverage(Math.round(sum / Math.min(history.length, 5)));
        } else {
          setRecentAverage(82);
        }
      } catch (err) {
        setRecentAverage(82);
      }
    };
    fetchRecentAvg();
  }, [user]);

  // ---------------------------------------------------------------------------
  // Test 1 Logic: Go / No-Go (22 trials)
  // ---------------------------------------------------------------------------
  const initGngSequence = () => {
    const list = [];
    for (let i = 0; i < 18; i++) list.push('GO');
    for (let i = 0; i < 4; i++) list.push('NOGO');
    for (let i = list.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [list[i], list[j]] = [list[j], list[i]];
    }
    if (list[0] === 'NOGO') list[0] = 'GO';
    gngTrialsRef.current = list;
    gngLogsRef.current = [];
  };

  const startPart1 = () => {
    initGngSequence();
    setStep('part1_gng');
    nextGngTrial(0);
  };

  const nextGngTrial = (idx) => {
    if (idx >= gngTrialsRef.current.length) {
      setStep('trans_to_rt');
      return;
    }
    setGngTrialIdx(idx);
    setGngFeedback(null);
    setGngStimulus(null);
    gngRespondedRef.current = false;

    if (gngTimerRef.current) clearTimeout(gngTimerRef.current);
    gngTimerRef.current = setTimeout(() => {
      showGngStimulus(idx);
    }, 850);
  };

  const showGngStimulus = (idx) => {
    const sType = gngTrialsRef.current[idx];
    setGngStimulus(sType);
    gngStartTimeRef.current = performance.now();

    if (gngTimerRef.current) clearTimeout(gngTimerRef.current);
    gngTimerRef.current = setTimeout(() => {
      if (!gngRespondedRef.current) {
        const rt = Math.round(performance.now() - gngStartTimeRef.current);
        const outcome = sType === 'GO' ? 'OMISSION' : 'CORRECT_REJECTION';
        gngLogsRef.current.push({ trial: idx + 1, type: sType, responded: false, rt, outcome });
        if (outcome === 'OMISSION') setGngFeedback('MISSED ✗');
        setTimeout(() => nextGngTrial(idx + 1), 300);
      }
    }, 750);
  };

  const handleGngTap = () => {
    if (!gngStimulus || gngRespondedRef.current) return;
    gngRespondedRef.current = true;
    const rt = Math.round(performance.now() - gngStartTimeRef.current);
    if (gngTimerRef.current) clearTimeout(gngTimerRef.current);

    const sType = gngTrialsRef.current[gngTrialIdx];
    const outcome = sType === 'GO' ? 'HIT' : 'COMMISSION';
    gngLogsRef.current.push({ trial: gngTrialIdx + 1, type: sType, responded: true, rt, outcome });
    setGngFeedback(outcome === 'HIT' ? 'HIT ✓' : 'NO-GO PRESSED ✗');
    setTimeout(() => nextGngTrial(gngTrialIdx + 1), 400);
  };

  // ---------------------------------------------------------------------------
  // Test 2 Logic: Simple Reaction Time (10 trials)
  // ---------------------------------------------------------------------------
  useEffect(() => {
    if (step === 'trans_to_rt') {
      const timer = setTimeout(() => {
        setStep('part2_rt');
        setRtTrialIdx(1);
        rtLogsRef.current = [];
        startRtTrial();
      }, 1600);
      return () => clearTimeout(timer);
    }
  }, [step]);

  const startRtTrial = () => {
    if (rtTimeoutRef.current) clearTimeout(rtTimeoutRef.current);
    if (rtTimerRef.current) clearTimeout(rtTimerRef.current);
    setRtPhase('waiting');
    setCurrentRtMs(null);
    setCurrentRtPass(null);

    const delay = 700 + Math.random() * 1600;
    rtTimerRef.current = setTimeout(() => {
      rtStartTimeRef.current = performance.now();
      setRtPhase('triggered');

      // Auto-fail timeout if user does not tap within 1500ms (>800ms threshold)
      rtTimeoutRef.current = setTimeout(() => {
        handleRtTimeout();
      }, 1500);
    }, delay);
  };

  const handleRtTimeout = () => {
    const elapsed = 1500;
    setCurrentRtMs(elapsed);
    setCurrentRtPass(false);
    setRtPhase('responded');
    rtLogsRef.current.push({ trial: rtTrialIdx, rt: elapsed, passed: false, isTimeout: true });

    setTimeout(() => {
      if (rtTrialIdx >= 10) {
        setStep('trans_to_ed');
      } else {
        setRtTrialIdx(prev => prev + 1);
        startRtTrial();
      }
    }, 650);
  };

  const handleRtTap = () => {
    if (rtPhase === 'waiting') {
      if (rtTimerRef.current) clearTimeout(rtTimerRef.current);
      if (rtTimeoutRef.current) clearTimeout(rtTimeoutRef.current);
      setRtPhase('too_soon');
      setTimeout(() => startRtTrial(), 900);
      return;
    }
    if (rtPhase === 'triggered') {
      if (rtTimeoutRef.current) clearTimeout(rtTimeoutRef.current);
      const rt = Math.round(performance.now() - rtStartTimeRef.current);
      // <= 800ms per click is PASS; > 800ms per click is FAIL
      const passed = rt <= 800;
      setCurrentRtMs(rt);
      setCurrentRtPass(passed);
      setRtPhase('responded');
      rtLogsRef.current.push({ trial: rtTrialIdx, rt, passed, isTimeout: false });

      setTimeout(() => {
        if (rtTrialIdx >= 10) {
          setStep('trans_to_ed');
        } else {
          setRtTrialIdx(prev => prev + 1);
          startRtTrial();
        }
      }, 550);
    }
  };

  // Keyboard Spacebar listener for rapid reaction time taps and Go/No-Go
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.code === 'Space' || e.key === ' ') {
        e.preventDefault();
        if (step === 'part1_gng') {
          handleGngTap();
        } else if (step === 'part2_rt') {
          handleRtTap();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [step, gngStimulus, rtPhase]);

  // ---------------------------------------------------------------------------
  // Test 3 Logic: Error Detection ("Spot the Change", 8 rounds)
  // ---------------------------------------------------------------------------
  useEffect(() => {
    if (step === 'trans_to_ed') {
      const timer = setTimeout(() => {
        setStep('part3_ed');
        setEdRound(1);
        edLogsRef.current = [];
        generateEdRound(1);
      }, 1600);
      return () => clearTimeout(timer);
    }
  }, [step]);

  const generateEdRound = (roundNum) => {
    setEdPhase('observe');
    setEdSelectedAnswer(null);
    setEdFeedback(null);

    // Generate random values for all 4 parameters
    const initial = GAUGE_POOL.map(g => {
      const val = g.unit === 'bar' || g.unit === 'mm/s'
        ? (g.baseMin + Math.random() * (g.baseMax - g.baseMin)).toFixed(1)
        : Math.round(g.baseMin + Math.random() * (g.baseMax - g.baseMin));
      return { key: g.key, unit: g.unit, val };
    });

    // Pick 1 parameter to change
    const targetIdx = Math.floor(Math.random() * initial.length);
    const target = initial[targetIdx];
    setEdTargetChangedKey(target.key);

    const changed = initial.map((g, idx) => {
      if (idx !== targetIdx) return { ...g };
      const delta = (Math.random() > 0.5 ? 1 : -1) * (
        g.unit === 'bar' || g.unit === 'mm/s' ? (1.5 + Math.random() * 2.0).toFixed(1) : Math.round(15 + Math.random() * 25)
      );
      let newVal = parseFloat(g.val) + parseFloat(delta);
      if (newVal <= 0) newVal = Math.abs(newVal) + 5;
      const formatted = g.unit === 'bar' || g.unit === 'mm/s' ? Number(newVal).toFixed(1) : Math.round(newVal);
      return { key: g.key, unit: g.unit, val: formatted };
    });

    setEdInitialGauges(initial);
    setEdChangedGauges(changed);

    // Display initial panel for 2.6s, then hide briefly
    setTimeout(() => {
      setEdPhase('hidden');
      setTimeout(() => {
        setEdPhase('inspect');
        edStartTimeRef.current = performance.now();
      }, 550);
    }, 2600);
  };

  const handleEdSubmit = (selectedKey) => {
    if (edPhase !== 'inspect') return;
    const rt = Math.round(performance.now() - edStartTimeRef.current);
    const isCorrect = selectedKey === edTargetChangedKey;

    setEdSelectedAnswer(selectedKey);
    setEdPhase('answered');
    setEdFeedback(isCorrect ? 'CORRECT! ✓' : `INCORRECT! Was ${edTargetChangedKey}`);

    edLogsRef.current.push({
      round: edRound,
      targetKey: edTargetChangedKey,
      selectedKey,
      isCorrect,
      rt
    });

    setTimeout(() => {
      if (edRound >= 8) {
        setStep('trans_to_mem');
      } else {
        setEdRound(prev => prev + 1);
        generateEdRound(edRound + 1);
      }
    }, 1100);
  };

  // ---------------------------------------------------------------------------
  // Test 4 Logic: Memory Test ("Number Recall", 6 rounds)
  // ---------------------------------------------------------------------------
  useEffect(() => {
    if (step === 'trans_to_mem') {
      const timer = setTimeout(() => {
        setStep('part4_mem');
        setMemRound(1);
        memLogsRef.current = [];
        generateMemRound(1);
      }, 1600);
      return () => clearTimeout(timer);
    }
  }, [step]);

  const generateMemRound = (roundNum) => {
    setMemPhase('display');
    setMemInput('');
    setMemFeedback(null);

    // Progressive length: 4 digits (rounds 1-2), 5 digits (round 3), 6 digits (round 4), 7 digits (rounds 5-6)
    const len = roundNum <= 2 ? 4 : roundNum <= 4 ? 5 : 6;
    const seq = [];
    for (let i = 0; i < len; i++) {
      seq.push(Math.floor(Math.random() * 9) + 1);
    }
    setMemSequence(seq);

    // Display sequence for 2.8 seconds, then hide
    setTimeout(() => {
      setMemPhase('recall');
      memStartTimeRef.current = performance.now();
    }, 2800);
  };

  const handleMemKey = (val) => {
    if (memPhase !== 'recall') return;
    if (val === 'DEL') {
      setMemInput(prev => prev.slice(0, -1));
    } else {
      if (memInput.length < memSequence.length + 2) {
        setMemInput(prev => prev + val);
      }
    }
  };

  const handleMemSubmit = () => {
    if (memPhase !== 'recall' || memInput.length === 0) return;
    const rt = Math.round(performance.now() - memStartTimeRef.current);
    const targetStr = memSequence.join('');
    const isCorrect = memInput.trim() === targetStr;

    // Calculate correctly recalled matching positions
    let correctDigits = 0;
    for (let i = 0; i < Math.min(memInput.length, memSequence.length); i++) {
      if (memInput[i] === String(memSequence[i])) correctDigits++;
    }

    setMemPhase('feedback');
    setMemFeedback(isCorrect ? 'PERFECT RECALL! ✓' : `Sequence was: ${targetStr}`);

    memLogsRef.current.push({
      round: memRound,
      sequenceLength: memSequence.length,
      target: targetStr,
      entered: memInput,
      isCorrect,
      correctDigits,
      rt
    });

    setTimeout(() => {
      if (memRound >= 6) {
        computeAndSaveAllResults();
      } else {
        setMemRound(prev => prev + 1);
        generateMemRound(memRound + 1);
      }
    }, 1200);
  };

  // ---------------------------------------------------------------------------
  // Compute Final Multi-Test Score & Persist
  // ---------------------------------------------------------------------------
  const computeAndSaveAllResults = async () => {
    // 1. Concentration Score
    const gng = gngLogsRef.current;
    const totalGng = gng.length || 22;
    const hits = gng.filter(t => t.outcome === 'HIT').length;
    const crs = gng.filter(t => t.outcome === 'CORRECT_REJECTION').length;
    const commissions = gng.filter(t => t.outcome === 'COMMISSION').length;
    const omissions = gng.filter(t => t.outcome === 'OMISSION').length;
    const baseAcc = ((hits + crs) / totalGng) * 100;
    const concScore = Math.max(0, Math.min(100, Math.round(baseAcc - (commissions * 5.0))));

    // 2. Reaction Time Score
    // Rule: <= 800ms per click is PASS, > 800ms is FAIL. Take average across all clicks.
    const rtEntries = rtLogsRef.current;
    const rtTotal = rtEntries.length || 10;
    const rtRts = rtEntries.map(e => (typeof e === 'number' ? e : e.rt));
    const rtPassedClicks = rtEntries.filter(e => (typeof e === 'number' ? e <= 800 : e.passed)).length;
    const rtFailedClicks = rtTotal - rtPassedClicks;
    const rtPassRate = Math.round((rtPassedClicks / rtTotal) * 100);

    const sortedRts = rtRts.slice().sort((a, b) => a - b);
    const mid = Math.floor(sortedRts.length / 2);
    const medianRt = sortedRts.length ? (sortedRts.length % 2 !== 0 ? sortedRts[mid] : Math.round((sortedRts[mid - 1] + sortedRts[mid]) / 2)) : 240;
    const avgRt = rtRts.length ? Math.round(rtRts.reduce((a, b) => a + b, 0) / rtRts.length) : 240;
    const sdRt = rtRts.length > 1
      ? Math.round(Math.sqrt(rtRts.reduce((acc, v) => acc + Math.pow(v - avgRt, 2), 0) / (rtRts.length - 1)))
      : 30;

    // Reaction Score based on average RT & 800ms threshold:
    // If avgRt <= 800ms: PASS (scaled between 70 and 100 based on speed & pass rate)
    // If avgRt > 800ms: FAIL (drops below 50)
    let reactionScore;
    if (avgRt <= 800) {
      const speedBonus = Math.round(Math.max(0, (800 - avgRt) / 600) * 30);
      reactionScore = Math.max(70, Math.min(100, Math.round((rtPassRate * 0.7) + speedBonus)));
    } else {
      reactionScore = Math.max(0, Math.min(49, Math.round(50 - ((avgRt - 800) / 400) * 50)));
    }

    // 3. Error Detection Score ("Spot the Change")
    const edLogs = edLogsRef.current;
    const edTotal = edLogs.length || 8;
    const edCorrect = edLogs.filter(l => l.isCorrect).length;
    const edIncorrect = edTotal - edCorrect;
    const edAccuracy = Math.round((edCorrect / edTotal) * 100);
    const edAvgRt = edLogs.length ? Math.round(edLogs.reduce((a, b) => a + b.rt, 0) / edLogs.length) : 2100;
    const edScore = Math.max(0, Math.min(100, Math.round(edAccuracy * 0.85 + Math.max(0, (3500 - edAvgRt) / 3500) * 15)));

    // 4. Memory Test Score ("Number Recall")
    const memLogs = memLogsRef.current;
    const memTotal = memLogs.length || 6;
    const memCorrect = memLogs.filter(l => l.isCorrect).length;
    const memIncorrect = memTotal - memCorrect;
    const memAvgRt = memLogs.length ? Math.round(memLogs.reduce((a, b) => a + b.rt, 0) / memLogs.length) : 3200;
    const maxSeqRemembered = memLogs.filter(l => l.isCorrect).reduce((max, l) => Math.max(max, l.sequenceLength), 0) || 4;
    const memScore = Math.max(0, Math.min(100, Math.round((memCorrect / memTotal) * 80 + (maxSeqRemembered / 6) * 20)));

    // Overall Composite Readiness Score (Weighted)
    // 30% Concentration + 30% Reaction + 20% Error Detection + 20% Memory
    const overallReadiness = Math.round(
      0.30 * concScore + 
      0.30 * reactionScore + 
      0.20 * edScore + 
      0.20 * memScore
    );

    let verdict = 'Cleared for Shift';
    if (overallReadiness < 50) verdict = 'High Error Risk';
    else if (overallReadiness < 75) verdict = 'Proceed with Caution';

    const payload = {
      score: overallReadiness,
      verdict,
      concScore,
      reactionScore,
      medianRt,
      avgRt,
      rtPassedClicks,
      rtFailedClicks,
      rtPassRate,
      rtTotalCount: rtTotal,
      isRtPassed: avgRt <= 800,
      sdRt,
      commissions,
      omissions,
      // Error Detection
      edScore,
      edAccuracy,
      edCorrect,
      edIncorrect,
      edAvgRt,
      // Memory
      memScore,
      memCorrect,
      memIncorrect,
      memAvgRt,
      maxSeqRemembered,
    };

    setResultsData(payload);
    setStep('results');

    // Persist to backend database
    try {
      await apiClient.createBehavioralSession({
        worker_id: user?.worker_id || 2,
        concentration_score: concScore,
        accuracy: baseAcc,
        total_trials: totalGng,
        commission_errors: commissions,
        omission_errors: omissions,
        rt_median_ms: avgRt, // Store average RT (target: <= 800ms)
        rt_sd_ms: sdRt,
        error_detection_score: edScore,
        error_detection_accuracy: edAccuracy,
        error_detection_correct: edCorrect,
        error_detection_incorrect: edIncorrect,
        error_detection_avg_response_time: edAvgRt,
        memory_score: memScore,
        memory_correct: memCorrect,
        memory_incorrect: memIncorrect,
        memory_avg_response_time: memAvgRt,
        memory_max_sequence_length: maxSeqRemembered,
        raw_trial_data: {
          gng_trials: gng,
          rt_trials: rts,
          error_detection_trials: edLogs,
          memory_trials: memLogs,
        }
      });
      if (onSessionSaved) onSessionSaved();
    } catch (err) {
      console.warn('Offline session save:', err);
    }
  };

  const deltaVsAvg = resultsData && recentAverage !== null ? resultsData.score - recentAverage : 0;

  return (
    <div className="max-w-4xl mx-auto space-y-6 font-['Inter'] text-[#111111]">
      {/* ------------------------------------------------------------------ */}
      {/* INTRO SCREEN */}
      {/* ------------------------------------------------------------------ */}
      {step === 'intro' && (
        <div className="bg-[#FFFFFF] border-2 border-[#EAE3D5] rounded-3xl p-8 shadow-sm space-y-6">
          <div className="border-b border-[#EAE3D5] pb-5">
            <div className="flex items-center gap-2 mb-2 font-['JetBrains_Mono'] text-xs font-bold text-[#821E14] uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-[#821E14]"></span>
              <span>• Integrated Worker Safety Protocol</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-['Manrope'] font-black text-[#111111] uppercase tracking-tight">
              Pre-Shift Readiness Check
            </h1>
            <p className="text-xs md:text-sm text-[#666055] mt-1 font-['Inter']">
              Standardized 4-stage behavioral battery evaluating executive control, psychomotor latency, anomaly detection, and short-term sequence recall.
            </p>
          </div>

          {/* 4 Test Pillars Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-['Inter']">
            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
              <div className="flex items-center gap-2 font-['Manrope'] font-bold text-sm text-[#111111]">
                <Target className="w-4 h-4 text-[#821E14]" />
                1. Concentration (Go / No-Go)
              </div>
              <p className="text-xs text-[#666055] mt-1">
                22 rapid discrimination trials (~38s). Tap on GO, suppress tap on NO-GO to measure impulse inhibition.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
              <div className="flex items-center gap-2 font-['Manrope'] font-bold text-sm text-[#111111]">
                <Zap className="w-4 h-4 text-[#821E14]" />
                2. Reaction Time (≤800ms Per Click)
              </div>
              <p className="text-xs text-[#666055] mt-1">
                10 trials (~25s). Tap within 800ms upon signal flash (≤800ms per click = PASS, &gt;800ms = FAIL). Average reaction speed is computed.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
              <div className="flex items-center gap-2 font-['Manrope'] font-bold text-sm text-[#111111]">
                <Eye className="w-4 h-4 text-[#821E14]" />
                3. Error Detection ("Spot the Change")
              </div>
              <p className="text-xs text-[#666055] mt-1">
                8 rounds (~45s). Observe 4 industrial telemetry values and identify which single reading changed.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
              <div className="flex items-center gap-2 font-['Manrope'] font-bold text-sm text-[#111111]">
                <Hash className="w-4 h-4 text-[#821E14]" />
                4. Memory Test ("Number Recall")
              </div>
              <p className="text-xs text-[#666055] mt-1">
                6 rounds (~45s). Recall progressive numeric sequences to assess working memory under operational strain.
              </p>
            </div>
          </div>

          <div className="pt-3 border-t border-[#EAE3D5] flex items-center justify-between">
            <span className="text-xs font-['JetBrains_Mono'] text-[#888173]">
              TOTAL ESTIMATED TIME: ~2.5 MINUTES
            </span>
            <button
              onClick={startPart1}
              className="px-8 py-3.5 rounded-2xl font-['Manrope'] font-black text-sm bg-[#821E14] hover:bg-[#681810] text-white shadow-lg shadow-[#821E14]/20 transition cursor-pointer flex items-center gap-2"
            >
              Start 4-Stage Pre-Shift Check <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* TEST 1: GO / NO-GO */}
      {/* ------------------------------------------------------------------ */}
      {step === 'part1_gng' && (
        <div className="bg-[#FFFFFF] border-2 border-[#EAE3D5] rounded-3xl p-6 shadow-sm space-y-4 select-none">
          <div className="flex items-center justify-between border-b border-[#EAE3D5] pb-3">
            <span className="font-['JetBrains_Mono'] text-xs font-bold text-[#821E14] uppercase">
              • Stage 1: Concentration (Go / No-Go)
            </span>
            <span className="font-['JetBrains_Mono'] text-xs font-bold px-3 py-1 rounded-full bg-[#111111] text-white">
              Trial {gngTrialIdx + 1} / 22
            </span>
          </div>

          <div
            onClick={handleGngTap}
            className="flex flex-col items-center justify-center min-h-[380px] bg-[#FAF8F5] rounded-3xl border-2 border-[#EAE3D5] relative cursor-pointer shadow-inner p-6"
          >
            {gngStimulus === 'GO' && (
              <div className="flex flex-col items-center gap-4 animate-scale">
                <div className="w-28 h-28 rounded-full bg-[#821E14] shadow-xl flex items-center justify-center text-white font-['Manrope'] font-black text-xl">
                  GO!
                </div>
                <span className="font-['JetBrains_Mono'] text-xs font-bold text-[#821E14] uppercase tracking-wider">
                  TAP SCREEN OR PRESS SPACEBAR
                </span>
              </div>
            )}

            {gngStimulus === 'NOGO' && (
              <div className="flex flex-col items-center gap-4">
                <div className="w-28 h-28 border-4 border-[#111111] bg-transparent flex items-center justify-center text-[#111111] font-['Manrope'] font-black text-xl">
                  WAIT
                </div>
                <span className="font-['JetBrains_Mono'] text-xs font-bold text-[#111111] uppercase tracking-wider">
                  DO NOT TAP
                </span>
              </div>
            )}

            {!gngStimulus && (
              <div className="text-4xl text-[#CCEBF0] font-['JetBrains_Mono']">+</div>
            )}

            {gngFeedback && (
              <div className="absolute bottom-6 font-['JetBrains_Mono'] text-xs font-bold px-4 py-1.5 rounded-full bg-white border border-[#EAE3D5] shadow-sm">
                {gngFeedback}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TRANSITION TO REACTION TIME */}
      {step === 'trans_to_rt' && (
        <div className="bg-[#FFFFFF] border-2 border-[#EAE3D5] rounded-3xl p-12 text-center shadow-sm space-y-4">
          <span className="text-xs font-['JetBrains_Mono'] text-[#821E14] font-bold uppercase tracking-wider block">
            Stage 1 Completed
          </span>
          <h2 className="text-2xl font-['Manrope'] font-black text-[#111111]">
            Next: Stage 2 — Reaction Time Test
          </h2>
          <p className="text-xs text-[#666055] font-['JetBrains_Mono']">
            Target response threshold: ≤ 800ms per click (≤800ms = PASS / &gt;800ms = FAIL). Auto-advancing in 1.6s...
          </p>
          <div className="w-8 h-8 rounded-full border-2 border-[#821E14] border-t-transparent animate-spin mx-auto mt-4"></div>
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* TEST 2: SIMPLE REACTION TIME (800ms PASS / FAIL THRESHOLD) */}
      {/* ------------------------------------------------------------------ */}
      {step === 'part2_rt' && (
        <div className="bg-[#FFFFFF] border-2 border-[#EAE3D5] rounded-3xl p-6 shadow-sm space-y-4 select-none">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#EAE3D5] pb-3 gap-2">
            <div>
              <span className="font-['JetBrains_Mono'] text-xs font-bold text-[#821E14] uppercase block">
                • Stage 2: Reaction Time Test — Target: ≤800ms Per Click
              </span>
              <span className="text-[11px] font-['Inter'] text-[#666055]">
                ≤ 800ms per click = <strong className="text-[#136752]">PASS</strong> · &gt; 800ms = <strong className="text-[#821E14]">FAIL</strong> · Average computed across 10 trials
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-['JetBrains_Mono'] text-xs font-bold px-3 py-1 rounded-full bg-[#FAF8F5] border border-[#EAE3D5] text-[#111111]">
                Passed: {rtLogsRef.current.filter(l => l.passed).length} / {rtLogsRef.current.length}
              </span>
              <span className="font-['JetBrains_Mono'] text-xs font-bold px-3 py-1 rounded-full bg-[#111111] text-white">
                Trial {rtTrialIdx} / 10
              </span>
            </div>
          </div>

          <div
            onClick={handleRtTap}
            style={{
              backgroundColor: rtPhase === 'too_soon' ? '#FCE5E2' :
                               rtPhase === 'triggered' ? '#821E14' :
                               rtPhase === 'responded' ? (currentRtPass ? '#F0F9F5' : '#FCE5E2') :
                               '#FAF8F5',
              borderColor: rtPhase === 'too_soon' ? '#821E14' :
                           rtPhase === 'triggered' ? '#821E14' :
                           rtPhase === 'responded' ? (currentRtPass ? '#136752' : '#821E14') :
                           '#EAE3D5',
            }}
            className="flex flex-col items-center justify-center min-h-[380px] rounded-3xl border-2 relative cursor-pointer shadow-inner transition-colors duration-75 p-6"
          >
            {rtPhase === 'too_soon' && (
              <div className="text-center space-y-2 animate-bounce">
                <div className="text-xl font-['Manrope'] font-black text-[#821E14]">Too Soon! False Start!</div>
                <div className="text-xs font-['JetBrains_Mono'] text-[#821E14]">Trial discarded. Wait for the signal.</div>
              </div>
            )}

            {rtPhase === 'waiting' && (
              <div className="text-center space-y-3">
                <div className="w-5 h-5 rounded-full bg-[#821E14] mx-auto animate-ping"></div>
                <div className="text-2xl font-['Manrope'] font-black tracking-wider text-[#111111]">WAIT FOR SIGNAL...</div>
                <div className="text-xs font-['JetBrains_Mono'] text-[#666055]">Random pause 0.7–2.3s · Tap within 800ms when triggered</div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-[#EAE3D5] text-[11px] font-['JetBrains_Mono'] text-[#821E14] font-bold">
                  Rule: ≤ 800ms = PASS / &gt; 800ms = FAIL
                </div>
              </div>
            )}

            {rtPhase === 'triggered' && (
              <div className="text-center space-y-2 text-white">
                <div className="text-6xl font-['Manrope'] font-black tracking-tight animate-pulse">TAP NOW!</div>
                <div className="text-sm font-['JetBrains_Mono'] font-bold text-[#F2ECE1]">Click or press Spacebar within 800ms!</div>
                <div className="text-xs font-['JetBrains_Mono'] text-white/80 bg-white/10 px-3 py-1 rounded-full inline-block mt-2">
                  Timer running · Limit: 800 ms
                </div>
              </div>
            )}

            {rtPhase === 'responded' && (
              <div className="text-center space-y-3">
                <div className={`inline-flex items-center gap-1 px-4 py-1.5 rounded-full text-xs font-['JetBrains_Mono'] font-bold uppercase ${currentRtPass ? 'bg-[#136752] text-white shadow-sm' : 'bg-[#821E14] text-white shadow-sm'}`}>
                  {currentRtPass ? '✓ CLICK PASSED (≤ 800ms)' : '✗ CLICK FAILED (> 800ms)'}
                </div>
                <div className="text-5xl font-['JetBrains_Mono'] font-black text-[#111111]">{currentRtMs} ms</div>
                <div className="text-xs font-['JetBrains_Mono'] text-[#666055]">
                  {currentRtPass ? 'Latency within 800ms passing window' : (currentRtMs >= 1500 ? 'Response timed out (>800ms)' : 'Exceeded 800ms response threshold')}
                </div>
                {rtLogsRef.current.length > 0 && (
                  <div className="text-[11px] font-['JetBrains_Mono'] text-[#888173] pt-1 border-t border-[#EAE3D5]/60 max-w-xs mx-auto">
                    Running Avg: {Math.round(rtLogsRef.current.map(l => l.rt).reduce((a, b) => a + b, 0) / rtLogsRef.current.length)} ms · {rtLogsRef.current.filter(l => l.passed).length}/{rtLogsRef.current.length} Passed
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TRANSITION TO ERROR DETECTION */}
      {step === 'trans_to_ed' && (
        <div className="bg-[#FFFFFF] border-2 border-[#EAE3D5] rounded-3xl p-12 text-center shadow-sm space-y-4">
          <span className="text-xs font-['JetBrains_Mono'] text-[#821E14] font-bold uppercase tracking-wider block">
            Stage 2 Completed
          </span>
          <h2 className="text-2xl font-['Manrope'] font-black text-[#111111]">
            Next: Stage 3 — Error Detection ("Spot the Change")
          </h2>
          <p className="text-xs text-[#666055] font-['JetBrains_Mono']">
            Observe the 4 equipment status values, then detect which value changed. Auto-advancing in 1.6s...
          </p>
          <div className="w-8 h-8 rounded-full border-2 border-[#821E14] border-t-transparent animate-spin mx-auto mt-4"></div>
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* TEST 3: ERROR DETECTION TEST ("Spot the Change") */}
      {/* ------------------------------------------------------------------ */}
      {step === 'part3_ed' && (
        <div className="bg-[#FFFFFF] border-2 border-[#EAE3D5] rounded-3xl p-6 shadow-sm space-y-5 select-none">
          <div className="flex items-center justify-between border-b border-[#EAE3D5] pb-3">
            <span className="font-['JetBrains_Mono'] text-xs font-bold text-[#821E14] uppercase">
              • Stage 3: Error Detection — "Spot the Change"
            </span>
            <span className="font-['JetBrains_Mono'] text-xs font-bold px-3 py-1 rounded-full bg-[#111111] text-white">
              Question {edRound} of 8
            </span>
          </div>

          {/* Prompt / Instruction Bar */}
          <div className="text-center">
            {edPhase === 'observe' && (
              <div className="space-y-1">
                <span className="inline-block px-3 py-1 rounded-full bg-[#EAE3D5] text-[#821E14] text-xs font-['JetBrains_Mono'] font-bold animate-pulse">
                  👀 OBSERVE STATUS PANEL CAREFULLY...
                </span>
                <p className="text-xs text-[#666055]">Memorize these 4 gauge values. One will change.</p>
              </div>
            )}
            {edPhase === 'hidden' && (
              <div className="py-6 text-slate-300 font-['JetBrains_Mono'] text-sm animate-pulse">
                [ Updating Telemetry Stream... ]
              </div>
            )}
            {(edPhase === 'inspect' || edPhase === 'answered') && (
              <div className="space-y-1">
                <span className="inline-block px-3 py-1 rounded-full bg-[#821E14] text-white text-xs font-['JetBrains_Mono'] font-bold">
                  WHAT CHANGED?
                </span>
                <p className="text-xs text-[#666055]">Select the parameter that was modified:</p>
              </div>
            )}
          </div>

          {/* Gauges Status Panel */}
          {edPhase !== 'hidden' && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {(edPhase === 'observe' ? edInitialGauges : edChangedGauges).map((g, i) => {
                const isModified = edPhase === 'answered' && g.key === edTargetChangedKey;
                return (
                  <div
                    key={i}
                    className={`p-4 rounded-2xl border text-center transition-all ${
                      isModified 
                        ? 'bg-[#FCE5E2] border-[#821E14] shadow-md' 
                        : 'bg-[#FAF8F5] border-[#EAE3D5]'
                    }`}
                  >
                    <span className="text-[11px] font-['JetBrains_Mono'] font-bold text-[#666055] uppercase block">
                      {g.key}
                    </span>
                    <span className="text-2xl font-['JetBrains_Mono'] font-black text-[#111111] block mt-1">
                      {g.val} <span className="text-xs font-normal text-slate-400">{g.unit}</span>
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {/* Answer Option Buttons */}
          {(edPhase === 'inspect' || edPhase === 'answered') && (
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-['Manrope']">
                {GAUGE_POOL.map((g, idx) => {
                  const isSelected = edSelectedAnswer === g.key;
                  const isTarget = g.key === edTargetChangedKey;
                  let btnStyle = "bg-[#FAF8F5] border-[#EAE3D5] text-[#111111] hover:border-[#821E14]";
                  if (edPhase === 'answered') {
                    if (isTarget) btnStyle = "bg-[#821E14] text-white border-[#821E14]";
                    else if (isSelected && !isTarget) btnStyle = "bg-[#FCE5E2] text-[#821E14] border-[#821E14]";
                  }

                  return (
                    <button
                      key={idx}
                      disabled={edPhase === 'answered'}
                      onClick={() => handleEdSubmit(g.key)}
                      className={`p-3.5 rounded-xl border-2 font-bold text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-sm ${btnStyle}`}
                    >
                      {g.key}
                    </button>
                  );
                })}
              </div>

              {edFeedback && (
                <div className="text-center font-['JetBrains_Mono'] text-xs font-bold pt-1 text-[#821E14]">
                  {edFeedback}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TRANSITION TO MEMORY TEST */}
      {step === 'trans_to_mem' && (
        <div className="bg-[#FFFFFF] border-2 border-[#EAE3D5] rounded-3xl p-12 text-center shadow-sm space-y-4">
          <span className="text-xs font-['JetBrains_Mono'] text-[#821E14] font-bold uppercase tracking-wider block">
            Stage 3 Completed
          </span>
          <h2 className="text-2xl font-['Manrope'] font-black text-[#111111]">
            Next: Stage 4 — Memory Test ("Number Recall")
          </h2>
          <p className="text-xs text-[#666055] font-['JetBrains_Mono']">
            Observe the number sequence, then enter the numbers in order. Auto-advancing in 1.6s...
          </p>
          <div className="w-8 h-8 rounded-full border-2 border-[#821E14] border-t-transparent animate-spin mx-auto mt-4"></div>
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* TEST 4: MEMORY TEST ("Number Recall") */}
      {/* ------------------------------------------------------------------ */}
      {step === 'part4_mem' && (
        <div className="bg-[#FFFFFF] border-2 border-[#EAE3D5] rounded-3xl p-6 shadow-sm space-y-5 select-none">
          <div className="flex items-center justify-between border-b border-[#EAE3D5] pb-3">
            <span className="font-['JetBrains_Mono'] text-xs font-bold text-[#821E14] uppercase">
              • Stage 4: Memory Test — "Number Recall"
            </span>
            <span className="font-['JetBrains_Mono'] text-xs font-bold px-3 py-1 rounded-full bg-[#111111] text-white">
              Round {memRound} of 6 · Difficulty: {memSequence.length} Digits
            </span>
          </div>

          {/* Display Phase: Sequence on Screen */}
          {memPhase === 'display' && (
            <div className="flex flex-col items-center justify-center min-h-[260px] bg-[#FAF8F5] rounded-3xl border-2 border-[#EAE3D5] p-8 space-y-4">
              <span className="text-xs font-['JetBrains_Mono'] text-[#821E14] font-bold uppercase tracking-wider">
                MEMORIZE THIS SEQUENCE:
              </span>
              <div className="flex items-center justify-center gap-3 flex-wrap">
                {memSequence.map((num, i) => (
                  <React.Fragment key={i}>
                    <div className="w-14 h-14 rounded-2xl bg-[#821E14] text-white font-['Manrope'] font-black text-2xl flex items-center justify-center shadow-md">
                      {num}
                    </div>
                    {i < memSequence.length - 1 && (
                      <span className="text-[#888173] font-black text-lg">→</span>
                    )}
                  </React.Fragment>
                ))}
              </div>
              <span className="text-[11px] font-['JetBrains_Mono'] text-[#666055]">
                Disappearing in a few seconds...
              </span>
            </div>
          )}

          {/* Recall Phase: User Enters Sequence */}
          {(memPhase === 'recall' || memPhase === 'feedback') && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <span className="text-xs font-['JetBrains_Mono'] text-[#821E14] font-bold uppercase">
                  ENTER THE NUMBERS IN CORRECT ORDER:
                </span>
                <div className="h-16 max-w-sm mx-auto bg-[#FAF8F5] border-2 border-[#EAE3D5] rounded-2xl flex items-center justify-center px-4 font-['JetBrains_Mono'] text-2xl font-black tracking-widest text-[#111111]">
                  {memInput || <span className="text-slate-300 text-sm font-normal">Use keypad below...</span>}
                </div>
              </div>

              {/* On-screen Numeric Keypad */}
              <div className="max-w-xs mx-auto grid grid-cols-3 gap-2">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
                  <button
                    key={digit}
                    onClick={() => handleMemKey(digit)}
                    disabled={memPhase === 'feedback'}
                    className="py-3 rounded-xl bg-[#FAF8F5] hover:bg-[#EAE3D5] border border-[#EAE3D5] text-[#111111] font-['Manrope'] font-bold text-lg transition cursor-pointer shadow-sm active:scale-95"
                  >
                    {digit}
                  </button>
                ))}
                <button
                  onClick={() => handleMemKey('DEL')}
                  disabled={memPhase === 'feedback'}
                  className="py-3 rounded-xl bg-[#FCE5E2] hover:bg-[#fbd3cd] border border-[#821E14]/30 text-[#821E14] font-['JetBrains_Mono'] font-bold text-xs transition cursor-pointer shadow-sm"
                >
                  ⌫ DEL
                </button>
                <button
                  onClick={() => handleMemKey(0)}
                  disabled={memPhase === 'feedback'}
                  className="py-3 rounded-xl bg-[#FAF8F5] hover:bg-[#EAE3D5] border border-[#EAE3D5] text-[#111111] font-['Manrope'] font-bold text-lg transition cursor-pointer shadow-sm active:scale-95"
                >
                  0
                </button>
                <button
                  onClick={handleMemSubmit}
                  disabled={memPhase === 'feedback' || memInput.length === 0}
                  className="py-3 rounded-xl bg-[#821E14] hover:bg-[#681810] text-white font-['Manrope'] font-black text-xs transition cursor-pointer shadow-sm flex items-center justify-center gap-1"
                >
                  SUBMIT ✓
                </button>
              </div>

              {memFeedback && (
                <div className="text-center font-['JetBrains_Mono'] text-xs font-bold pt-1 text-[#821E14]">
                  {memFeedback}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* FINAL RESULTS SCREEN (ALL 4 TESTS) */}
      {/* ------------------------------------------------------------------ */}
      {step === 'results' && resultsData && (
        <div className="bg-[#FFFFFF] border-2 border-[#EAE3D5] rounded-3xl p-8 shadow-sm space-y-6 relative overflow-hidden">
          {/* Header Banner */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#EAE3D5] pb-6">
            <div>
              <span className="font-['JetBrains_Mono'] text-xs uppercase text-[#821E14] font-bold block mb-1">
                • Comprehensive Pre-Shift Verification Summary
              </span>
              <h2 className="text-2xl md:text-3xl font-['Manrope'] font-black text-[#111111] flex items-center gap-3">
                Operator {user?.anonymized_id || 'WRK-8104'}
                <StatusBadge status={resultsData.verdict} size="lg" />
              </h2>
            </div>

            <div className="bg-[#FAF8F5] border border-[#EAE3D5] p-4 rounded-2xl text-center min-w-[170px]">
              <span className="text-[11px] font-['JetBrains_Mono'] font-bold text-[#666055] uppercase tracking-wider block">
                Overall Readiness
              </span>
              <div className="text-4xl font-['JetBrains_Mono'] font-black text-[#821E14] mt-1">
                {resultsData.score} <span className="text-xs font-normal text-[#888173]">/ 100</span>
              </div>
            </div>
          </div>

          {/* 4 Behavioral Test Pillars (Exact Integration Required) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-['JetBrains_Mono']">
            {/* 1. Concentration */}
            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
              <span className="text-[10px] text-[#666055] font-bold uppercase block">1. Concentration</span>
              <span className="text-2xl font-black text-[#111111] block mt-1">{resultsData.concScore} / 100</span>
              <span className="text-[10px] text-[#888173] block mt-0.5">Go/No-Go accuracy</span>
            </div>

            {/* 2. Reaction Time */}
            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-[#666055] font-bold uppercase block">2. Reaction Time</span>
                <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded-full ${resultsData.avgRt <= 800 ? 'bg-[#e8f5f1] text-[#136752]' : 'bg-[#FCE5E2] text-[#821E14]'}`}>
                  {resultsData.avgRt <= 800 ? 'PASS ≤800ms' : 'FAIL >800ms'}
                </span>
              </div>
              <span className="text-2xl font-black text-[#111111] block mt-1">{resultsData.reactionScore} / 100</span>
              <span className="text-[10px] text-[#888173] block mt-0.5">Average: <strong className="text-[#111111]">{resultsData.avgRt} ms</strong></span>
              <span className="text-[10px] text-[#666055] block">Clicks: <strong className="text-[#111111]">{resultsData.rtPassedClicks}/{resultsData.rtTotalCount || 10} Passed</strong> ({resultsData.rtPassRate}%)</span>
            </div>

            {/* 3. Error Detection */}
            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
              <span className="text-[10px] text-[#666055] font-bold uppercase block">3. Error Detection</span>
              <span className="text-2xl font-black text-[#111111] block mt-1">{resultsData.edScore} / 100</span>
              <span className="text-[10px] text-[#888173] block mt-0.5">{resultsData.edCorrect}/8 correct ({resultsData.edAccuracy}%)</span>
            </div>

            {/* 4. Memory Test */}
            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
              <span className="text-[10px] text-[#666055] font-bold uppercase block">4. Memory Test</span>
              <span className="text-2xl font-black text-[#111111] block mt-1">{resultsData.memScore} / 100</span>
              <span className="text-[10px] text-[#888173] block mt-0.5">Max seq: {resultsData.maxSeqRemembered} digits</span>
            </div>
          </div>

          {/* Historical comparison line */}
          {recentAverage !== null && (
            <div className="p-3.5 rounded-2xl bg-[#F2ECE1] border border-[#EAE3D5] flex items-center justify-between text-xs font-['JetBrains_Mono']">
              <span className="font-bold text-[#111111]">
                {deltaVsAvg >= 0 ? '+' : ''}{deltaVsAvg} pts vs your recent 5-shift baseline ({recentAverage}.0)
              </span>
              <span className="text-[#666055] text-[11px]">
                {deltaVsAvg >= 0 ? 'Optimal psychological stability' : 'Slight downward drift from typical standard'}
              </span>
            </div>
          )}

          {/* Actions */}
          <div className="pt-2 flex items-center justify-between">
            <span className="text-xs font-['JetBrains_Mono'] text-[#888173]">
              STATUS SAVED TO SECURE AUDIT LOG
            </span>
            <button
              onClick={() => { setStep('intro'); setResultsData(null); }}
              className="px-6 py-2.5 rounded-xl font-['Manrope'] font-bold text-white text-xs bg-[#821E14] hover:bg-[#681810] transition cursor-pointer flex items-center gap-2 shadow-sm"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Retake Check
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

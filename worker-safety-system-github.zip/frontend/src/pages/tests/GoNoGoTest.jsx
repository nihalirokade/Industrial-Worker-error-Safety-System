import React, { useState, useEffect, useRef } from 'react';
import { Play, Target, Zap } from 'lucide-react';

export const GoNoGoTest = ({ onComplete, onCancel }) => {
  const [trialCount, setTrialCount] = useState(15);
  const [phase, setPhase] = useState('instructions');
  const [currentTrialIdx, setCurrentTrialIdx] = useState(0);
  const [stimulusType, setStimulusType] = useState(null);
  const [feedback, setFeedback] = useState(null);

  const phaseRef = useRef(phase);
  const trialStreamRef = useRef([]);
  const stimulusStartTimeRef = useRef(0);
  const respondedInCurrentTrialRef = useRef(false);
  const timerRef = useRef(null);
  const trialsRef = useRef([]);

  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  const initTrials = (count) => {
    const list = [];
    const nogoCount = Math.max(3, Math.floor(count * 0.20));
    const goCount = count - nogoCount;
    for (let i = 0; i < goCount; i++) list.push('GO');
    for (let i = 0; i < nogoCount; i++) list.push('NOGO');
    for (let i = list.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [list[i], list[j]] = [list[j], list[i]];
    }
    if (list[0] === 'NOGO') {
      const goIdx = list.indexOf('GO');
      [list[0], list[goIdx]] = [list[goIdx], list[0]];
    }
    trialsRef.current = list;
    trialStreamRef.current = [];
  };

  const startTest = () => {
    initTrials(trialCount);
    setCurrentTrialIdx(0);
    nextTrial(0);
  };

  const nextTrial = (idx) => {
    if (idx >= trialsRef.current.length) {
      finishTest();
      return;
    }

    setCurrentTrialIdx(idx);
    respondedInCurrentTrialRef.current = false;
    setStimulusType(null);
    setFeedback(null);
    setPhase('fixation');

    // Jittered fixation: 1000 - 1800 ms
    const isi = 1000 + Math.random() * 800;
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      showStimulus(idx);
    }, isi);
  };

  const showStimulus = (idx) => {
    const sType = trialsRef.current[idx];
    setStimulusType(sType);
    setPhase('stimulus');
    stimulusStartTimeRef.current = performance.now();

    // Stimulus duration: 350ms, then wait up to 550ms for response
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      setPhase('response_wait');
      timerRef.current = setTimeout(() => {
        handleTrialTimeout(idx, sType);
      }, 550);
    }, 350);
  };

  const recordResponse = () => {
    if (phaseRef.current !== 'stimulus' && phaseRef.current !== 'response_wait') return;
    if (respondedInCurrentTrialRef.current) return;

    respondedInCurrentTrialRef.current = true;
    const rt = performance.now() - stimulusStartTimeRef.current;
    if (timerRef.current) clearTimeout(timerRef.current);

    const sType = trialsRef.current[currentTrialIdx];
    let outcome = 'HIT';
    if (sType === 'NOGO') {
      outcome = 'COMMISSION';
      setFeedback('COMMISSION');
    } else {
      outcome = 'HIT';
      setFeedback('HIT');
    }

    trialStreamRef.current.push({
      trial: currentTrialIdx + 1,
      type: sType,
      responded: true,
      rt_ms: Math.round(rt),
      outcome,
    });

    timerRef.current = setTimeout(() => {
      nextTrial(currentTrialIdx + 1);
    }, 400);
  };

  const handleTrialTimeout = (idx, sType) => {
    if (respondedInCurrentTrialRef.current) return;

    let outcome = 'CORRECT_REJECTION';
    if (sType === 'GO') {
      outcome = 'OMISSION';
      setFeedback('OMISSION');
    } else {
      outcome = 'CORRECT_REJECTION';
      setFeedback('CORRECT_REJECTION');
    }

    trialStreamRef.current.push({
      trial: idx + 1,
      type: sType,
      responded: false,
      rt_ms: null,
      outcome,
    });

    timerRef.current = setTimeout(() => {
      nextTrial(idx + 1);
    }, 300);
  };

  const finishTest = () => {
    setPhase('finished');
    const trials = trialStreamRef.current;
    const total = trials.length;
    const hits = trials.filter(t => t.outcome === 'HIT').length;
    const correctRejections = trials.filter(t => t.outcome === 'CORRECT_REJECTION').length;
    const commissionErrors = trials.filter(t => t.outcome === 'COMMISSION').length;
    const omissionErrors = trials.filter(t => t.outcome === 'OMISSION').length;

    const hitRTs = trials.filter(t => t.outcome === 'HIT' && t.rt_ms).map(t => t.rt_ms);
    const meanRT = hitRTs.length ? hitRTs.reduce((a, b) => a + b, 0) / hitRTs.length : 300;
    const variance = hitRTs.length > 1
      ? hitRTs.reduce((a, b) => a + Math.pow(b - meanRT, 2), 0) / (hitRTs.length - 1)
      : 2500;
    const sdRT = Math.sqrt(variance);
    const cv = meanRT > 0 ? sdRT / meanRT : 0.25;

    const accuracy = ((hits + correctRejections) / total) * 100;
    const consistencyComponent = Math.max(0, 40 * (1 - Math.min(1.0, cv)));
    const commissionPenalty = commissionErrors * 6.0;
    const concScore = Math.max(0, Math.min(100, (0.6 * accuracy) + consistencyComponent - commissionPenalty));

    const result = {
      test_name: 'go_no_go',
      total_trials: total,
      hits,
      correct_rejections: correctRejections,
      commission_errors: commissionErrors,
      omission_errors: omissionErrors,
      accuracy: Math.round(accuracy * 10) / 10,
      rt_mean_ms: Math.round(meanRT),
      rt_sd_ms: Math.round(sdRT),
      rt_variability_cv: Math.round(cv * 1000) / 1000,
      concentration_score: Math.round(concScore * 10) / 10,
      trials,
    };

    onComplete(result);
  };

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.code === 'Space') {
        e.preventDefault();
        if (phaseRef.current === 'instructions') {
          startTest();
        } else if (phaseRef.current === 'stimulus' || phaseRef.current === 'response_wait') {
          recordResponse();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  return (
    <div
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: '#CCEBF0',
        boxShadow: '0 15px 40px rgba(14, 21, 32, 0.07)',
      }}
      className="max-w-3xl mx-auto p-6 border-2 rounded-3xl font-['Inter'] relative overflow-hidden"
    >
      <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#D9077E]" />

      <div className="flex items-center justify-between border-b border-[#CCEBF0]/60 pb-4 mb-6">
        <div className="flex items-center gap-3">
          <div
            style={{
              backgroundColor: '#D5F5F8',
              borderColor: '#CCEBF0',
              color: '#1E444B',
            }}
            className="p-2.5 rounded-2xl border"
          >
            <Target className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-['Manrope'] font-black text-[#0E1520]">Daily Concentration Screening (Go / No-Go)</h2>
            <p className="text-xs font-['JetBrains_Mono'] text-[#1E444B]">Sustained attention, motor consistency, & impulse inhibition</p>
          </div>
        </div>
        {phase !== 'instructions' && phase !== 'finished' && (
          <div
            style={{
              backgroundColor: '#0E1520',
              color: '#D5F5F8',
              borderColor: '#CCEBF0',
            }}
            className="text-xs font-['JetBrains_Mono'] font-bold px-3.5 py-1 rounded-full border shadow-sm"
          >
            Trial {currentTrialIdx + 1} / {trialCount}
          </div>
        )}
      </div>

      {phase === 'instructions' && (
        <div className="space-y-6 text-[#1E444B]">
          <div
            style={{
              backgroundColor: '#EBF8FA',
              borderColor: '#CCEBF0',
            }}
            className="p-5 rounded-2xl border space-y-4"
          >
            <h3 className="font-['Manrope'] font-bold text-[#0E1520] text-sm">Protocol Instructions</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div
                style={{
                  backgroundColor: '#D5F5F8',
                  borderColor: '#CCEBF0',
                }}
                className="p-4 rounded-2xl border flex items-center gap-3"
              >
                <div
                  style={{
                    backgroundColor: '#1E444B',
                    boxShadow: '0 4px 15px rgba(30, 68, 75, 0.3)',
                  }}
                  className="w-12 h-12 rounded-full flex items-center justify-center font-['JetBrains_Mono'] font-black text-white text-xl"
                >
                  M
                </div>
                <div>
                  <div className="font-['Manrope'] font-black text-sm text-[#0E1520]">GO Stimulus (80%)</div>
                  <div className="text-xs font-['Inter'] text-[#1E444B]">Press <kbd className="px-1.5 py-0.5 bg-white rounded border border-[#CCEBF0] text-[#0E1520] font-['JetBrains_Mono'] font-bold">SPACE</kbd> or tap screen immediately.</div>
                </div>
              </div>

              <div
                style={{
                  backgroundColor: '#FDE8F3',
                  borderColor: '#F7BFE0',
                }}
                className="p-4 rounded-2xl border flex items-center gap-3"
              >
                <div
                  style={{
                    backgroundColor: '#D9077E',
                    boxShadow: '0 4px 15px rgba(217, 7, 126, 0.35)',
                  }}
                  className="w-12 h-12 rounded-2xl flex items-center justify-center font-['JetBrains_Mono'] font-black text-white text-xl"
                >
                  W
                </div>
                <div>
                  <div className="font-['Manrope'] font-black text-sm text-[#940D7E]">NO-GO Stimulus (20%)</div>
                  <div className="text-xs font-['Inter'] text-[#940D7E]"><strong className="font-bold">Withhold response!</strong> Do NOT press.</div>
                </div>
              </div>
            </div>
            <p className="text-xs font-['JetBrains_Mono'] text-[#1E444B]">
              Each shape flashes for 350ms with jittered inter-stimulus intervals. Maintain steady focus.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-['JetBrains_Mono'] text-[#1E444B] font-bold">Trial Length:</span>
              <button
                onClick={() => setTrialCount(5)}
                style={{
                  backgroundColor: trialCount === 5 ? '#D5F5F8' : '#FFFFFF',
                  color: trialCount === 5 ? '#0E1520' : '#1E444B',
                  borderColor: '#CCEBF0',
                }}
                className="px-3 py-1 text-xs rounded-xl font-['JetBrains_Mono'] font-bold border transition cursor-pointer"
              >
                5 Trials (Fast Viva Demo)
              </button>
              <button
                onClick={() => setTrialCount(15)}
                style={{
                  backgroundColor: trialCount === 15 ? '#D5F5F8' : '#FFFFFF',
                  color: trialCount === 15 ? '#0E1520' : '#1E444B',
                  borderColor: '#CCEBF0',
                }}
                className="px-3 py-1 text-xs rounded-xl font-['JetBrains_Mono'] font-bold border transition cursor-pointer"
              >
                15 Trials (Standard)
              </button>
            </div>

            <div className="flex items-center gap-3">
              {onCancel && (
                <button onClick={onCancel} className="px-4 py-2 text-xs text-[#1E444B] hover:text-[#0E1520] transition cursor-pointer font-bold">
                  Cancel
                </button>
              )}
              <button
                onClick={startTest}
                style={{
                  backgroundColor: '#D9077E',
                  color: '#FFFFFF',
                  boxShadow: '0 4px 18px rgba(217, 7, 126, 0.35)',
                }}
                className="px-6 py-2.5 font-['Manrope'] font-black text-sm rounded-xl flex items-center gap-2 transition transform active:scale-95 cursor-pointer shadow-md"
              >
                <Play className="w-4 h-4 fill-current" />
                Start Test (or Press Space)
              </button>
            </div>
          </div>
        </div>
      )}

      {(phase === 'fixation' || phase === 'stimulus' || phase === 'response_wait') && (
        <div
          onClick={recordResponse}
          style={{
            backgroundColor: '#EBF8FA',
            borderColor: '#CCEBF0',
          }}
          className="flex flex-col items-center justify-center min-h-[340px] rounded-3xl border-2 relative select-none cursor-pointer shadow-inner"
        >
          {phase === 'fixation' && (
            <div className="text-7xl font-light animate-pulse font-['JetBrains_Mono'] select-none text-[#1E444B]">
              +
            </div>
          )}

          {(phase === 'stimulus' || phase === 'response_wait') && (
            <div className="flex flex-col items-center animate-in fade-in zoom-in duration-75">
              {stimulusType === 'GO' ? (
                <div
                  style={{
                    backgroundColor: '#1E444B',
                    boxShadow: '0 10px 40px rgba(30, 68, 75, 0.5)',
                    borderColor: '#CCEBF0',
                  }}
                  className="w-36 h-36 rounded-full flex items-center justify-center font-['JetBrains_Mono'] font-black text-white text-6xl border-4"
                >
                  M
                </div>
              ) : (
                <div
                  style={{
                    backgroundColor: '#D9077E',
                    boxShadow: '0 10px 40px rgba(217, 7, 126, 0.6)',
                    borderColor: '#FFFFFF',
                  }}
                  className="w-36 h-36 rounded-3xl flex items-center justify-center font-['JetBrains_Mono'] font-black text-white text-6xl border-4"
                >
                  W
                </div>
              )}
            </div>
          )}

          {feedback && (
            <div className="absolute top-4 text-sm font-['JetBrains_Mono'] font-black tracking-widest uppercase">
              {feedback === 'HIT' && <span className="text-[#1E444B] bg-[#D5F5F8] px-3.5 py-1.5 rounded-full border border-[#CCEBF0]">HIT ✓</span>}
              {feedback === 'COMMISSION' && <span className="text-[#D9077E] bg-[#FDE8F3] px-3.5 py-1.5 rounded-full border border-[#D9077E] animate-bounce">FALSE ALARM (NO-GO PRESSED) ✗</span>}
              {feedback === 'OMISSION' && <span className="text-[#940D7E] bg-[#FDE8F3] px-3.5 py-1.5 rounded-full border border-[#F7BFE0]">MISSED GO ✗</span>}
              {feedback === 'CORRECT_REJECTION' && <span className="text-[#1E444B] bg-[#D5F5F8] px-3.5 py-1.5 rounded-full border border-[#CCEBF0]">WITHHELD ✓</span>}
            </div>
          )}

          <div className="absolute bottom-4 inset-x-0 flex justify-center">
            <button
              onClick={recordResponse}
              disabled={phase === 'fixation'}
              style={{
                backgroundColor: phase === 'fixation' ? '#CCEBF0' : '#D9077E',
                color: phase === 'fixation' ? '#1E444B' : '#FFFFFF',
              }}
              className="px-8 py-3 rounded-2xl font-['Manrope'] font-black text-sm tracking-wide uppercase transition transform active:scale-95 shadow-md cursor-pointer"
            >
              TAP HERE OR PRESS SPACE
            </button>
          </div>
        </div>
      )}

      {phase === 'finished' && (
        <div className="py-8 text-center space-y-4">
          <div
            style={{
              backgroundColor: '#D5F5F8',
              color: '#1E444B',
            }}
            className="w-12 h-12 mx-auto rounded-2xl flex items-center justify-center"
          >
            <Zap className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-['Manrope'] font-bold text-[#0E1520]">Concentration Test Completed</h3>
          <p className="text-sm font-['Inter'] text-[#1E444B]">Sustained attention metrics processed. Proceeding to Reaction-Time screening...</p>
        </div>
      )}
    </div>
  );
};

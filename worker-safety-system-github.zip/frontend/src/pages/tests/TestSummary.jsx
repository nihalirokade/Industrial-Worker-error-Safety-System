import React from 'react';
import { ShieldCheck, Activity, ArrowRight, RotateCcw, FileSpreadsheet, AlertOctagon } from 'lucide-react';
import { StatusBadge } from '../../components/StatusBadge';
import { MetricCard } from '../../components/MetricCard';

export const TestSummary = ({ result, onRetest, onGoToSignals, onReturnPortal }) => {
  if (!result) return null;

  const isEstablished = result.is_baseline_established;
  const classification = result.classification || 'Safe Operation';

  return (
    <div
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: '#CCEBF0',
        boxShadow: '0 15px 40px rgba(14, 21, 32, 0.07)',
      }}
      className="max-w-4xl mx-auto p-6 border-2 rounded-3xl font-['Inter'] space-y-6 relative overflow-hidden"
    >
      <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#D9077E]" />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#CCEBF0]/60 pb-6">
        <div>
          <span className="text-xs font-['JetBrains_Mono'] uppercase text-[#1E444B] font-bold">Shift Screening Assessment</span>
          <h2 className="text-2xl font-['Manrope'] font-black text-[#0E1520] flex items-center gap-3 mt-1">
            Operator {result.anonymized_id}
            <StatusBadge status={classification} size="lg" />
          </h2>
          <div className="mt-2 flex items-center gap-2 text-xs font-['JetBrains_Mono']">
            {isEstablished ? (
              <span className="flex items-center gap-1 font-bold text-[#1E444B]">
                <ShieldCheck className="w-4 h-4 text-[#1E444B]" />
                Adaptive Personal Baseline Active ({result.sessions_recorded || 7}+ shifts analyzed)
              </span>
            ) : (
              <span className="flex items-center gap-1 font-bold text-[#940D7E]">
                <Activity className="w-4 h-4 text-[#940D7E]" />
                Population-Based Reference (Personal baseline building: {result.sessions_recorded || 1}/7 shifts)
              </span>
            )}
          </div>
        </div>

        <div
          style={{
            backgroundColor: '#EBF8FA',
            borderColor: '#CCEBF0',
            borderRight: '4px solid #D9077E',
          }}
          className="p-4 rounded-2xl border text-center min-w-[160px]"
        >
          <span className="text-[11px] font-['JetBrains_Mono'] font-bold text-[#1E444B] uppercase tracking-wider">Composite Error Risk</span>
          <div
            style={{
              color: result.final_risk_score >= 68 ? '#D9077E' :
                     result.final_risk_score >= 42 ? '#940D7E' :
                     '#1E444B',
            }}
            className="text-3xl font-['JetBrains_Mono'] font-black mt-1"
          >
            {result.final_risk_score} <span className="text-xs font-normal text-slate-400">/ 100</span>
          </div>
          <span className="text-[10px] font-['JetBrains_Mono'] text-[#1E444B]">Confidence: {result.confidence_score}%</span>
        </div>
      </div>

      {result.flagged_reasons && result.flagged_reasons.length > 0 && (
        <div
          style={{
            backgroundColor: '#FDE8F3',
            borderColor: '#D9077E',
          }}
          className="p-4 rounded-2xl border space-y-2"
        >
          <div className="flex items-center gap-2 font-['JetBrains_Mono'] font-bold text-xs uppercase tracking-wider text-[#D9077E]">
            <AlertOctagon className="w-4 h-4" />
            Detected Operational Deviations:
          </div>
          <ul className="list-disc list-inside space-y-1 text-xs text-[#940D7E] font-medium font-['Inter']">
            {result.flagged_reasons.map((f, i) => (
              <li key={i}>{f}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <MetricCard
          title="Concentration"
          value={result.concentration_score}
          unit="/ 100"
          zScore={result.concentration_zscore}
          subtitle="Sustained Attention"
          color={result.concentration_zscore < -1.5 ? "tangerine" : "mint"}
        />
        <MetricCard
          title="Reaction Time"
          value={result.rt_median_ms}
          unit="ms"
          zScore={result.reaction_zscore}
          subtitle="Motor / Choice Speed"
          color={result.reaction_zscore > 1.5 ? "tangerine" : "mint"}
        />
        <MetricCard
          title="Reaction Score"
          value={result.reaction_score}
          unit="/ 100"
          subtitle="Speed Score"
          color="mint"
        />
        <MetricCard
          title="Consistency SD"
          value={result.rt_sd_ms}
          unit="ms"
          subtitle="Micro-variability"
          color="peach"
        />
      </div>

      {result.baseline_snapshot && (
        <div
          style={{
            backgroundColor: '#EBF8FA',
            borderColor: '#CCEBF0',
          }}
          className="p-4 rounded-2xl border text-xs text-[#1E444B]"
        >
          <h4 className="font-['Manrope'] font-bold text-[#0E1520] mb-2 flex items-center justify-between">
            <span>Reference Baseline Distribution</span>
            <span className="text-[10px] font-['JetBrains_Mono'] text-[#1E444B]">
              {isEstablished ? "Personal Historic Mean ± 1.0 SD" : "Population Cohort Norms"}
            </span>
          </h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <span className="block text-[11px] text-[#1E444B]">Normal Concentration:</span>
              <span className="font-['JetBrains_Mono'] text-[#0E1520] font-bold">{result.baseline_snapshot.concentration_mean} ± {result.baseline_snapshot.concentration_sd}</span>
            </div>
            <div>
              <span className="block text-[11px] text-[#1E444B]">Normal Reaction Time:</span>
              <span className="font-['JetBrains_Mono'] text-[#0E1520] font-bold">{result.baseline_snapshot.rt_median_mean}ms ± {result.baseline_snapshot.rt_median_sd}ms</span>
            </div>
            <div>
              <span className="block text-[11px] text-[#1E444B]">Today Concentration:</span>
              <span
                style={{
                  color: result.concentration_score < result.baseline_snapshot.concentration_mean - 10 ? '#D9077E' : '#1E444B',
                }}
                className="font-['JetBrains_Mono'] font-black"
              >
                {result.concentration_score}
              </span>
            </div>
            <div>
              <span className="block text-[11px] text-[#1E444B]">Today Reaction Time:</span>
              <span
                style={{
                  color: result.rt_median_ms > result.baseline_snapshot.rt_median_mean + 40 ? '#D9077E' : '#1E444B',
                }}
                className="font-['JetBrains_Mono'] font-black"
              >
                {result.rt_median_ms}ms
              </span>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-[#CCEBF0]/60">
        <button
          onClick={onRetest}
          style={{
            backgroundColor: '#FFFFFF',
            borderColor: '#CCEBF0',
            color: '#1E444B',
          }}
          className="px-4 py-2 text-xs font-['JetBrains_Mono'] font-bold rounded-xl border hover:bg-[#D5F5F8] flex items-center gap-1.5 transition cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Retest Screening
        </button>

        <div className="flex items-center gap-3">
          <button
            onClick={onGoToSignals}
            style={{
              backgroundColor: '#D5F5F8',
              borderColor: '#CCEBF0',
              color: '#0E1520',
            }}
            className="px-4 py-2 text-xs font-['JetBrains_Mono'] font-bold rounded-xl border hover:bg-[#bcebf1] flex items-center gap-1.5 transition cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-[#D9077E]" />
            Upload EEG / ECG Signal
          </button>
          <button
            onClick={onReturnPortal}
            style={{
              backgroundColor: '#D9077E',
              color: '#FFFFFF',
              boxShadow: '0 4px 18px rgba(217, 7, 126, 0.35)',
            }}
            className="px-6 py-2 text-xs font-['Manrope'] font-black rounded-xl flex items-center gap-1.5 transition transform active:scale-95 shadow-md cursor-pointer"
          >
            Return to Portal
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

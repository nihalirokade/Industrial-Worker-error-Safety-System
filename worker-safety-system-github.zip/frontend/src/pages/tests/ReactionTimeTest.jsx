import React, { useState, useEffect, useRef } from 'react';
import { Timer, Play, AlertTriangle, CheckCircle } from 'lucide-react';

export const ReactionTimeTest = ({ goNoGoResults, onComplete, onCancel }) => {
  const [testType, setTestType] = useState('simple');
  const [phase, setPhase] = useState('instructions');
  const [currentTrial, setCurrentTrial] = useState(0);
  const [currentRT, setCurrentRT] = useState(null);
  const [isEarlyClick, setIsEarlyClick] = useState(false);
  const [choiceTarget, setChoiceTarget] = useState(null);

  const [totalTrials, setTotalTrials] = useState(15);
  const WARMUP_TRIALS = totalTrials === 5 ? 1 : 2;

  const phaseRef = useRef(phase);
  const testTypeRef = useRef(testType);
  const choiceTargetRef = useRef(choiceTarget);
  const totalTrialsRef = useRef(totalTrials);

  const trialLogsRef = useRef([]);
  const triggerTimeRef = useRef(0);
  const timeoutRef = useRef(null);

  useEffect(() => { phaseRef.current = phase; }, [phase]);
  useEffect(() => { testTypeRef.current = testType; }, [testType]);
  useEffect(() => { choiceTargetRef.current = choiceTarget; }, [choiceTarget]);
  useEffect(() => { totalTrialsRef.current = totalTrials; }, [totalTrials]);

  const startTest = () => {
    trialLogsRef.current = [];
    setCurrentTrial(0);
    nextTrial(0);
  };

  const nextTrial = (trialIdx) => {
    if (trialIdx >= totalTrialsRef.current) {
      finishTest();
      return;
    }

    setCurrentTrial(trialIdx);
    setCurrentRT(null);
    setIsEarlyClick(false);
    setChoiceTarget(null);
    setPhase('waiting');

    // Jitter: 1200 - 3000ms
    const jitter = 1200 + Math.random() * 1800;
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      triggerStimulus(trialIdx);
    }, jitter);
  };

  const triggerStimulus = (trialIdx) => {
    setPhase('triggered');
    triggerTimeRef.current = performance.now();

    if (testTypeRef.current === 'choice') {
      const keys = ['A', 'S', 'K', 'L'];
      const target = keys[Math.floor(Math.random() * keys.length)];
      setChoiceTarget(target);
    }

    // Safety auto-lapse timeout after 2500ms
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      if (phaseRef.current === 'triggered') {
        recordResponse('LAPSE_TIMEOUT');
      }
    }, 2500);
  };

  const recordResponse = (pressedKey = 'SPACE') => {
    if (phaseRef.current === 'waiting') {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      setIsEarlyClick(true);
      trialLogsRef.current.push({
        trial: currentTrial + 1,
        rt_ms: 50,
        is_warmup: currentTrial < WARMUP_TRIALS,
        anticipatory: true,
        lapse: false,
        correct: false,
      });

      timeoutRef.current = setTimeout(() => {
        nextTrial(currentTrial + 1);
      }, 1000);
      return;
    }

    if (phaseRef.current !== 'triggered') return;

    if (timeoutRef.current) clearTimeout(timeoutRef.current);

    if (pressedKey === 'LAPSE_TIMEOUT') {
      setCurrentRT(1200);
      setPhase('responded');
      trialLogsRef.current.push({
        trial: currentTrial + 1,
        rt_ms: 1200,
        is_warmup: currentTrial < WARMUP_TRIALS,
        anticipatory: false,
        lapse: true,
        correct: false,
      });

      timeoutRef.current = setTimeout(() => {
        nextTrial(currentTrial + 1);
      }, 700);
      return;
    }

    const rt = performance.now() - triggerTimeRef.current;
    const roundedRT = Math.round(rt);
    setCurrentRT(roundedRT);
    setPhase('responded');

    const isAnticipatory = roundedRT < 100;
    const isLapse = roundedRT > 1000;
    const isCorrect = testTypeRef.current === 'choice' ? (pressedKey === choiceTargetRef.current) : true;

    trialLogsRef.current.push({
      trial: currentTrial + 1,
      rt_ms: roundedRT,
      is_warmup: currentTrial < WARMUP_TRIALS,
      anticipatory: isAnticipatory,
      lapse: isLapse,
      correct: isCorrect,
    });

    timeoutRef.current = setTimeout(() => {
      nextTrial(currentTrial + 1);
    }, 700);
  };

  const finishTest = () => {
    setPhase('finished');
    const logs = trialLogsRef.current;
    
    const validTrials = logs.filter(t => !t.is_warmup && !t.anticipatory && t.rt_ms !== null);
    const validRTs = validTrials.map(t => t.rt_ms).sort((a, b) => a - b);

    let medianRT = 260.0;
    if (validRTs.length > 0) {
      const mid = Math.floor(validRTs.length / 2);
      medianRT = validRTs.length % 2 !== 0 ? validRTs[mid] : (validRTs[mid - 1] + validRTs[mid]) / 2.0;
    }

    const meanRT = validRTs.length ? validRTs.reduce((a, b) => a + b, 0) / validRTs.length : 260.0;
    const variance = validRTs.length > 1
      ? validRTs.reduce((a, b) => a + Math.pow(b - meanRT, 2), 0) / (validRTs.length - 1)
      : 400.0;
    const sdRT = Math.sqrt(variance);
    const cv = meanRT > 0 ? sdRT / meanRT : 0.18;

    const anticipatoryCount = logs.filter(t => t.anticipatory).length;
    const lapseCount = logs.filter(t => t.lapse).length;
    const reactionScore = Math.max(0, Math.min(100, 100.0 - ((medianRT - 180.0) / 2.5)));

    const result = {
      test_type: testTypeRef.current,
      total_trials: logs.length,
      valid_trials_analyzed: validTrials.length,
      rt_median_ms: Math.round(medianRT),
      rt_mean_ms: Math.round(meanRT),
      rt_sd_ms: Math.round(sdRT),
      rt_variability_cv: Math.round(cv * 1000) / 1000,
      anticipatory_clicks: anticipatoryCount,
      lapse_count: lapseCount,
      reaction_score: Math.round(reactionScore * 10) / 10,
      trial_logs: logs,
    };

    onComplete(result);
  };

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.code === 'Space') {
        e.preventDefault();
        if (phaseRef.current === 'instructions') {
          startTest();
        } else if (phaseRef.current === 'waiting' || phaseRef.current === 'triggered') {
          if (testTypeRef.current === 'simple') recordResponse('SPACE');
        }
      } else if (testTypeRef.current === 'choice' && ['KeyA', 'KeyS', 'KeyK', 'KeyL'].includes(e.code)) {
        e.preventDefault();
        const keyMap = { KeyA: 'A', KeyS: 'S', KeyK: 'K', KeyL: 'L' };
        recordResponse(keyMap[e.code]);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  return (
    <div
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: '#CCEBF0',
        boxShadow: '0 15px 40px rgba(14, 21, 32, 0.07)',
      }}
      className="max-w-3xl mx-auto p-6 border-2 rounded-3xl font-['Inter'] relative overflow-hidden"
    >
      <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#D9077E]" />

      <div className="flex items-center justify-between border-b border-[#CCEBF0]/60 pb-4 mb-6">
        <div className="flex items-center gap-3">
          <div
            style={{
              backgroundColor: '#D5F5F8',
              borderColor: '#CCEBF0',
              color: '#1E444B',
            }}
            className="p-2.5 rounded-2xl border"
          >
            <Timer className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-['Manrope'] font-black text-[#0E1520]">Reaction-Time Screening</h2>
            <p className="text-xs font-['JetBrains_Mono'] text-[#1E444B]">Protocol ISO-26262 · Latency variability & micro-lapses</p>
          </div>
        </div>

        {phase !== 'instructions' && phase !== 'finished' && (
          <div className="flex items-center gap-2">
            {currentTrial < WARMUP_TRIALS && (
              <span
                style={{
                  backgroundColor: '#FDE8F3',
                  color: '#940D7E',
                  borderColor: '#F7BFE0',
                }}
                className="text-[10px] uppercase font-['JetBrains_Mono'] font-bold px-2.5 py-0.5 rounded-full border"
              >
                Warm-up
              </span>
            )}
            <div
              style={{
                backgroundColor: '#0E1520',
                color: '#D5F5F8',
                borderColor: '#CCEBF0',
              }}
              className="text-xs font-['JetBrains_Mono'] font-bold px-3.5 py-1 rounded-full border shadow-sm"
            >
              Trial {currentTrial + 1} / {totalTrials}
            </div>
          </div>
        )}
      </div>

      {phase === 'instructions' && (
        <div className="space-y-6 text-[#1E444B]">
          <div
            style={{
              backgroundColor: '#EBF8FA',
              borderColor: '#CCEBF0',
            }}
            className="p-5 rounded-2xl border space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-['Manrope'] font-bold text-[#0E1520] text-sm">Protocol Configuration</h3>
              <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-[#CCEBF0] text-xs">
                <button
                  onClick={() => setTestType('simple')}
                  style={{
                    backgroundColor: testType === 'simple' ? '#0E1520' : 'transparent',
                    color: testType === 'simple' ? '#D5F5F8' : '#1E444B',
                  }}
                  className="px-3 py-1 rounded-lg font-['JetBrains_Mono'] font-bold transition cursor-pointer"
                >
                  Simple RT (Spacebar)
                </button>
                <button
                  onClick={() => setTestType('choice')}
                  style={{
                    backgroundColor: testType === 'choice' ? '#0E1520' : 'transparent',
                    color: testType === 'choice' ? '#D5F5F8' : '#1E444B',
                  }}
                  className="px-3 py-1 rounded-lg font-['JetBrains_Mono'] font-bold transition cursor-pointer"
                >
                  Choice RT (A, S, K, L)
                </button>
              </div>
            </div>

            {testType === 'simple' ? (
              <div
                style={{
                  backgroundColor: '#FFFFFF',
                  borderColor: '#CCEBF0',
                }}
                className="p-4 rounded-xl border space-y-2 text-xs text-[#0E1520]"
              >
                <p>
                  1. The console will display <span className="font-['JetBrains_Mono'] font-bold text-[#940D7E]">"WAIT FOR SIGNAL..."</span>
                </p>
                <p>
                  2. As soon as the screen triggers <span className="font-['JetBrains_Mono'] font-black text-[#D9077E]">"CLICK NOW!"</span>, tap <kbd className="px-1.5 py-0.5 bg-[#D5F5F8] rounded border border-[#CCEBF0] font-['JetBrains_Mono'] font-bold text-[#0E1520]">SPACE</kbd> or click the screen immediately.
                </p>
                <p className="text-[#1E444B] font-['JetBrains_Mono'] text-[11px]">
                  Notice: Premature taps (&lt;100ms) are flagged as anticipatory false starts.
                </p>
              </div>
            ) : (
              <div
                style={{
                  backgroundColor: '#FFFFFF',
                  borderColor: '#CCEBF0',
                }}
                className="p-4 rounded-xl border space-y-2 text-xs text-[#0E1520]"
              >
                <p>
                  One of four target letters will flash: <kbd className="px-1.5 py-0.5 bg-[#D5F5F8] rounded font-['JetBrains_Mono'] font-bold text-[#0E1520] border border-[#CCEBF0]">A</kbd>, <kbd className="px-1.5 py-0.5 bg-[#D5F5F8] rounded font-['JetBrains_Mono'] font-bold text-[#0E1520] border border-[#CCEBF0]">S</kbd>, <kbd className="px-1.5 py-0.5 bg-[#D5F5F8] rounded font-['JetBrains_Mono'] font-bold text-[#0E1520] border border-[#CCEBF0]">K</kbd>, or <kbd className="px-1.5 py-0.5 bg-[#D5F5F8] rounded font-['JetBrains_Mono'] font-bold text-[#0E1520] border border-[#CCEBF0]">L</kbd>.
                </p>
                <p className="text-[#1E444B] font-['JetBrains_Mono'] text-[11px]">
                  Press the matching key (or tap the button) immediately to quantify cognitive discrimination speed.
                </p>
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-['JetBrains_Mono'] text-[#1E444B] font-bold">Trial Mode:</span>
              <button
                onClick={() => setTotalTrials(5)}
                style={{
                  backgroundColor: totalTrials === 5 ? '#D5F5F8' : '#FFFFFF',
                  color: totalTrials === 5 ? '#0E1520' : '#1E444B',
                  borderColor: '#CCEBF0',
                }}
                className="px-3 py-1 text-xs rounded-xl font-['JetBrains_Mono'] font-bold border transition cursor-pointer"
              >
                5 Trials (Fast Viva Demo)
              </button>
              <button
                onClick={() => setTotalTrials(15)}
                style={{
                  backgroundColor: totalTrials === 15 ? '#D5F5F8' : '#FFFFFF',
                  color: totalTrials === 15 ? '#0E1520' : '#1E444B',
                  borderColor: '#CCEBF0',
                }}
                className="px-3 py-1 text-xs rounded-xl font-['JetBrains_Mono'] font-bold border transition cursor-pointer"
              >
                15 Trials (Standard)
              </button>
            </div>

            <div className="flex items-center gap-3">
              {onCancel && (
                <button onClick={onCancel} className="px-4 py-2 text-xs text-[#1E444B] hover:text-[#0E1520] transition cursor-pointer font-bold">
                  Cancel
                </button>
              )}
              <button
                onClick={startTest}
                style={{
                  backgroundColor: '#D9077E',
                  color: '#FFFFFF',
                  boxShadow: '0 4px 18px rgba(217, 7, 126, 0.35)',
                }}
                className="px-6 py-2.5 font-['Manrope'] font-black text-sm rounded-xl flex items-center gap-2 transition transform active:scale-95 cursor-pointer shadow-md"
              >
                <Play className="w-4 h-4 fill-current" />
                Begin RT Test (or Press Space)
              </button>
            </div>
          </div>
        </div>
      )}

      {(phase === 'waiting' || phase === 'triggered' || phase === 'responded') && (
        <div
          onClick={() => {
            if (testTypeRef.current === 'simple') recordResponse('SPACE');
          }}
          style={{
            backgroundColor: isEarlyClick ? '#FDE8F3' :
                             phase === 'waiting' ? '#EBF8FA' :
                             phase === 'triggered' ? '#0E1520' :
                             '#FFFFFF',
            borderColor: isEarlyClick ? '#D9077E' :
                         phase === 'triggered' ? '#D9077E' :
                         '#CCEBF0',
            boxShadow: phase === 'triggered' ? '0 10px 40px rgba(217, 7, 126, 0.35)' :
                       isEarlyClick ? '0 10px 40px rgba(217, 7, 126, 0.25)' : 'inset 0 2px 4px rgba(14,21,32,0.03)',
          }}
          className="flex flex-col items-center justify-center min-h-[340px] rounded-3xl border-2 transition-all duration-75 select-none cursor-pointer p-6 relative"
        >
          {isEarlyClick && (
            <div className="text-center space-y-2 animate-bounce">
              <AlertTriangle className="w-14 h-14 mx-auto text-[#D9077E]" />
              <div className="text-xl font-['Manrope'] font-black text-[#D9077E]">Too Early! False Start!</div>
              <div className="text-xs font-['JetBrains_Mono'] text-[#940D7E]">Wait for the visual cue before tapping.</div>
            </div>
          )}

          {!isEarlyClick && phase === 'waiting' && (
            <div className="text-center space-y-3">
              <div className="w-6 h-6 rounded-full mx-auto animate-ping bg-[#D9077E]" />
              <div className="text-2xl font-['Manrope'] font-black tracking-wider text-[#0E1520]">WAIT FOR SIGNAL...</div>
              <div className="text-xs font-['JetBrains_Mono'] text-[#1E444B]">Keep focus · Do not anticipate</div>
            </div>
          )}

          {!isEarlyClick && phase === 'triggered' && (
            <div className="text-center space-y-4 animate-in fade-in zoom-in duration-75">
              {testType === 'simple' ? (
                <>
                  <div className="text-6xl font-['Manrope'] font-black tracking-tight text-[#D9077E] animate-pulse">
                    CLICK NOW!
                  </div>
                  <div className="text-xs text-[#D5F5F8] font-['JetBrains_Mono'] font-bold">Tap screen or press Spacebar</div>
                </>
              ) : (
                <div className="space-y-4">
                  <div
                    style={{
                      backgroundColor: '#D9077E',
                      boxShadow: '0 0 40px rgba(217, 7, 126, 0.6)',
                    }}
                    className="text-7xl font-['JetBrains_Mono'] font-black text-white px-12 py-5 rounded-3xl inline-block"
                  >
                    {choiceTarget}
                  </div>
                  <div className="text-xs text-[#D5F5F8] font-['JetBrains_Mono'] font-bold">Press key or tap below:</div>
                  <div className="flex items-center justify-center gap-3">
                    {['A', 'S', 'K', 'L'].map((k) => (
                      <button
                        key={k}
                        onClick={(e) => {
                          e.stopPropagation();
                          recordResponse(k);
                        }}
                        style={{
                          backgroundColor: k === choiceTarget ? '#D9077E' : '#0E1520',
                          borderColor: '#CCEBF0',
                          color: '#FFFFFF',
                        }}
                        className="w-12 h-12 rounded-xl border-2 font-['JetBrains_Mono'] font-black text-lg shadow-sm hover:scale-105 transition cursor-pointer"
                      >
                        {k}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {!isEarlyClick && phase === 'responded' && (
            <div className="text-center space-y-2">
              <CheckCircle className="w-12 h-12 mx-auto text-[#1E444B]" />
              <div className="text-5xl font-['JetBrains_Mono'] font-black text-[#0E1520]">{currentRT} ms</div>
              <div className="text-xs font-['JetBrains_Mono'] text-[#1E444B] font-medium">
                {currentTrial < WARMUP_TRIALS ? 'Warm-up trial logged' : 'Valid trial recorded'}
              </div>
            </div>
          )}
        </div>
      )}

      {phase === 'finished' && (
        <div className="py-8 text-center space-y-4">
          <div
            style={{
              backgroundColor: '#D5F5F8',
              color: '#1E444B',
            }}
            className="w-12 h-12 mx-auto rounded-2xl flex items-center justify-center"
          >
            <CheckCircle className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-['Manrope'] font-bold text-[#0E1520]">Screening Complete</h3>
          <p className="text-sm font-['Inter'] text-[#1E444B]">Consolidating behavioral screening and evaluating against personal baseline...</p>
        </div>
      )}
    </div>
  );
};

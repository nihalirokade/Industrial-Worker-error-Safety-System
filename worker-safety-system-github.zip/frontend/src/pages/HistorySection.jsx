import React, { useState, useEffect } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ReferenceLine, Legend } from 'recharts';
import { 
  History as HistoryIcon, Activity, Heart, FileText, Download, CheckCircle, 
  AlertOctagon, Calendar, TrendingUp, BarChart3, Clock, ShieldCheck, Award, Zap, ChevronRight,
  ClipboardCheck
} from 'lucide-react';
import { apiClient } from '../api/client';
import { StatusBadge } from '../components/StatusBadge';

// Seeded pre-shift check history starting strictly from September 8th, 2026
const DEFAULT_BEHAVIORAL_HISTORY = [
  {
    id: 201,
    worker_id: 2,
    concentration_score: 88,
    reaction_score: 86,
    rt_median_ms: 232,
    error_detection_score: 90,
    memory_score: 85,
    classification: 'Cleared for Shift',
    created_at: '2026-09-08T07:05:00',
    shift_label: 'Shift 1 · Monday Morning'
  },
  {
    id: 202,
    worker_id: 2,
    concentration_score: 91,
    reaction_score: 89,
    rt_median_ms: 224,
    error_detection_score: 92,
    memory_score: 90,
    classification: 'Cleared for Shift',
    created_at: '2026-09-09T07:12:00',
    shift_label: 'Shift 2 · Tuesday Morning'
  },
  {
    id: 203,
    worker_id: 2,
    concentration_score: 87,
    reaction_score: 88,
    rt_median_ms: 228,
    error_detection_score: 88,
    memory_score: 88,
    classification: 'Cleared for Shift',
    created_at: '2026-09-10T07:08:00',
    shift_label: 'Shift 3 · Wednesday Morning'
  },
  {
    id: 204,
    worker_id: 2,
    concentration_score: 70,
    reaction_score: 68,
    rt_median_ms: 310,
    error_detection_score: 75,
    memory_score: 72,
    classification: 'Proceed with Caution',
    created_at: '2026-09-11T07:25:00',
    shift_label: 'Shift 4 · Thursday Morning (Fatigue)'
  },
  {
    id: 205,
    worker_id: 2,
    concentration_score: 94,
    reaction_score: 92,
    rt_median_ms: 215,
    error_detection_score: 95,
    memory_score: 92,
    classification: 'Cleared for Shift',
    created_at: '2026-09-12T07:02:00',
    shift_label: 'Shift 5 · Saturday Morning (Peak Recovery)'
  }
];

// Seeded fallback ECG report history starting strictly from September 8th, 2026
const DEFAULT_ECG_HISTORY = [
  {
    id: 101,
    filename: 'ecg_normal_shift1.pdf',
    file_type: 'pdf',
    classification: 'normal',
    summary_note: 'Clinical PDF Lead II strip · Mean HR: 69 BPM, RMSSD: 45.8 ms · Optimal sinus cadence (Normal)',
    physiological_risk_score: 14.0,
    heart_rate: 69,
    rmssd: 45.8,
    strain_level: 'LOW',
    vagal_level: 'HIGH',
    created_at: '2026-09-08T07:15:00',
    shift_day: 'Mon, Sep 8'
  },
  {
    id: 102,
    filename: 'ecg_normal_shift2.csv',
    file_type: 'ecg',
    classification: 'normal',
    summary_note: 'Wearable Lead II stream · Mean HR: 68 BPM, RMSSD: 47.1 ms · Balanced sympathovagal tone (Normal)',
    physiological_risk_score: 13.0,
    heart_rate: 68,
    rmssd: 47.1,
    strain_level: 'LOW',
    vagal_level: 'HIGH',
    created_at: '2026-09-09T07:18:00',
    shift_day: 'Tue, Sep 9'
  },
  {
    id: 103,
    filename: 'ecg_normal_shift3.pdf',
    file_type: 'pdf',
    classification: 'normal',
    summary_note: 'Clinical PDF Lead II strip · Mean HR: 71 BPM, RMSSD: 44.0 ms · Stable resting rhythm (Normal)',
    physiological_risk_score: 15.0,
    heart_rate: 71,
    rmssd: 44.0,
    strain_level: 'LOW',
    vagal_level: 'HIGH',
    created_at: '2026-09-10T07:14:00',
    shift_day: 'Wed, Sep 10'
  },
  {
    id: 104,
    filename: 'ecg_tensed_shift4.pdf',
    file_type: 'pdf',
    classification: 'tensed',
    summary_note: 'Clinical PDF Report · Mean HR: 102 BPM, RMSSD: 16.3 ms · Acute sympathetic overdrive & vagal withdrawal (Tensed)',
    physiological_risk_score: 82.0,
    heart_rate: 102,
    rmssd: 16.3,
    strain_level: 'HIGH',
    vagal_level: 'LOW',
    created_at: '2026-09-11T07:30:00',
    shift_day: 'Thu, Sep 11'
  },
  {
    id: 105,
    filename: 'ecg_normal_shift5.csv',
    file_type: 'ecg',
    classification: 'normal',
    summary_note: 'Wearable Lead II stream · Mean HR: 68 BPM, RMSSD: 46.2 ms · High vagal reserve, fully recovered (Normal)',
    physiological_risk_score: 14.0,
    heart_rate: 68,
    rmssd: 46.2,
    strain_level: 'LOW',
    vagal_level: 'HIGH',
    created_at: '2026-09-12T07:10:00',
    shift_day: 'Sat, Sep 12'
  },
];

export const HistorySection = ({ user }) => {
  // 3 Separated Tabs to prevent clustering: 'test' | 'ecg' | 'weekly'
  const [activeTab, setActiveTab] = useState('test'); 
  const [history, setHistory] = useState([]);
  const [ecgHistory, setEcgHistory] = useState(DEFAULT_ECG_HISTORY);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      // 1. Behavioral History (filter strictly starting from Sep 8, 2026)
      const data = await apiClient.getWorkerHistory(user?.worker_id || 2);
      if (data && data.length > 0) {
        const filtered = data.filter(d => {
          const dateStr = d.created_at || '';
          return dateStr >= '2026-09-08';
        });
        if (filtered.length >= 2) {
          setHistory(filtered);
        } else {
          setHistory(DEFAULT_BEHAVIORAL_HISTORY);
        }
      } else {
        setHistory(DEFAULT_BEHAVIORAL_HISTORY);
      }

      // 2. ECG Reports History (filter strictly starting from Sep 8, 2026)
      try {
        const res = await fetch(`/api/signals/history/${user?.worker_id || 2}`);
        if (res.ok) {
          const ecgList = await res.json();
          if (ecgList && ecgList.length > 0) {
            const filteredEcg = ecgList.filter(e => (e.created_at || '') >= '2026-09-08');
            if (filteredEcg.length >= 2) {
              setEcgHistory(filteredEcg.map(e => ({
                ...e,
                heart_rate: e.ecg_features?.mean_heart_rate_bpm || (e.classification === 'tensed' ? 104 : 70),
                rmssd: e.ecg_features?.rmssd_ms || (e.classification === 'tensed' ? 15.2 : 45.1),
                strain_level: (e.classification === 'tensed' || e.physiological_risk_score >= 50) ? 'HIGH' : 'LOW',
                vagal_level: (e.classification === 'tensed' || e.physiological_risk_score >= 50) ? 'LOW' : 'HIGH'
              })));
            } else {
              setEcgHistory(DEFAULT_ECG_HISTORY);
            }
          }
        }
      } catch (ecgErr) {
        console.warn('Fallback to seeded ECG history:', ecgErr);
        setEcgHistory(DEFAULT_ECG_HISTORY);
      }
    } catch (e) {
      console.error('Failed to load history:', e);
      setHistory(DEFAULT_BEHAVIORAL_HISTORY);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user?.worker_id]);

  // Format behavioral data for Recharts (Starting strictly from Sep 8, 2026)
  const chartData = (history.length > 0 ? history : DEFAULT_BEHAVIORAL_HISTORY)
    .filter(h => (h.created_at || '') >= '2026-09-08')
    .map(h => {
      const conc = h.concentration_score || 80;
      const react = h.reaction_score || 80;
      const ed = h.error_detection_score || 85;
      const mem = h.memory_score || 80;
      const score = Math.round(0.30 * conc + 0.30 * react + 0.20 * ed + 0.20 * mem);
      const d = new Date(h.created_at);
      const month = d.toLocaleString('en-US', { month: 'short' });
      const day = d.getDate();
      return {
        date: `${month} ${day}`,
        rawDate: h.created_at,
        score,
        conc,
        react,
        ed,
        mem,
        rt: h.rt_median_ms || 240,
        classification: h.classification || (score >= 75 ? 'Cleared for Shift' : score >= 50 ? 'Proceed with Caution' : 'High Error Risk'),
      };
    });

  const sessionList = [...chartData].reverse();

  // Compute Weekly Statistics (Sep 8 - Sep 12)
  const totalSessions = chartData.length;
  const avgReadiness = totalSessions > 0
    ? Math.round(chartData.reduce((acc, c) => acc + c.score, 0) / totalSessions * 10) / 10
    : 85.8;
  const avgRt = totalSessions > 0
    ? Math.round(chartData.reduce((acc, c) => acc + c.rt, 0) / totalSessions * 10) / 10
    : 241.8;
  const pass800Count = chartData.filter(c => c.rt <= 800).length;
  const pass800Rate = totalSessions > 0 ? Math.round((pass800Count / totalSessions) * 100) : 100;

  return (
    <div className="space-y-8 font-['Inter'] text-[#111111]">
      {/* Editorial Header */}
      <div className="border-b border-[#EAE3D5] pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2 font-['JetBrains_Mono'] text-xs font-bold text-[#821E14] uppercase tracking-wider">
            <span className="w-2 h-2 rounded-full bg-[#821E14]"></span>
            <span>• Longitudinal Surveillance Log (From Sep 8, 2026)</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-['Manrope'] font-black text-[#111111] uppercase tracking-tight">
            Separated <span className="text-[#821E14]">History</span>
          </h1>
          <p className="text-xs md:text-sm text-[#666055] mt-1 font-['Inter']">
            Separated records for <strong>Operator Alex Turner (WRK-8104)</strong> starting September 8, 2026. Select a category below.
          </p>
        </div>

        {/* 3 Dedicated Separated Tabs to prevent clustering */}
        <div className="inline-flex p-1.5 rounded-2xl bg-[#F2ECE1] border border-[#EAE3D5] shadow-sm flex-wrap gap-1">
          <button
            onClick={() => setActiveTab('test')}
            className={`px-4 py-2 rounded-xl text-xs font-['Manrope'] font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'test'
                ? 'bg-[#821E14] text-white shadow-md'
                : 'text-[#666055] hover:text-[#111111]'
            }`}
          >
            <ClipboardCheck className="w-4 h-4" />
            Test History ({sessionList.length})
          </button>

          <button
            onClick={() => setActiveTab('ecg')}
            className={`px-4 py-2 rounded-xl text-xs font-['Manrope'] font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'ecg'
                ? 'bg-[#821E14] text-white shadow-md'
                : 'text-[#666055] hover:text-[#111111]'
            }`}
          >
            <Heart className="w-4 h-4" />
            ECG History ({ecgHistory.length})
          </button>

          <button
            onClick={() => setActiveTab('weekly')}
            className={`px-4 py-2 rounded-xl text-xs font-['Manrope'] font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'weekly'
                ? 'bg-[#821E14] text-white shadow-md'
                : 'text-[#666055] hover:text-[#111111]'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            Check Weekly Progress
          </button>
        </div>
      </div>

      {/* =========================================================
          TAB 1: BEHAVIORAL TEST HISTORY ONLY (UNCLUSTERED)
          ========================================================= */}
      {activeTab === 'test' && (
        <div className="space-y-8 animate-fadeIn">
          {/* Section Subtitle */}
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[11px] font-['JetBrains_Mono'] font-bold text-[#821E14] uppercase tracking-wider block">
                • 4-Stage Behavioral Psychomotor Screening Records
              </span>
              <h2 className="text-xl md:text-2xl font-['Manrope'] font-black text-[#111111] uppercase mt-0.5">
                Pre-Shift Behavioral Test History (Sep 8 – Sep 12, 2026)
              </h2>
            </div>
            <span className="text-xs font-['JetBrains_Mono'] text-[#888173]">
              Target: ≤800ms Reaction Per Click
            </span>
          </div>

          {/* 1. Readiness Trajectory Chart */}
          <div className="bg-white border-2 border-[#EAE3D5] rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-['Manrope'] font-bold text-sm text-[#111111] uppercase tracking-wider">
                • Composite Readiness Score Trajectory (Sep 8 – Sep 12)
              </span>
              <span className="text-[11px] font-['JetBrains_Mono'] text-[#821E14] font-bold">
                Index (0 – 100)
              </span>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 10, right: 20, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#EAE3D5" />
                  <XAxis dataKey="date" stroke="#666055" tick={{ fontSize: 11, fill: '#666055' }} />
                  <YAxis domain={[40, 100]} stroke="#666055" tick={{ fontSize: 11, fill: '#666055' }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#111111', borderColor: '#821E14', borderRadius: '1rem', fontSize: '12px', color: '#FAF8F5' }}
                    labelStyle={{ color: '#E05A1B', fontWeight: 'bold' }}
                  />
                  <ReferenceLine y={75} stroke="#136752" strokeDasharray="4 4" strokeWidth={1.5} label={{ value: 'Cleared (≥75)', fill: '#136752', fontSize: 10, fontWeight: 'bold' }} />
                  <ReferenceLine y={50} stroke="#821E14" strokeDasharray="4 4" strokeWidth={1.5} label={{ value: 'Caution (<75)', fill: '#821E14', fontSize: 10, fontWeight: 'bold' }} />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="#821E14"
                    strokeWidth={3.5}
                    dot={{ r: 5, fill: '#821E14' }}
                    activeDot={{ r: 7, fill: '#E05A1B' }}
                    name="Readiness Score"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* 2. Completed Pre-Shift Checks List */}
          <div className="space-y-3">
            <h3 className="font-['Manrope'] font-bold text-sm text-[#111111] uppercase tracking-wider">
              Shift Test Sessions ({sessionList.length})
            </h3>

            {sessionList.map((s, idx) => {
              const d = new Date(s.rawDate);
              const dateFormatted = !isNaN(d.getTime())
                ? d.toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })
                : s.date;

              const isPass = s.rt <= 800;

              return (
                <div
                  key={idx}
                  className="p-5 rounded-2xl bg-white border border-[#EAE3D5] shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 font-['JetBrains_Mono'] hover:border-[#821E14]/40 transition"
                >
                  <div>
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-bold text-[#111111]">{dateFormatted}</span>
                      <StatusBadge status={s.classification} size="sm" />
                    </div>
                    
                    {/* 4 Test Pillars breakdown */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-[#666055] mt-2 pt-2 border-t border-[#EAE3D5]">
                      <div className="p-2 rounded-xl bg-[#FAF8F5] border border-[#EAE3D5]">
                        <span className="text-[10px] text-[#888173] block">1. Concentration</span>
                        <strong className="text-[#111111] text-sm">{s.conc} / 100</strong>
                      </div>
                      <div className="p-2 rounded-xl bg-[#FAF8F5] border border-[#EAE3D5]">
                        <span className="text-[10px] text-[#888173] block">2. Reaction Time</span>
                        <strong className="text-[#111111] text-sm">
                          {s.rt} ms
                        </strong>
                        <span className={`text-[9px] font-bold block ${isPass ? 'text-[#136752]' : 'text-[#821E14]'}`}>
                          {isPass ? '✓ Pass (≤800ms)' : '✗ Fail (>800ms)'}
                        </span>
                      </div>
                      <div className="p-2 rounded-xl bg-[#FAF8F5] border border-[#EAE3D5]">
                        <span className="text-[10px] text-[#888173] block">3. Error Detection</span>
                        <strong className="text-[#111111] text-sm">{s.ed} / 100</strong>
                      </div>
                      <div className="p-2 rounded-xl bg-[#FAF8F5] border border-[#EAE3D5]">
                        <span className="text-[10px] text-[#888173] block">4. Memory Recall</span>
                        <strong className="text-[#111111] text-sm">{s.mem} / 100</strong>
                      </div>
                    </div>
                  </div>

                  <div className="text-right border-l md:pl-6 border-[#EAE3D5]">
                    <span className="text-[10px] text-[#888173] block">READINESS</span>
                    <span className="text-3xl font-black text-[#821E14]">
                      {s.score} <span className="text-xs text-[#888173] font-normal">/ 100</span>
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* =========================================================
          TAB 2: ECG BIOSIGNAL HISTORY ONLY (UNCLUSTERED)
          ========================================================= */}
      {activeTab === 'ecg' && (
        <div className="space-y-8 animate-fadeIn">
          {/* Section Subtitle */}
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[11px] font-['JetBrains_Mono'] font-bold text-[#821E14] uppercase tracking-wider block">
                • Lead II Clinical Telemetry & Autonomic HRV Records
              </span>
              <h2 className="text-xl md:text-2xl font-['Manrope'] font-black text-[#111111] uppercase mt-0.5">
                ECG Biosignal Report History (Sep 8 – Sep 12, 2026)
              </h2>
            </div>
            <span className="text-xs font-['JetBrains_Mono'] text-[#888173]">
              {ecgHistory.length} Uploaded Reports
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ecgHistory.map((report) => {
              const isTensed = (report.classification || '').toLowerCase().includes('tens');
              const d = new Date(report.created_at);
              const dateStr = !isNaN(d.getTime())
                ? d.toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })
                : report.created_at;

              return (
                <div
                  key={report.id}
                  className="p-6 rounded-3xl bg-white border border-[#EAE3D5] shadow-sm space-y-4 font-['Inter'] hover:border-[#821E14]/50 transition"
                >
                  <div className="flex items-start justify-between gap-3 border-b border-[#EAE3D5] pb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-[#821E14]" />
                        <span className="font-['JetBrains_Mono'] text-sm font-bold text-[#111111]">
                          {report.filename}
                        </span>
                      </div>
                      <span className="text-[11px] font-['JetBrains_Mono'] text-[#888173] block mt-0.5">
                        {dateStr} · {report.file_type?.toUpperCase() || 'DOCUMENT'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-['JetBrains_Mono'] font-black uppercase border ${
                        isTensed
                          ? 'bg-[#FCE5E2] text-[#821E14] border-[#821E14]'
                          : 'bg-[#D5F5F8] text-[#136752] border-[#CCEBF0]'
                      }`}>
                        STRAIN: {isTensed ? 'HIGH' : 'LOW'}
                      </span>
                      <span className={`px-3 py-1 rounded-full text-[10px] font-['JetBrains_Mono'] font-bold uppercase border ${
                        isTensed
                          ? 'bg-[#FCE5E2] text-[#821E14] border-[#821E14]'
                          : 'bg-[#D5F5F8] text-[#136752] border-[#CCEBF0]'
                      }`}>
                        {isTensed ? 'TENSED' : 'NORMAL'}
                      </span>
                    </div>
                  </div>

                  {/* 3 Metric Scorecards */}
                  <div className="grid grid-cols-3 gap-3 font-['JetBrains_Mono'] text-center">
                    <div className="p-3 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
                      <span className="text-[10px] text-[#888173] uppercase block">Heart Rate</span>
                      <span className="text-base font-black text-[#111111]">{report.heart_rate || 70} BPM</span>
                      <span className={`text-[10px] font-bold block mt-0.5 ${isTensed ? 'text-[#821E14]' : 'text-[#136752]'}`}>
                        {isTensed ? 'HIGH' : 'NORMAL'}
                      </span>
                    </div>

                    <div className="p-3 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
                      <span className="text-[10px] text-[#888173] uppercase block">Vagal Tone</span>
                      <span className="text-base font-black text-[#111111]">{report.rmssd || 44} ms</span>
                      <span className={`text-[10px] font-bold block mt-0.5 ${isTensed ? 'text-[#821E14]' : 'text-[#136752]'}`}>
                        {isTensed ? 'LOW (SUPPRESSED)' : 'HIGH (HEALTHY)'}
                      </span>
                    </div>

                    <div className="p-3 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
                      <span className="text-[10px] text-[#888173] uppercase block">Cardiac Risk</span>
                      <span className="text-base font-black text-[#821E14]">{Math.round(report.physiological_risk_score || 16)}/100</span>
                      <span className={`text-[10px] font-bold block mt-0.5 ${isTensed ? 'text-[#821E14]' : 'text-[#136752]'}`}>
                        {isTensed ? 'HIGH' : 'LOW'}
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-[#555044] font-['Inter'] leading-relaxed pt-1 border-t border-[#EAE3D5]/60">
                    {report.summary_note || (isTensed ? 'Acute sympathetic strain detected with suppressed vagal tone.' : 'Normal sinus cadence with ample parasympathetic reserve.')}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* =========================================================
          TAB 3: CHECK WEEKLY PROGRESS VIEW (SEP 8 – SEP 12)
          ========================================================= */}
      {activeTab === 'weekly' && (
        <div className="space-y-8 animate-fadeIn">
          {/* Weekly Banner */}
          <div className="p-6 md:p-8 rounded-3xl bg-[#5A150D] text-white relative overflow-hidden shadow-xl space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/15 pb-6">
              <div>
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-[#E05A1B]" />
                  <span className="font-['JetBrains_Mono'] text-xs uppercase tracking-widest text-[#EAE3D5] font-bold">
                    • Shift Week 37 Audit · Sep 8 – Sep 12, 2026
                  </span>
                </div>
                <h2 className="text-2xl md:text-3xl font-['Manrope'] font-black uppercase text-white mt-1">
                  Weekly Operational Progress & Safety Clearance
                </h2>
                <p className="text-xs text-slate-200 font-['Inter'] mt-1">
                  Consolidated cognitive stamina, psychomotor speed compliance (≤800ms), and autonomic recovery trajectory.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <span className="px-4 py-2 rounded-full text-xs font-['JetBrains_Mono'] font-black uppercase tracking-wider bg-[#136752] text-white border border-[#239174] shadow-md flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4" />
                  WEEKLY VERDICT: CLEARED (GRADE A)
                </span>
              </div>
            </div>

            {/* 4 Massive Weekly Scorecards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-white/10 border border-white/15">
                <span className="text-3xl md:text-4xl font-['Manrope'] font-black text-white block">
                  {avgReadiness}
                </span>
                <span className="text-[11px] font-['JetBrains_Mono'] uppercase tracking-wider text-[#EAE3D5] font-bold block mt-1">
                  Avg Weekly Readiness
                </span>
                <span className="text-[10px] text-[#00F0FF] font-['JetBrains_Mono'] block mt-0.5">
                  +4.2% vs Plant Baseline
                </span>
              </div>

              <div className="p-5 rounded-2xl bg-white/10 border border-white/15">
                <span className="text-3xl md:text-4xl font-['Manrope'] font-black text-[#E05A1B] block">
                  {pass800Rate}%
                </span>
                <span className="text-[11px] font-['JetBrains_Mono'] uppercase tracking-wider text-[#EAE3D5] font-bold block mt-1">
                  ≤ 800ms RT Pass Rate
                </span>
                <span className="text-[10px] text-slate-300 font-['JetBrains_Mono'] block mt-0.5">
                  Mean Latency: {avgRt} ms
                </span>
              </div>

              <div className="p-5 rounded-2xl bg-white/10 border border-white/15">
                <span className="text-3xl md:text-4xl font-['Manrope'] font-black text-white block">
                  5 / 5
                </span>
                <span className="text-[11px] font-['JetBrains_Mono'] uppercase tracking-wider text-[#EAE3D5] font-bold block mt-1">
                  Pre-Shift Adherence
                </span>
                <span className="text-[10px] text-[#00F0FF] font-['JetBrains_Mono'] block mt-0.5">
                  100% On-Time Protocol
                </span>
              </div>

              <div className="p-5 rounded-2xl bg-white/10 border border-white/15">
                <span className="text-3xl md:text-4xl font-['Manrope'] font-black text-white block">
                  80%
                </span>
                <span className="text-[11px] font-['JetBrains_Mono'] uppercase tracking-wider text-[#EAE3D5] font-bold block mt-1">
                  Autonomic Equilibrium
                </span>
                <span className="text-[10px] text-slate-300 font-['JetBrains_Mono'] block mt-0.5">
                  4 Normal / 1 Rested
                </span>
              </div>
            </div>
          </div>

          {/* DAY-BY-DAY WEEKLY PROGRESSION MATRIX (SEP 8 - SEP 12) */}
          <div className="bg-white border-2 border-[#EAE3D5] rounded-3xl p-6 md:p-8 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#EAE3D5] pb-4">
              <div>
                <span className="text-[11px] font-['JetBrains_Mono'] font-bold text-[#821E14] uppercase tracking-wider">
                  • Detailed Progression Matrix
                </span>
                <h3 className="text-xl font-['Manrope'] font-black text-[#111111] uppercase mt-0.5">
                  Day-by-Day Shift Evaluation (September 8 – September 12, 2026)
                </h3>
              </div>
              <span className="text-xs font-['JetBrains_Mono'] text-[#666055]">
                Operator: <strong>Alex Turner (WRK-8104)</strong>
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-['Inter'] text-xs">
                <thead>
                  <tr className="border-b border-[#EAE3D5] text-[#888173] font-['JetBrains_Mono'] uppercase text-[10px] tracking-wider">
                    <th className="py-3 px-3">Date & Shift</th>
                    <th className="py-3 px-3">Concentration</th>
                    <th className="py-3 px-3">Reaction Time (≤800ms)</th>
                    <th className="py-3 px-3">Error Detection</th>
                    <th className="py-3 px-3">Memory</th>
                    <th className="py-3 px-3">ECG Autonomic Status</th>
                    <th className="py-3 px-3">Composite</th>
                    <th className="py-3 px-3 text-right">Clearance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EAE3D5]">
                  {chartData.map((item, idx) => {
                    const ecgMatch = ecgHistory[idx] || ecgHistory[0];
                    const isTensed = (ecgMatch.classification || '').toLowerCase().includes('tens');
                    const isRtPass = item.rt <= 800;

                    return (
                      <tr key={idx} className="hover:bg-[#FAF8F5] transition">
                        <td className="py-3.5 px-3 font-['JetBrains_Mono'] font-bold text-[#111111]">
                          {item.date}, 2026
                        </td>
                        <td className="py-3.5 px-3 font-['JetBrains_Mono'] font-semibold text-[#111111]">
                          {item.conc} / 100
                        </td>
                        <td className="py-3.5 px-3 font-['JetBrains_Mono']">
                          <span className="font-bold text-[#111111]">{item.rt} ms</span>
                          <span className={`ml-1.5 px-1.5 py-0.5 rounded text-[9px] font-bold ${
                            isRtPass ? 'bg-[#D5F5F8] text-[#136752]' : 'bg-[#FCE5E2] text-[#821E14]'
                          }`}>
                            {isRtPass ? 'PASS' : 'FAIL'}
                          </span>
                        </td>
                        <td className="py-3.5 px-3 font-['JetBrains_Mono'] font-semibold text-[#111111]">
                          {item.ed} / 100
                        </td>
                        <td className="py-3.5 px-3 font-['JetBrains_Mono'] font-semibold text-[#111111]">
                          {item.mem} / 100
                        </td>
                        <td className="py-3.5 px-3 font-['JetBrains_Mono']">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                            isTensed 
                              ? 'bg-[#FCE5E2] text-[#821E14] border-[#821E14]' 
                              : 'bg-[#D5F5F8] text-[#136752] border-[#CCEBF0]'
                          }`}>
                            {isTensed ? 'TENSED (HR 102)' : `NORMAL (HR ${ecgMatch.heart_rate})`}
                          </span>
                        </td>
                        <td className="py-3.5 px-3 font-['Manrope'] font-black text-sm text-[#821E14]">
                          {item.score}
                        </td>
                        <td className="py-3.5 px-3 text-right">
                          <StatusBadge status={item.classification} size="sm" />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* 4 Pillar Progression Curves (Sep 8 – Sep 12) */}
          <div className="bg-white border-2 border-[#EAE3D5] rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-['Manrope'] font-bold text-sm text-[#111111] uppercase tracking-wider">
                • 4 Pillar Cognitive Trajectory Across Week 37
              </span>
              <span className="text-[11px] font-['JetBrains_Mono'] text-[#821E14] font-bold">
                Daily Sub-Scores (0 – 100)
              </span>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 10, right: 20, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#EAE3D5" />
                  <XAxis dataKey="date" stroke="#666055" tick={{ fontSize: 11, fill: '#666055' }} />
                  <YAxis domain={[50, 100]} stroke="#666055" tick={{ fontSize: 11, fill: '#666055' }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#111111', borderColor: '#821E14', borderRadius: '1rem', fontSize: '12px', color: '#FAF8F5' }}
                    labelStyle={{ color: '#E05A1B', fontWeight: 'bold' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', fontFamily: 'JetBrains Mono' }} />
                  <Line type="monotone" dataKey="conc" stroke="#821E14" strokeWidth={2.5} name="Concentration" dot={{ r: 4 }} />
                  <Line type="monotone" dataKey="react" stroke="#E05A1B" strokeWidth={2.5} name="Reaction Score" dot={{ r: 4 }} />
                  <Line type="monotone" dataKey="ed" stroke="#136752" strokeWidth={2.5} name="Error Detection" dot={{ r: 4 }} />
                  <Line type="monotone" dataKey="mem" stroke="#443E33" strokeWidth={2.5} name="Memory Recall" dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Supervisor Weekly Synthesis & Formal Clearance Note */}
          <div className="p-6 md:p-8 rounded-3xl bg-[#FAF8F5] border-2 border-[#EAE3D5] space-y-4">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#821E14]" />
              <span className="font-['JetBrains_Mono'] text-xs uppercase tracking-wider text-[#821E14] font-bold">
                • Shift Command Weekly Operational Synthesis
              </span>
            </div>
            <blockquote className="font-['Manrope'] font-medium text-sm md:text-base text-[#111111] leading-relaxed italic border-l-4 border-[#821E14] pl-4">
              "Operator Alex Turner (WRK-8104) has demonstrated outstanding operational resilience throughout Week 37. The Thursday (Sep 11) mid-week fatigue event was detected promptly with high autonomic strain (HR 102 bpm, RMSSD 16.3ms). Following a 30-minute rest protocol and rotation away from heavy hydraulic press duty, full neurocardiac equilibrium was recovered by Saturday morning (Readiness 94/100, RMSSD 46.2ms, Reaction RT 215ms). Alex is officially certified for full-clearance industrial operations."
            </blockquote>
            <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-[#EAE3D5] text-xs font-['JetBrains_Mono'] text-[#666055]">
              <span>Medical Officer: Dr. Sarah Vance, MD (Plant Unit 4)</span>
              <span>Audit Signature: ISO-26262-CERT-98214</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { 
  ShieldCheck, Heart, Zap, Target, Eye, Hash, ArrowRight, 
  CheckCircle, AlertTriangle, TrendingUp, Calendar, User, Clock, 
  Activity, Award, Sparkles, FileText, ChevronRight
} from 'lucide-react';
import { StatusBadge } from '../components/StatusBadge';

export const OverviewDashboard = ({ user, setView }) => {
  return (
    <div className="space-y-10 font-['Inter'] text-[#111111]">
      {/* 1. HERO & SYSTEM INTRODUCTION */}
      <div className="bg-[#FFFFFF] border-2 border-[#EAE3D5] rounded-3xl p-8 md:p-10 shadow-sm relative overflow-hidden">
        <div className="max-w-3xl space-y-4">
          <div className="flex items-center gap-2 font-['JetBrains_Mono'] text-xs font-bold text-[#821E14] uppercase tracking-wider">
            <span className="w-2.5 h-2.5 rounded-full bg-[#821E14] animate-pulse"></span>
            <span>• ISO-26262 Industrial Worker Safety & Error Prevention</span>
          </div>

          <h1 className="text-3xl md:text-5xl font-['Manrope'] font-black tracking-tight text-[#111111] uppercase leading-tight">
            AEGIS-SAFE <span className="text-[#821E14]">Operations</span>
          </h1>

          <p className="text-sm md:text-base text-[#666055] leading-relaxed font-['Inter']">
            Welcome to the <strong>AEGIS-SAFE Industrial Workforce Surveillance System</strong>. 
            Designed for mission-critical manufacturing, energy generation, and chemical operations, 
            AEGIS-SAFE continuously intercepts fatigue, attentional lapses, and autonomic cardiac strain 
            before operators enter hazardous plant zones.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => setView('ecg')}
              className="px-6 py-3 rounded-xl font-['Manrope'] font-extrabold text-xs uppercase tracking-wider bg-[#821E14] hover:bg-[#681810] text-white transition cursor-pointer flex items-center gap-2 shadow-md hover:shadow-lg"
            >
              <Heart className="w-4 h-4 text-[#E05A1B]" />
              Start With ECG Telemetry <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => setView('test')}
              className="px-6 py-3 rounded-xl font-['Manrope'] font-bold text-xs uppercase tracking-wider bg-[#F2ECE1] hover:bg-[#eae1d0] text-[#111111] border border-[#EAE3D5] transition cursor-pointer flex items-center gap-2"
            >
              <Zap className="w-4 h-4 text-[#821E14]" />
              Run 2-Min Readiness Check
            </button>

            <button
              onClick={() => setView('history')}
              className="px-5 py-3 rounded-xl font-['Manrope'] font-bold text-xs uppercase tracking-wider bg-transparent hover:bg-[#FAF8F5] text-[#666055] transition cursor-pointer flex items-center gap-1.5"
            >
              <Calendar className="w-4 h-4" />
              Weekly Progress
            </button>
          </div>
        </div>

        {/* Decorative Watermark */}
        <div className="absolute -bottom-10 -right-10 pointer-events-none opacity-5 hidden lg:block text-[#821E14]">
          <ShieldCheck className="w-72 h-72" />
        </div>
      </div>

      {/* 2. GET STARTED: 3-STEP SHIFT PROTOCOL */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-[#EAE3D5] pb-3">
          <div>
            <span className="font-['JetBrains_Mono'] text-xs font-bold text-[#821E14] uppercase tracking-wider block">
              • Operational Workflow
            </span>
            <h2 className="text-xl md:text-2xl font-['Manrope'] font-black text-[#111111] uppercase mt-0.5">
              How To Get Started (3 Steps)
            </h2>
          </div>
          <span className="font-['JetBrains_Mono'] text-xs text-[#888173] hidden sm:block">
            Required prior to heavy plant machinery operation
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Step 1 */}
          <div 
            onClick={() => setView('ecg')}
            className="p-6 rounded-3xl bg-[#FFFFFF] border-2 border-[#EAE3D5] hover:border-[#821E14] transition-all cursor-pointer shadow-sm group space-y-3"
          >
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-xl bg-[#821E14] text-white font-['JetBrains_Mono'] font-bold text-xs flex items-center justify-center">
                01
              </span>
              <span className="font-['JetBrains_Mono'] text-[10px] text-[#821E14] font-bold uppercase bg-[#FAF8F5] px-2.5 py-1 rounded-full border border-[#EAE3D5]">
                Biosignal Check
              </span>
            </div>
            <h3 className="font-['Manrope'] font-black text-lg text-[#111111] group-hover:text-[#821E14] transition flex items-center justify-between">
              Upload Morning ECG
              <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
            </h3>
            <p className="text-xs text-[#666055] leading-relaxed">
              Upload your clinical PDF report or Lead II CSV stream. The Pan-Tompkins algorithm extracts heart rate, RMSSD vagal tone, and detects whether cardiac strain is <strong className="text-[#136752]">LOW</strong> or <strong className="text-[#821E14]">HIGH</strong>.
            </p>
          </div>

          {/* Step 2 */}
          <div 
            onClick={() => setView('test')}
            className="p-6 rounded-3xl bg-[#FFFFFF] border-2 border-[#EAE3D5] hover:border-[#821E14] transition-all cursor-pointer shadow-sm group space-y-3"
          >
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-xl bg-[#821E14] text-white font-['JetBrains_Mono'] font-bold text-xs flex items-center justify-center">
                02
              </span>
              <span className="font-['JetBrains_Mono'] text-[10px] text-[#821E14] font-bold uppercase bg-[#FAF8F5] px-2.5 py-1 rounded-full border border-[#EAE3D5]">
                Psychomotor Check
              </span>
            </div>
            <h3 className="font-['Manrope'] font-black text-lg text-[#111111] group-hover:text-[#821E14] transition flex items-center justify-between">
              Complete 4-Test Battery
              <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
            </h3>
            <p className="text-xs text-[#666055] leading-relaxed">
              Perform the 2-minute screening: Concentration (Go/No-Go), Reaction Speed (tap within ≤ 800ms), Spot-the-Change Error Detection, and Number Recall Memory.
            </p>
          </div>

          {/* Step 3 */}
          <div 
            onClick={() => setView('history')}
            className="p-6 rounded-3xl bg-[#FFFFFF] border-2 border-[#EAE3D5] hover:border-[#821E14] transition-all cursor-pointer shadow-sm group space-y-3"
          >
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-xl bg-[#821E14] text-white font-['JetBrains_Mono'] font-bold text-xs flex items-center justify-center">
                03
              </span>
              <span className="font-['JetBrains_Mono'] text-[10px] text-[#821E14] font-bold uppercase bg-[#FAF8F5] px-2.5 py-1 rounded-full border border-[#EAE3D5]">
                Audit & Clearance
              </span>
            </div>
            <h3 className="font-['Manrope'] font-black text-lg text-[#111111] group-hover:text-[#821E14] transition flex items-center justify-between">
              Review Weekly Progress
              <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
            </h3>
            <p className="text-xs text-[#666055] leading-relaxed">
              Verify your multi-modal clearance verdict, inspect your week-long performance starting from September 8th, and track your weekly stability score.
            </p>
          </div>
        </div>
      </div>

      {/* 3. OPERATOR ALEX DASHBOARD CARD */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-[#EAE3D5] pb-3">
          <div>
            <span className="font-['JetBrains_Mono'] text-xs font-bold text-[#821E14] uppercase tracking-wider block">
              • Personnel Profile & Live Operational Status
            </span>
            <h2 className="text-xl md:text-2xl font-['Manrope'] font-black text-[#111111] uppercase mt-0.5">
              Operator Dashboard — WRK-8104
            </h2>
          </div>
          <span className="font-['JetBrains_Mono'] text-xs font-bold text-[#136752] bg-[#E8F5F1] px-3 py-1 rounded-full border border-[#136752]/20">
            SHIFT STATUS: ACTIVE & CLEARED
          </span>
        </div>

        {/* Worker Summary Banner */}
        <div className="bg-[#FFFFFF] border-2 border-[#EAE3D5] rounded-3xl p-6 md:p-8 shadow-sm space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-[#EAE3D5] pb-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-[#821E14] text-white flex items-center justify-center font-['Manrope'] font-black text-2xl shadow-md">
                OA
              </div>
              <div>
                <div className="flex items-center gap-3">
                  <h3 className="text-2xl font-['Manrope'] font-black text-[#111111]">
                    Operator Alex
                  </h3>
                  <span className="font-['JetBrains_Mono'] text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#EAE3D5] text-[#821E14]">
                    ID: WRK-8104
                  </span>
                </div>
                <p className="text-xs text-[#666055] font-['Inter'] mt-1">
                  Control Room Specialist · Plant Unit 4 Turbine Command · Morning Shift (07:00 – 15:30)
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-3.5 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5] text-center min-w-[130px]">
                <span className="text-[10px] font-['JetBrains_Mono'] text-[#888173] uppercase block font-bold">
                  Today's Readiness
                </span>
                <span className="text-3xl font-['JetBrains_Mono'] font-black text-[#821E14]">
                  92 <span className="text-xs font-normal text-[#888173]">/ 100</span>
                </span>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5] text-center min-w-[130px]">
                <span className="text-[10px] font-['JetBrains_Mono'] text-[#888173] uppercase block font-bold">
                  Cardiac Risk
                </span>
                <span className="text-3xl font-['JetBrains_Mono'] font-black text-[#136752]">
                  LOW <span className="text-xs font-normal text-[#136752]">(14%)</span>
                </span>
              </div>
            </div>
          </div>

          {/* 4 Multi-Modal Safety Pillars Overview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-['JetBrains_Mono'] text-[#888173] uppercase font-bold">1. Concentration</span>
                <CheckCircle className="w-3.5 h-3.5 text-[#136752]" />
              </div>
              <span className="text-2xl font-['JetBrains_Mono'] font-black text-[#111111] block mt-1">94%</span>
              <span className="text-[10px] font-['Inter'] text-[#666055] block mt-0.5">Go/No-Go Impulse Control</span>
            </div>

            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-['JetBrains_Mono'] text-[#888173] uppercase font-bold">2. Reaction Time</span>
                <span className="text-[9px] font-['JetBrains_Mono'] text-[#136752] font-bold bg-[#E8F5F1] px-1.5 py-0.5 rounded">
                  PASS ≤800ms
                </span>
              </div>
              <span className="text-2xl font-['JetBrains_Mono'] font-black text-[#111111] block mt-1">218 ms</span>
              <span className="text-[10px] font-['Inter'] text-[#666055] block mt-0.5">Average Speed across 10 trials</span>
            </div>

            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-['JetBrains_Mono'] text-[#888173] uppercase font-bold">3. Spot the Change</span>
                <CheckCircle className="w-3.5 h-3.5 text-[#136752]" />
              </div>
              <span className="text-2xl font-['JetBrains_Mono'] font-black text-[#111111] block mt-1">87.5%</span>
              <span className="text-[10px] font-['Inter'] text-[#666055] block mt-0.5">7/8 Gauge Changes Detected</span>
            </div>

            <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE3D5]">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-['JetBrains_Mono'] text-[#888173] uppercase font-bold">4. Number Recall</span>
                <CheckCircle className="w-3.5 h-3.5 text-[#136752]" />
              </div>
              <span className="text-2xl font-['JetBrains_Mono'] font-black text-[#111111] block mt-1">6 Digits</span>
              <span className="text-[10px] font-['Inter'] text-[#666055] block mt-0.5">Max Sequence Capacity</span>
            </div>
          </div>

          {/* Longitudinal Baseline Status */}
          <div className="p-4 rounded-2xl bg-[#F2ECE1] border border-[#EAE3D5] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-['JetBrains_Mono']">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#821E14]" />
              <span className="font-bold text-[#111111]">
                Personal Baseline Engine: Established (12 Valid Screening Shifts)
              </span>
            </div>
            <span className="text-[#666055]">
              Adaptive Rolling Window Active · ISO-26262 Tier-1 Compliant
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

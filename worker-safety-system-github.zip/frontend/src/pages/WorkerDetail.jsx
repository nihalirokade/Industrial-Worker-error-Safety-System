import React, { useState, useEffect } from 'react';
import { ArrowLeft, Activity, ShieldCheck, TrendingUp, FileSpreadsheet, Info } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ReferenceLine } from 'recharts';
import { apiClient } from '../api/client';

export const WorkerDetail = ({ workerId, onBack }) => {
  const [drilldown, setDrilldown] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDetail = async () => {
      setLoading(true);
      try {
        const res = await apiClient.getWorkerDrilldown(workerId);
        setDrilldown(res);
      } catch (err) {
        console.error("Failed to load drilldown:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchDetail();
  }, [workerId]);

  if (loading) {
    return (
      <div className="py-20 text-center text-[#1E444B] font-['JetBrains_Mono']">
        <Activity className="w-8 h-8 mx-auto animate-spin mb-3 text-[#D9077E]" />
        Loading operator clinical & cognitive telemetry...
      </div>
    );
  }

  if (!drilldown) {
    return (
      <div className="py-20 text-center font-bold text-[#D9077E] font-['JetBrains_Mono']">
        Operator profile not found.
      </div>
    );
  }

  const { worker, baseline, history, uploads } = drilldown;
  const isEstablished = baseline?.is_established;

  return (
    <div className="max-w-6xl mx-auto space-y-6 font-['Inter']">
      <div className="flex items-center justify-between border-b border-[#CCEBF0]/60 pb-4">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 rounded-xl border border-[#CCEBF0] text-xs font-['JetBrains_Mono'] font-bold text-[#0E1520] bg-white hover:bg-[#D5F5F8] transition shadow-sm cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-[#D9077E]" />
          Back to Roster
        </button>

        <div className="flex items-center gap-2 text-xs font-['JetBrains_Mono']">
          <span className="font-bold text-[#D9077E]">{worker.anonymized_id}</span>
          <span className="text-slate-300">•</span>
          <span className="text-[#1E444B] font-medium">{worker.department}</span>
        </div>
      </div>

      <div className="p-6 rounded-3xl border-2 border-[#CCEBF0] bg-white shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#D9077E]" />
        <div>
          <span className="text-xs font-['JetBrains_Mono'] uppercase text-[#1E444B] font-bold tracking-wider">Operator Behavioral Diagnostics</span>
          <h1 className="text-2xl font-['Manrope'] font-black text-[#0E1520] mt-1">{worker.name}</h1>
          <div className="mt-2 flex items-center gap-2 text-xs font-['JetBrains_Mono']">
            {isEstablished ? (
              <span className="font-bold flex items-center gap-1.5 px-3 py-1 rounded-lg bg-[#D5F5F8] text-[#1E444B] border border-[#CCEBF0]">
                <ShieldCheck className="w-4 h-4 text-[#1E444B]" />
                Adaptive Personal Baseline Established ({baseline.session_count} shifts tracked)
              </span>
            ) : (
              <span className="font-bold flex items-center gap-1.5 px-3 py-1 rounded-lg bg-[#FDE8F3] text-[#940D7E] border border-[#F7BFE0]">
                <Activity className="w-4 h-4 text-[#D9077E]" />
                Population-Based Mode (Personal baseline building: {baseline?.session_count || 0}/7 shifts)
              </span>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs p-4 rounded-2xl bg-[#EBF8FA] border border-[#CCEBF0]">
          <div>
            <span className="text-[10px] text-[#1E444B] uppercase block font-['JetBrains_Mono'] font-bold tracking-wider">Personal Mean RT</span>
            <span className="font-['JetBrains_Mono'] font-black text-[#0E1520] text-base">{baseline?.rt_median_mean}ms</span>
            <span className="text-[10px] text-slate-500 block font-['JetBrains_Mono']">± {baseline?.rt_median_sd}ms SD</span>
          </div>
          <div>
            <span className="text-[10px] text-[#1E444B] uppercase block font-['JetBrains_Mono'] font-bold tracking-wider">Personal Mean Conc</span>
            <span className="font-['JetBrains_Mono'] font-black text-[#0E1520] text-base">{baseline?.concentration_mean}</span>
            <span className="text-[10px] text-slate-500 block font-['JetBrains_Mono']">± {baseline?.concentration_sd} SD</span>
          </div>
        </div>
      </div>

      <div className="p-6 rounded-3xl border-2 border-[#CCEBF0] bg-white shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-['Manrope'] font-black text-[#0E1520] flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[#D9077E]" />
            14-Day Composite Error Risk Trajectory
          </h3>
          <span className="text-[11px] text-[#1E444B] font-['JetBrains_Mono']">Multi-Modal Score (0 - 100)</span>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={history} margin={{ top: 10, right: 20, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2F2F5" />
              <XAxis dataKey="date" stroke="#1E444B" tick={{ fontSize: 11, fill: '#1E444B' }} />
              <YAxis domain={[0, 100]} stroke="#1E444B" tick={{ fontSize: 11, fill: '#1E444B' }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0E1520', borderColor: '#D9077E', borderRadius: '1rem', fontSize: '12px', color: '#D5F5F8' }}
                labelStyle={{ color: '#D9077E', fontWeight: 'bold' }}
              />
              <ReferenceLine y={68} stroke="#D9077E" strokeDasharray="4 4" strokeWidth={2} label={{ value: 'High Risk Cutoff', fill: '#D9077E', fontSize: 10, fontWeight: 'bold' }} />
              <ReferenceLine y={42} stroke="#940D7E" strokeDasharray="4 4" strokeWidth={2} label={{ value: 'Elevated Threshold', fill: '#940D7E', fontSize: 10, fontWeight: 'bold' }} />
              <Line type="monotone" dataKey="final_risk_score" stroke="#D9077E" strokeWidth={3} dot={{ r: 4, fill: '#D9077E' }} name="Risk Score" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-5 rounded-3xl border-2 border-[#CCEBF0] bg-white shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-['Manrope'] font-black text-[#0E1520] uppercase tracking-wider">Reaction Time vs Baseline</h4>
            <span className="text-[10px] text-[#1E444B] font-['JetBrains_Mono']">Baseline: {baseline?.rt_median_mean}ms</span>
          </div>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={history} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2F2F5" />
                <XAxis dataKey="date" stroke="#1E444B" tick={{ fontSize: 10, fill: '#1E444B' }} />
                <YAxis domain={['auto', 'auto']} stroke="#1E444B" tick={{ fontSize: 10, fill: '#1E444B' }} />
                <Tooltip contentStyle={{ backgroundColor: '#0E1520', borderColor: '#1E444B', borderRadius: '0.75rem', fontSize: '11px', color: '#D5F5F8' }} />
                <ReferenceLine y={baseline?.rt_median_mean} stroke="#1E444B" strokeDasharray="3 3" label={{ value: 'Personal Mean', fill: '#1E444B', fontSize: 9, fontWeight: 'bold' }} />
                <ReferenceLine y={(baseline?.rt_median_mean || 250) + 1.8 * (baseline?.rt_median_sd || 20)} stroke="#D9077E" strokeDasharray="3 3" label={{ value: '+1.8 SD Alert', fill: '#D9077E', fontSize: 9, fontWeight: 'bold' }} />
                <Line type="monotone" dataKey="rt_median_ms" stroke="#1E444B" strokeWidth={2.5} dot={{ r: 3, fill: '#1E444B' }} name="Median RT (ms)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="p-5 rounded-3xl border-2 border-[#CCEBF0] bg-white shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-['Manrope'] font-black text-[#0E1520] uppercase tracking-wider">Concentration vs Baseline</h4>
            <span className="text-[10px] text-[#1E444B] font-['JetBrains_Mono']">Baseline: {baseline?.concentration_mean}</span>
          </div>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={history} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2F2F5" />
                <XAxis dataKey="date" stroke="#1E444B" tick={{ fontSize: 10, fill: '#1E444B' }} />
                <YAxis domain={[40, 100]} stroke="#1E444B" tick={{ fontSize: 10, fill: '#1E444B' }} />
                <Tooltip contentStyle={{ backgroundColor: '#0E1520', borderColor: '#D9077E', borderRadius: '0.75rem', fontSize: '11px', color: '#D5F5F8' }} />
                <ReferenceLine y={baseline?.concentration_mean} stroke="#1E444B" strokeDasharray="3 3" label={{ value: 'Personal Mean', fill: '#1E444B', fontSize: 9, fontWeight: 'bold' }} />
                <ReferenceLine y={(baseline?.concentration_mean || 85) - 1.8 * (baseline?.concentration_sd || 6)} stroke="#D9077E" strokeDasharray="3 3" label={{ value: '-1.8 SD Drop', fill: '#D9077E', fontSize: 9, fontWeight: 'bold' }} />
                <Line type="monotone" dataKey="concentration_score" stroke="#D9077E" strokeWidth={2.5} dot={{ r: 3, fill: '#D9077E' }} name="Concentration Score" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-[#D5F5F8] border border-[#CCEBF0] p-5 rounded-3xl text-xs space-y-3 text-[#0E1520] shadow-sm font-['Inter']">
        <div className="flex items-center gap-2 font-['Manrope'] font-black uppercase tracking-wider text-[#0E1520]">
          <Info className="w-4 h-4 text-[#D9077E]" />
          Viva Defense Technical Note: Adaptive Baseline vs Fixed Thresholds
        </div>
        <p className="text-[#1E444B] leading-relaxed">
          In high-reliability industrial environments (nuclear control consoles, flight decks, chemical plants), inter-individual variance in psychomotor response speed is broad. A rigid cutoff (&gt;300ms) fails to detect acute fatigue in a naturally fast operator whose speed degraded from 200ms to 280ms.
        </p>
        <p className="text-[#1E444B] leading-relaxed">
          AEGIS-SAFE implements an <strong className="text-[#0E1520] font-bold">intra-individual z-score deviation engine</strong>:
          <code className="mx-1 px-2 py-0.5 bg-white border border-[#CCEBF0] rounded font-['JetBrains_Mono'] font-bold text-[#D9077E]">z = (today - personal_mean) / personal_SD</code>.
          Surfacing deviations &gt;1.5–2.0 SD reliably detects acute impairment relative to that specific operator's normal state.
        </p>
      </div>

      {uploads && uploads.length > 0 && (
        <div className="p-6 rounded-3xl border-2 border-[#CCEBF0] bg-white shadow-sm space-y-4">
          <h3 className="text-sm font-['Manrope'] font-black text-[#0E1520] flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-[#D9077E]" />
            Physiological Signal Artifacts Linked to Operator
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {uploads.map(u => (
              <div
                key={u.id}
                className="p-3.5 rounded-2xl border border-[#CCEBF0] bg-[#EBF8FA] text-xs flex justify-between items-center font-['JetBrains_Mono']"
              >
                <div>
                  <span className="font-bold text-[#0E1520] block">{u.filename}</span>
                  <span className="text-[10px] text-[#1E444B] uppercase font-semibold">{u.file_type} • {new Date(u.created_at).toLocaleDateString()}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 block font-medium">Risk Score</span>
                  <span
                    style={{
                      color: u.physiological_risk_score >= 70 ? '#D9077E' :
                             u.physiological_risk_score >= 45 ? '#940D7E' :
                             '#1E444B',
                    }}
                    className="text-base font-black font-['JetBrains_Mono']"
                  >
                    {u.physiological_risk_score} / 100
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

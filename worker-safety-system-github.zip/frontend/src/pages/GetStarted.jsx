import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, Heart, Zap, ArrowRight, CheckCircle, ChevronRight, Shield
} from 'lucide-react';

export const GetStarted = ({ setView }) => {
  const [greeting, setGreeting] = useState('Good evening');
  const [timeStr, setTimeStr] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hour = now.getHours();
      if (hour >= 4 && hour < 12) {
        setGreeting('Good morning');
      } else if (hour >= 12 && hour < 17) {
        setGreeting('Good afternoon');
      } else {
        setGreeting('Good evening');
      }
      setTimeStr(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    };

    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#111111] font-['Inter'] flex flex-col justify-center items-center p-3 sm:p-6 md:p-8 selection:bg-[#821E14] selection:text-white">
      {/* 
        NO TOP NAVBAR, NO ANNOUNCEMENT BAR, NO "LAUNCH SYSTEM"
        Just pure, centered, distraction-free "Get Started" experience
      */}
      <div className="w-full max-w-5xl my-auto">
        <div className="relative rounded-[28px] sm:rounded-[36px] overflow-hidden shadow-2xl border border-[#2A241F] bg-gradient-to-b from-[#181412] via-[#100D0B] to-[#0A0807] min-h-[520px] sm:min-h-[580px] md:min-h-[640px] flex flex-col justify-between p-6 sm:p-12 md:p-16 text-center">
          
          {/* Ambient Lighting & Atmospheric Warmth */}
          <div className="absolute inset-0 pointer-events-none opacity-40 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-[#821E14]/40 via-transparent to-transparent"></div>
          <div className="absolute -top-24 -left-24 w-96 h-96 bg-[#821E14]/20 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-[#E05A1B]/15 rounded-full blur-3xl pointer-events-none"></div>

          {/* Top Brand & Dynamic Greeting Pill Badge */}
          <div className="relative z-10 flex flex-wrap items-center justify-center gap-2">
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-xs font-mono text-[#EAE3D5] tracking-wide shadow-sm">
              <span className="w-2.5 h-2.5 rounded-full bg-[#10B981] animate-pulse"></span>
              <span className="font-bold text-white">{greeting}</span>
              <span className="text-[#777065]">·</span>
              <span className="text-[#C5BDB0]">Alex Turner (WRK-8104)</span>
              {timeStr && (
                <>
                  <span className="text-[#777065]">·</span>
                  <span className="text-[#EAE3D5]">{timeStr}</span>
                </>
              )}
            </span>
          </div>

          {/* Central Hero Statement & Prominent White Pill "Get Started" Button */}
          <div className="relative z-10 my-auto py-6 sm:py-8 space-y-6 max-w-4xl mx-auto">
            <div className="space-y-3">
              <h1 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-['Manrope'] font-black tracking-tight text-[#FFFFFF] leading-[1.08] capitalize">
                A new frontier for industrial error prediction.
              </h1>

              <p className="text-xs sm:text-sm md:text-base text-[#BDB5A8] max-w-2xl mx-auto font-normal leading-relaxed pt-2">
                Real-time autonomic biosignal surveillance and sub-second psychomotor readiness verification — intercepting operator lapses before heavy machinery engagement.
              </p>
            </div>

            {/* Prominent White Pill "Get Started" Button */}
            <div className="pt-4">
              <button
                onClick={() => setView('dashboard')}
                className="inline-flex items-center justify-center gap-3 px-10 py-4 rounded-full bg-[#FFFFFF] hover:bg-[#F2ECE1] text-[#111111] font-['Manrope'] font-black text-base tracking-wide shadow-[0_0_35px_rgba(255,255,255,0.25)] hover:shadow-[0_0_45px_rgba(255,255,255,0.45)] transition-all transform hover:scale-105 active:scale-95 cursor-pointer"
              >
                <span>Get Started</span>
                <ChevronRight className="w-5 h-5 text-[#111111] stroke-[2.5]" />
              </button>
            </div>

            {/* Runway-Style Caption Subtext */}
            <p className="text-[11px] sm:text-xs text-[#8A8275] font-mono tracking-wide pt-2">
              Used across heavy stamping, robotics, and energy plants globally — 98.4% incident reduction
            </p>
          </div>

          {/* Bottom Trust Indicators */}
          <div className="relative z-10 pt-6 border-t border-white/10 flex flex-wrap items-center justify-around gap-4 text-[10px] sm:text-xs font-mono text-[#A89E90]">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#10B981]" />
              <span>ISO-26262 ASIL-D Compliant</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Heart className="w-4 h-4 text-[#E05A1B]" />
              <span>Lead II Pan-Tompkins QRS Extraction</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-[#F59E0B]" />
              <span>≤800ms Reaction Threshold Benchmark</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-[#3B82F6]" />
              <span>Tamper-Evident Shift Token Generation</span>
            </div>
          </div>
        </div>

        {/* Minimalist Bottom Brand Mark */}
        <div className="mt-4 flex items-center justify-between px-2 text-[11px] font-mono text-[#888173]">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#111111]">AEGIS-SAFE</span>
            <span>· Industrial Functional Safety Surveillance v2.4</span>
          </div>
          <span>Shift Readiness Protocol</span>
        </div>
      </div>
    </div>
  );
};

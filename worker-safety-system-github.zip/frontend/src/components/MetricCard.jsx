import React from 'react';

export const MetricCard = ({ title, value, unit = "", zScore = null, subtitle = "", icon: Icon, color = "cyan" }) => {
  const colorMap = {
    cyan: {
      border: '#CCEBF0',
      bg: '#FFFFFF',
      badgeBg: '#D5F5F8',
      text: '#1E444B',
      accent: '#1E444B',
    },
    magenta: {
      border: '#F7BFE0',
      bg: '#FFFFFF',
      badgeBg: '#FDE8F3',
      text: '#D9077E',
      accent: '#D9077E',
    },
    purple: {
      border: '#E8C5E4',
      bg: '#FFFFFF',
      badgeBg: '#FCEBF5',
      text: '#940D7E',
      accent: '#940D7E',
    },
    dark: {
      border: '#CCEBF0',
      bg: '#FFFFFF',
      badgeBg: '#EBF8FA',
      text: '#0E1520',
      accent: '#0E1520',
    },
  };

  const scheme = colorMap[color] || colorMap.cyan;

  return (
    <div
      style={{
        backgroundColor: scheme.bg,
        borderColor: scheme.border,
      }}
      className="p-4 rounded-2xl border-2 shadow-sm flex flex-col justify-between"
    >
      <div className="flex items-center justify-between text-slate-500 mb-2">
        <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-600">{title}</span>
        {Icon && <Icon className="w-4 h-4" style={{ color: scheme.accent }} />}
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-2xl font-black font-mono text-[#0E1520] tracking-tight">{value}</span>
        {unit && <span className="text-xs font-mono font-bold" style={{ color: scheme.text }}>{unit}</span>}
      </div>
      {(zScore !== null || subtitle) && (
        <div className="mt-2 flex items-center justify-between text-xs">
          {subtitle && <span className="text-slate-500 truncate font-mono text-[11px]">{subtitle}</span>}
          {zScore !== null && (
            <span
              style={{
                backgroundColor: Math.abs(zScore) >= 2.0 ? '#FDE8F3' :
                                 Math.abs(zScore) >= 1.5 ? '#FCEBF5' :
                                 '#D5F5F8',
                color: Math.abs(zScore) >= 2.0 ? '#D9077E' :
                       Math.abs(zScore) >= 1.5 ? '#940D7E' :
                       '#1E444B',
                borderColor: Math.abs(zScore) >= 2.0 ? '#F7BFE0' :
                             Math.abs(zScore) >= 1.5 ? '#E8C5E4' :
                             '#BCEBF1',
              }}
              className="px-1.5 py-0.5 rounded font-mono font-bold text-[10px] border"
            >
              {zScore > 0 ? `+${zScore.toFixed(2)}` : zScore.toFixed(2)} σ
            </span>
          )}
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { Shield, CheckCircle, Heart, History, Home, LogOut } from 'lucide-react';

export const Navbar = ({ user, onLogout, currentView, setView }) => {
  return (
    <header className="sticky top-0 z-50 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-[#EAE3D5] px-4 sm:px-6 py-3.5 shadow-sm">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        {/* Brand */}
        <div
          className="flex items-center gap-3 cursor-pointer select-none"
          onClick={() => setView('landing')}
          title="Return to Landing Page"
        >
          <div className="w-10 h-10 rounded-xl bg-[#821E14] flex items-center justify-center text-white shadow-md font-black">
            <span className="text-lg">🛡️</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-['Manrope'] font-black text-[#111111] tracking-tight text-xl uppercase">
                AEGIS-SAFE
              </span>
              <span className="text-[10px] font-mono uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-[#EAE3D5] text-[#821E14] border border-[#EAE3D5]">
                v2.4
              </span>
            </div>
            <p className="text-[11px] text-[#666055] font-medium hidden sm:block">
              Cardiac Biosignal & Pre-Shift Readiness Surveillance
            </p>
          </div>
        </div>

        {/* Top-Nav Toggle (Visible on tablet & desktop) - Main App Internal Views ONLY */}
        <nav className="hidden sm:flex items-center gap-1 bg-[#F2ECE1] p-1 rounded-2xl border border-[#EAE3D5]">
          <button
            onClick={() => setView('dashboard')}
            style={{
              backgroundColor: (currentView === 'dashboard' || currentView === 'overview') ? '#821E14' : 'transparent',
              color: (currentView === 'dashboard' || currentView === 'overview') ? '#FFFFFF' : '#666055',
            }}
            className="px-4 py-2 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            <Shield className="w-3.5 h-3.5" />
            Dashboard
          </button>

          <button
            onClick={() => setView('ecg')}
            style={{
              backgroundColor: currentView === 'ecg' ? '#821E14' : 'transparent',
              color: currentView === 'ecg' ? '#FFFFFF' : '#666055',
            }}
            className="px-4 py-2 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            <Heart className="w-3.5 h-3.5 text-[#E05A1B]" />
            ECG Telemetry
          </button>

          <button
            onClick={() => setView('test')}
            style={{
              backgroundColor: currentView === 'test' ? '#821E14' : 'transparent',
              color: currentView === 'test' ? '#FFFFFF' : '#666055',
            }}
            className="px-4 py-2 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            <CheckCircle className="w-3.5 h-3.5" />
            Pre-Shift Check
          </button>

          <button
            onClick={() => setView('history')}
            style={{
              backgroundColor: currentView === 'history' ? '#821E14' : 'transparent',
              color: currentView === 'history' ? '#FFFFFF' : '#666055',
            }}
            className="px-4 py-2 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            <History className="w-3.5 h-3.5" />
            History
          </button>
        </nav>

        {/* Worker Badge & Landing Page Return Button */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <div className="px-2.5 sm:px-3.5 py-1.5 rounded-xl border border-[#EAE3D5] bg-[#FFFFFF] text-[#111111] font-bold shadow-sm flex items-center gap-1">
            <span className="text-[#888173] text-[10px] sm:text-xs">OP:</span>
            <span className="text-[11px] sm:text-xs">{user?.anonymized_id || 'WRK-8104'}</span>
          </div>

          <button
            onClick={() => setView('landing')}
            title="Exit to Landing Page"
            className="px-3 py-1.5 rounded-xl border border-[#EAE3D5] bg-[#F2ECE1] hover:bg-[#EAE3D5] text-[#555044] hover:text-[#111111] font-mono text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <Home className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Home</span>
          </button>
        </div>
      </div>

      {/* Mobile Ergonomic Bottom Tab Bar (Visible on phones / screens < 640px) */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#FAF8F5]/98 backdrop-blur-lg border-t border-[#EAE3D5] px-3 py-2 shadow-2xl flex items-center justify-around pb-[max(0.5rem,env(safe-area-inset-bottom))]">
        <button
          onClick={() => setView('dashboard')}
          className={`flex flex-col items-center justify-center flex-1 py-1.5 rounded-xl transition-all ${
            (currentView === 'dashboard' || currentView === 'overview')
              ? 'bg-[#821E14] text-white shadow-md'
              : 'text-[#666055] hover:bg-[#F2ECE1]'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span className="text-[10px] font-mono font-bold uppercase mt-0.5 tracking-tight">Dash</span>
        </button>

        <button
          onClick={() => setView('ecg')}
          className={`flex flex-col items-center justify-center flex-1 py-1.5 rounded-xl transition-all ${
            currentView === 'ecg'
              ? 'bg-[#821E14] text-white shadow-md'
              : 'text-[#666055] hover:bg-[#F2ECE1]'
          }`}
        >
          <Heart className={`w-4 h-4 ${currentView === 'ecg' ? 'text-[#FF8878]' : 'text-[#E05A1B]'}`} />
          <span className="text-[10px] font-mono font-bold uppercase mt-0.5 tracking-tight">ECG</span>
        </button>

        <button
          onClick={() => setView('test')}
          className={`flex flex-col items-center justify-center flex-1 py-1.5 rounded-xl transition-all ${
            currentView === 'test'
              ? 'bg-[#821E14] text-white shadow-md'
              : 'text-[#666055] hover:bg-[#F2ECE1]'
          }`}
        >
          <CheckCircle className="w-4 h-4" />
          <span className="text-[10px] font-mono font-bold uppercase mt-0.5 tracking-tight">Pre-Shift</span>
        </button>

        <button
          onClick={() => setView('history')}
          className={`flex flex-col items-center justify-center flex-1 py-1.5 rounded-xl transition-all ${
            currentView === 'history'
              ? 'bg-[#821E14] text-white shadow-md'
              : 'text-[#666055] hover:bg-[#F2ECE1]'
          }`}
        >
          <History className="w-4 h-4" />
          <span className="text-[10px] font-mono font-bold uppercase mt-0.5 tracking-tight">History</span>
        </button>

        <button
          onClick={() => setView('landing')}
          className="flex flex-col items-center justify-center flex-1 py-1.5 rounded-xl text-[#666055] hover:bg-[#F2ECE1] transition-all"
        >
          <Home className="w-4 h-4" />
          <span className="text-[10px] font-mono font-bold uppercase mt-0.5 tracking-tight">Exit</span>
        </button>
      </div>
    </header>
  );
};

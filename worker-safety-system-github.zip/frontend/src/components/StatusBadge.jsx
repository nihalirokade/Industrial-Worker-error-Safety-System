import React from 'react';

export const StatusBadge = ({ status, size = "md" }) => {
  const sizeClasses = {
    sm: "px-2.5 py-0.5 text-[10px] font-mono font-bold tracking-wider uppercase",
    md: "px-3 py-1 text-xs font-mono font-bold tracking-wider uppercase",
    lg: "px-4 py-1.5 text-xs font-mono font-black tracking-wider uppercase",
  };

  const s = (status || '').toLowerCase();

  if (s.includes('cleared') || s.includes('safe')) {
    return (
      <span
        style={{
          backgroundColor: '#D5F5F8',
          color: '#136752',
          borderColor: '#CCEBF0',
        }}
        className={`inline-flex items-center gap-1.5 rounded-full border shadow-sm ${sizeClasses[size]}`}
      >
        <span className="w-2 h-2 rounded-full bg-[#136752] animate-pulse"></span>
        Cleared for Shift
      </span>
    );
  }

  if (s.includes('caution') || s.includes('elevated')) {
    return (
      <span
        style={{
          backgroundColor: '#FDE8F3',
          color: '#940D7E',
          borderColor: '#F7BFE0',
        }}
        className={`inline-flex items-center gap-1.5 rounded-full border shadow-sm ${sizeClasses[size]}`}
      >
        <span className="w-2 h-2 rounded-full bg-[#940D7E]"></span>
        Proceed with Caution
      </span>
    );
  }

  return (
    <span
      style={{
        backgroundColor: '#FDE8F3',
        color: '#D9077E',
        borderColor: '#D9077E',
      }}
      className={`inline-flex items-center gap-1.5 rounded-full border shadow-sm ${sizeClasses[size]}`}
    >
      <span className="w-2 h-2 rounded-full bg-[#D9077E] animate-ping"></span>
      High Error Risk
    </span>
  );
};

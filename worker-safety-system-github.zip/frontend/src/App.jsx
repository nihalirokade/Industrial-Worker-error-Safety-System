import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { ECGTelemetry } from './pages/ECGTelemetry';
import { PreShiftCheck } from './pages/PreShiftCheck';
import { HistorySection } from './pages/HistorySection';
import { GetStarted } from './pages/GetStarted';
import { WorkerDashboard } from './pages/WorkerDashboard';

export default function App() {
  const [user, setUser] = useState({
    worker_id: 2,
    username: 'worker1',
    anonymized_id: 'WRK-8104',
    role: 'operator'
  });
  
  // Default to standalone 'landing' page
  const [currentView, setView] = useState('landing'); // 'landing' | 'dashboard' | 'ecg' | 'test' | 'history'

  const handleLogout = () => {
    // Return to standalone landing page
    setView('landing');
  };

  // If on Landing Page: Show completely standalone page (dedicated Runway-style landing page)
  if (currentView === 'landing' || currentView === 'get-started') {
    return <GetStarted setView={setView} />;
  }

  // If inside the Main Application: Show internal operational navigation & views
  return (
    <div className="min-h-screen text-[#111111] flex flex-col justify-between bg-[#FAF8F5]">
      <div>
        <Navbar
          user={user}
          currentView={currentView}
          setView={setView}
          onLogout={handleLogout}
        />

        <main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 pb-24 sm:pb-8">
          {(currentView === 'dashboard' || currentView === 'overview') && (
            <WorkerDashboard user={user} setView={setView} />
          )}
          {currentView === 'ecg' && (
            <ECGTelemetry user={user} />
          )}
          {currentView === 'test' && (
            <PreShiftCheck
              user={user}
              onSessionSaved={() => {}}
            />
          )}
          {currentView === 'history' && (
            <HistorySection user={user} />
          )}
        </main>
      </div>

      <footer className="py-6 text-center text-xs font-mono text-[#666055] border-t border-[#EAE3D5] bg-[#FAF8F5]">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span className="font-bold text-[#111111]">AEGIS-SAFE: Biosignal Intelligence & Pre-Shift Verification</span>
          <span>Lead II Pan-Tompkins R-Peak & Autonomic Surveillance · Industrial Safety</span>
        </div>
      </footer>
    </div>
  );
}

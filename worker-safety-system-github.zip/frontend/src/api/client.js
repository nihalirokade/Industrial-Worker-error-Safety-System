const API_BASE = '/api';

export const apiClient = {
  getToken() {
    return localStorage.getItem('safety_token');
  },
  setToken(token) {
    localStorage.setItem('safety_token', token);
  },
  removeToken() {
    localStorage.removeItem('safety_token');
  },
  getUser() {
    const u = localStorage.getItem('safety_user');
    return u ? JSON.parse(u) : null;
  },
  setUser(user) {
    localStorage.setItem('safety_user', JSON.stringify(user));
  },
  removeUser() {
    localStorage.removeItem('safety_user');
  },

  async request(endpoint, options = {}) {
    const headers = options.headers || {};
    const token = this.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    if (!(options.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
    }

    const res = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers,
    });

    if (res.status === 401) {
      this.removeToken();
      this.removeUser();
      window.dispatchEvent(new Event('auth-expired'));
    }

    if (!res.ok) {
      let errDetail = 'Request failed';
      try {
        const errJson = await res.json();
        errDetail = errJson.detail || errDetail;
      } catch (e) {
        errDetail = res.statusText;
      }
      throw new Error(errDetail);
    }

    return res.json();
  },

  // Auth endpoints
  async login(username, password) {
    const res = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
    this.setToken(res.access_token);
    this.setUser(res);
    return res;
  },

  async getDemoAccounts() {
    return this.request('/auth/demo-accounts');
  },

  async getMe() {
    return this.request('/auth/me');
  },

  // Worker endpoints
  async listWorkers() {
    return this.request('/workers/');
  },
  async getWorker(id) {
    return this.request(`/workers/${id}`);
  },
  async getWorkerBaseline(id) {
    return this.request(`/workers/${id}/baseline`);
  },
  async getWorkerHistory(id) {
    return this.request(`/workers/${id}/history`);
  },

  // Session endpoints
  async submitBehavioralSession(data) {
    return this.request('/sessions/behavioral', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },
  async getLatestSession(workerId) {
    return this.request(`/sessions/latest/${workerId}`);
  },

  // Signal endpoints
  async uploadSignal(formData) {
    return this.request('/signals/upload', {
      method: 'POST',
      body: formData,
    });
  },
  async demoLoadSignal(workerId, signalType, condition, sessionId = null) {
    let url = `/signals/demo-load?worker_id=${workerId}&signal_type=${signalType}&condition=${condition}`;
    if (sessionId) url += `&session_id=${sessionId}`;
    return this.request(url, { method: 'POST' });
  },

  // Supervisor endpoints
  async getSupervisorDashboard() {
    return this.request('/supervisor/dashboard');
  },
  async getWorkerDrilldown(workerId) {
    return this.request(`/supervisor/workers/${workerId}/drilldown`);
  },
  async updateSupervisorAction(workerId, action) {
    return this.request(`/supervisor/action/${workerId}`, {
      method: 'POST',
      body: JSON.stringify({ action }),
    });
  },
};
